# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project overview

OntoMCDA is a research prototype that recommends Multi-Criteria Decision Aid (MCDA) methods for a problem described in Portuguese free-form text. It combines a lexicon/rule-based NLP layer with an OWL ontology of ~100+ MCDA methods (AHP, TOPSIS, VIKOR, ELECTRE, PROMETHEE, BWM, COPRAS, CODAS, etc.) and returns a ranked list of methods whose ontological profile matches the inferred problem premises.

All user-facing text, lexicons, attribute names (e.g. `tipo_problema`, `compensatoriedade`), and ontology individuals are in Portuguese — preserve PT-BR when editing code and when generating/matching text.

## Repository layout

```
OntoMCDA_final.owl               RDF/XML ontology (~100+ MCDA methods)
pyproject.toml                   Build config and tool settings (pytest, ruff)
requirements.txt                 Pinned runtime dependencies
requirements-dev.txt             Dev extras (pytest, ruff)
src/ontomcda/                    Main Python package
    config.py                    ATTRS, ATTR_TO_PROP, DATA_ATTRS, ATTR_WEIGHTS, LEX constants
    nlp/                         NLP layer (infer_premissas, infer_attr, rule-based overrides)
    ontology.py                  OWL reader: load_profiles, get_method_instances (dual-namespace)
    scoring.py                   consult_ontology, ontology_match, canon_value
    pipeline.py                  recomendar() — top-level entry point
    dataset/                     Gold-standard generation (casos, gabarito, ranking_esperado)
    evaluation/                  Metrics (precision/recall/F1, P@k, Hit@k, nDCG@k, bootstrap CI)
data/                            Generated CSVs and templates (do not hand-edit)
    casos.csv
    gabarito_premissas.csv
    ranking_esperado.csv
    templates.json
notebooks/
    relatorio_validacao.ipynb    Results/validation notebook (not a Colab notebook)
tests/                           pytest suite (64 tests)
docs/
    integracao_modulos.md        Module integration guide
    metricas.md                  Metrics definitions and evaluation protocol
legacy/                          Original Colab notebooks — preserved for traceability (see Legacy)
outputs/                         Generated reports (relatorio.xlsx — not committed)
```

See `docs/integracao_modulos.md` for module dependency diagrams and `docs/metricas.md` for evaluation metric definitions.

## Setup and running

```bash
python -m venv .venv
source .venv/Scripts/activate    # Windows/Git-Bash
# source .venv/bin/activate      # Linux / macOS
pip install -r requirements.txt -e .
```

CLI entry points:

```bash
python -m ontomcda.dataset       # regenera data/ (casos.csv, gabarito_premissas.csv, ranking_esperado.csv, templates.json)
python -m ontomcda.evaluation    # executa pipeline completo e gera outputs/relatorio.xlsx
pytest -v                        # roda a suite de 64 testes
```

## Architecture of the recommendation pipeline

The flow is fixed and the attribute list `ATTRS` (in `src/ontomcda/config.py`) is the contract that wires NLP output to ontology queries. Changing it means changing six parallel structures:

1. **`ATTRS`** — ordered list of premise attributes (e.g. `tipo_problema`, `compensatoriedade`, `tipo_variavel`, `usa_pesos`, ...).
2. **`ATTR_TO_PROP`** — maps each attribute to one-or-more OWL property local names. Lists allow for legacy aliases (e.g. `tipo_problema → ["temTipoProblema", "temTipoDeProblema"]`).
3. **`DATA_ATTRS`** — subset treated as boolean data properties (`usa_pesos`, `requer_pesos`, `gera_pesos`, ...); `parse_bool_literal` normalizes their values to `"Sim"/"Nao"`.
4. **`ATTR_WEIGHTS`** — scoring weights used by `consult_ontology` to rank methods.
5. **`LEX`** — lexicon used by `infer_attr` to map surface forms in the text to canonical ontology values.
6. **`MANDATORY_QUERY_ATTRS`** — premises that must be inferred (currently just `tipo_problema`); if missing, `recomendar` short-circuits and returns empty results.

Pipeline entry points:
- `infer_premissas(texto)` → `(prem, evid_map, score_map)`. Runs `norm_txt` (lowercase + unidecode), then `infer_attr` per attribute, then overrides `tipo_problema` via `infer_tipo_problema_por_regras` (rule-based disambiguation of Escolha/Ordenacao/Classificacao).
- `load_profiles(owl_path)` → `dict[str, dict[str, str | None]]`. Uses rdflib to enumerate `MetodoMCDA` instances and read properties under **both** namespaces.
- `recomendar(texto, profiles, top_k)` → glues the two halves together: `infer_premissas` → `build_query_profile` (applies weights) → `consult_ontology` (scoring + accept/reject split).

### Dual-namespace OWL pattern — important

The ontology contains every triple twice: under the canonical namespace `NEW_NS = "http://www.ontomcda.org/onto#"` and under a legacy prefix `OLD_NS = "http://www.ontomcda.org/onto#OntologyMCDA#"` (note the literal `#` inside the URI). All reader code (`get_method_instances`, `load_profiles`) queries both namespaces and merges results. When adding a property or class, write it under both namespaces or update the readers, otherwise half of the data will be silently invisible.

### Value canonicalization and fuzzy matching

`canon_value(attr, val)` normalizes values (e.g. `"Ordenação" → "Ordenacao"`). Matching in `ontology_match` is asymmetric and attribute-specific:
- `tipo_variavel_match` implements a compatibility lattice (`Mista` accepts most cardinal subtypes, `Cardinal` accepts its subtypes, etc.).
- `estrutura_decisoria` has aliases (`MonoMulti`, `Monodecisor`, `Multidecisor`, `Coletiva`) that map onto `Individual`/`Grupo`.
- `compensatoriedade == "ParcialmenteCompensatorio"` matches any of the three variants.

When adding a new value, update `canon_value`, the matching helper, and the lexicon in lock-step.

## Legacy

`legacy/OntoMCDA_final.ipynb` and `legacy/OntoMCDA_metrica PLN.ipynb` are the original Google Colab notebooks from which the current package was refactored. They are preserved for traceability and historical reference only — do not treat them as authoritative for current behavior. Both notebooks called `google.colab.files.upload()` and `!pip install ...` directly; the refactored package replaces all of that with the venv setup and CLI commands described above.
