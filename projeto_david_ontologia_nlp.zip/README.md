# OntoMCDA

Recomendador de métodos MCDA a partir de descrição em português, guiado por ontologia OWL.

## Setup

```bash
python -m venv .venv
source .venv/Scripts/activate    # Windows bash
# source .venv/bin/activate      # Linux/Mac
pip install -r requirements.txt -e .
```

Dev extras: `pip install -r requirements-dev.txt`.

## Reproduzir a validação

```bash
python -m ontomcda.dataset       # regenera data/
python -m ontomcda.evaluation    # gera outputs/relatorio.xlsx
jupyter lab notebooks/relatorio_validacao.ipynb
```

## Uso programático

```python
from ontomcda import load_profiles, recomendar
p = load_profiles("OntoMCDA_final.owl")
r = recomendar("Um analista precisa escolher o melhor fornecedor...", p, top_k=5)
print(r["aceitos"])
```

## Testes

```bash
pytest              # all tests
pytest -k nlp       # NLP layer only
ruff check .
```

## Estrutura

Ver `CLAUDE.md` e `docs/integracao_modulos.md`.

## Validação

Ver `docs/metricas.md` para explicação das métricas.
Dataset sintético: `data/casos.csv`, `data/gabarito_premissas.csv`.
Templates documentados em `data/templates.json`.
