# Linha de Raciocínio — OntoMCDA

## 1 — Dados de entrada

27 casos sintéticos (9 templates × 3 redações em PT-BR), cada um com gabarito de 8–10 premissas. Gerados pelos próprios autores para cobrir os tipos de problema MCDA mais comuns.

## 2 — Como funciona o modelo

Dois estágios em sequência: (a) NLP lexicon-based — mapeia expressões do texto para premissas estruturais do problema; (b) consulta à ontologia OWL — compara premissas com perfis de ~100 métodos MCDA e produz ranking ponderado.

## 3 — Execução do modelo

`batch_recomendar` processa os 27 casos → gera `pred_premissas` (DataFrame). O notebook executa isso de forma reproduzível com `OWL_PATH` fixo e seed 42.

## 4 — Validação do modelo

Comparação `pred_premissas` vs. `gabarito_premissas` por atributo. Estabilidade linguística mede se as 3 redações do mesmo template produzem as mesmas premissas. Ranking fica pendente (requer curadoria de `ranking_esperado.csv`).

## 5 — Métricas

PLN: accuracy, F1 macro/micro, kappa, taxa de não-inferido. Ranking (quando disponível): P@k, Hit@k, nDCG, MRR, Kendall τ, Spearman ρ. Tudo com bootstrap IC 95%.

## 6 — Gráficos

Matrizes de confusão por atributo, barras de F1 por atributo, concordância por template, errorbar de bootstrap.

---

## O modelo tem qualidade?

Depende do que você quer afirmar. Aqui a análise honesta:

**O modelo provavelmente funciona bem para:**
- `tipo_problema` — regras explícitas + léxico rico → esperar acurácia alta (>85%)
- `tipo_variavel` — termos técnicos distintivos ("quantitativo", "ordinal", "mista")
- `estrutura_decisoria` — sinais claros ("comitê", "grupo", "um decisor")

**O modelo provavelmente é mais fraco em:**
- `completude_pref` e `ambiente_decisao` — lexicon com menos cobertura, textos raramente mencionam isso explicitamente
- `compensatoriedade` — vocabulário mais técnico, menos usado naturalmente

**Limitação estrutural importante:**
O dataset foi criado pelos próprios autores calibrado com o léxico — os textos usam as mesmas palavras que o léxico detecta. Isso tende a superestimar a qualidade real do NLP. Um avaliador externo vai notar isso.

A validação de ranking está incompleta — `ranking_esperado.csv` está vazio. Sem isso, você valida o NLP mas não valida se a recomendação de métodos é correta.

---

## Recomendação

O modelo tem qualidade aceitável para um protótipo de pesquisa se você declarar as limitações claramente. O ponto mais fraco para defender é a ausência de validação do ranking e o viés do dataset sintético. Preencher ao menos 5–10 linhas do `ranking_esperado.csv` com literatura MCDA clássica fortaleceria muito a defesa.
