# Métricas de Avaliação — OntoMCDA

Este documento explica cada métrica usada para avaliar o sistema, em linguagem acessível. As métricas estão divididas em dois grupos: **métricas de PLN** (avaliam a inferência de premissas) e **métricas de ranking** (avaliam a qualidade dos métodos recomendados).

---

## Métricas de PLN (Processamento de Linguagem Natural)

Essas métricas medem o quanto o sistema acerta ao identificar as premissas do problema a partir do texto.

---

### Acurácia (*Accuracy*)

**Em uma frase:** proporção de casos em que o sistema acertou o valor da premissa.

**Como ler:** vai de 0 a 1 (ou 0% a 100%). Acurácia 1,0 significa que o sistema acertou todos os casos; 0,5 significa que acertou metade. Em problemas com poucas classes, acurácia alta pode ser enganosa — por isso usamos também F1 e Kappa.

**Por que importa aqui:** é a métrica mais intuitiva e serve de referência rápida para cada premissa (tipo de problema, tipo de variável, etc.). Como os templates são balanceados (3 redações por template), a acurácia não é inflada por uma classe dominante.

---

### F1 Macro

**Em uma frase:** média do F1 de cada classe, tratando todas as classes com o mesmo peso.

**Como ler:** vai de 0 a 1. Quando há classes com poucos exemplos (ex: "Classificacao" com apenas 9 redações), o F1 macro penaliza erros nessas classes tanto quanto nas classes maiores. Valores acima de 0,8 são considerados bons para classificação multi-classe com poucos dados.

**Por que importa aqui:** o dataset tem 3 valores possíveis para `tipo_problema` (Escolha, Ordenacao, Classificacao), cada um com o mesmo número de redações. F1 macro garante que nenhuma classe seja ignorada.

---

### F1 Micro

**Em uma frase:** F1 calculado globalmente, somando todos os acertos e erros antes de dividir.

**Como ler:** vai de 0 a 1. Quando as classes são balanceadas, F1 micro e F1 macro convergem. Diferenças entre eles revelam desbalanceamento de classes.

**Por que importa aqui:** serve de controle para verificar se o balanceamento do dataset está funcionando como planejado.

---

### Kappa de Cohen (*Cohen's Kappa*)

**Em uma frase:** mede o quanto o sistema acerta além do que acertaria por puro acaso.

**Como ler:**

| Valor | Interpretação |
|---|---|
| < 0 | Pior que o acaso |
| 0,0 – 0,2 | Concordância fraca |
| 0,2 – 0,4 | Concordância razoável |
| 0,4 – 0,6 | Concordância moderada |
| 0,6 – 0,8 | Concordância substancial |
| 0,8 – 1,0 | Concordância quase perfeita |

**Por que importa aqui:** com 3 classes equiprováveis, um classificador aleatório acertaria 33% dos casos. Kappa revela se o NLP está de fato aprendendo padrões ou apenas chutando a classe mais frequente.

---

### Taxa de Não-Inferido

**Em uma frase:** proporção de casos em que o sistema não conseguiu inferir nenhum valor para a premissa.

**Como ler:** vai de 0 a 1. Zero é ideal — significa que o sistema sempre encontrou algum sinal no texto. Valores altos indicam que o léxico precisa ser expandido para cobrir mais formas de expressar aquela premissa.

**Por que importa aqui:** premissas não inferidas são silenciosas — o sistema não erra, simplesmente ignora o critério. Por isso é importante medir separadamente, pois a acurácia calculada sobre os casos inferidos pode ser artificialmente alta.

---

### Precisão por Classe, Recall por Classe, F1 por Classe

**Em uma frase:** as três métricas clássicas de classificação, calculadas separadamente para cada valor de cada premissa.

**Como ler:**
- **Precisão:** dos casos em que o sistema disse "Ordenacao", quantos eram realmente "Ordenacao"?
- **Recall:** de todos os casos que eram "Ordenacao", quantos o sistema identificou corretamente?
- **F1:** média harmônica entre precisão e recall — equilibra os dois.

**Por que importa aqui:** permite identificar confusões específicas (ex: o sistema confunde "Escolha" com "Ordenacao") e direcionar melhorias no léxico para os valores mais problemáticos.

---

### Matriz de Confusão

**Em uma frase:** tabela que mostra, para cada par (gabarito, predição), quantos casos caíram em cada combinação.

**Como ler:** a diagonal principal contém os acertos. Os elementos fora da diagonal são erros — a linha indica o valor real, a coluna indica o que o sistema disse.

**Por que importa aqui:** é a forma mais detalhada de entender *como* o sistema erra. Por exemplo: o sistema confunde "Ordenacao" com "Escolha" com mais frequência do que o contrário? Isso aponta para ambiguidade no léxico.

---

## Métricas de Ranking

Essas métricas medem a qualidade da lista de métodos recomendados, comparando com um ranking de referência (preenchido por curadoria da literatura ou por especialistas).

> **Nota:** estas métricas só são calculadas quando `ranking_esperado.csv` contém pelo menos um caso com métodos relevantes indicados. No dataset sintético atual, esse arquivo está vazio — as métricas de ranking serão aplicadas quando a curadoria for feita.

---

### P@k (Precisão em k)

**Em uma frase:** dos k primeiros métodos recomendados, qual fração é realmente relevante para o problema?

**Como ler:** vai de 0 a 1. P@3 = 0,67 significa que 2 dos 3 primeiros recomendados são métodos adequados. Avaliamos tipicamente P@3, P@5 e P@10.

**Por que importa aqui:** na prática, o analista olha apenas os primeiros resultados. P@k mede exatamente a qualidade do que ele vê primeiro.

---

### Hit@k

**Em uma frase:** o sistema colocou *ao menos um* método relevante nos primeiros k?

**Como ler:** é 0 ou 1 por caso (depois se calcula a média). Hit@5 = 0,9 significa que em 90% dos casos havia ao menos um método correto entre os cinco primeiros.

**Por que importa aqui:** para aplicações práticas, é suficiente que um método adequado apareça entre as primeiras sugestões — o analista saberá reconhecê-lo. Hit@k captura esse nível mínimo de utilidade.

---

### nDCG@k (Ganho Cumulativo Descontado Normalizado)

**Em uma frase:** mede não só *quantos* métodos relevantes aparecem nos primeiros k, mas também *onde* aparecem — um método relevante na posição 1 vale mais que na posição k.

**Como ler:** vai de 0 a 1. nDCG@k = 1,0 significa que o ranking gerado é idêntico ao ideal (todos os relevantes no topo). Penaliza mais fortemente um método relevante que aparece por último do que um que aparece no meio.

**Por que importa aqui:** reflete a experiência real do analista — ele lê a lista de cima para baixo e tende a parar nos primeiros itens.

---

### MRR (Mean Reciprocal Rank)

**Em uma frase:** em média, em que posição aparece o primeiro método relevante?

**Como ler:** MRR = 1/posição_média. MRR = 1,0 significa que o melhor método sempre aparece em primeiro lugar. MRR = 0,5 significa que, em média, o primeiro método relevante está na posição 2.

**Por que importa aqui:** captura a experiência do analista que busca o *melhor* método, não uma lista de bons métodos. É complementar ao Hit@k.

---

### Kendall τ parcial

**Em uma frase:** mede o quanto a *ordem* dos métodos em comum entre o ranking gerado e o ranking esperado está correta.

**Como ler:** vai de -1 a 1. τ = 1,0 significa que os métodos em comum aparecem na mesma ordem nos dois rankings. τ = -1,0 significa ordem invertida. Calculado apenas sobre os métodos que aparecem em ambos os rankings (*parcial*).

**Por que importa aqui:** vai além de saber quais métodos aparecem — avalia se a priorização está correta. Um sistema que recomenda os métodos certos mas na ordem errada ainda é problemático.

---

### Spearman ρ parcial

**Em uma frase:** correlação de posição (baseada em ranques) entre o ranking gerado e o esperado, calculada sobre os métodos em comum.

**Como ler:** vai de -1 a 1, com interpretação análoga ao Kendall τ. O Spearman é menos sensível a pequenas inversões locais, enquanto o Kendall penaliza cada par fora de ordem.

**Por que importa aqui:** usado em conjunto com o Kendall para ter uma visão robusta da correlação ordinal — se ambos concordam, a conclusão é mais confiável.

---

## Bootstrap — Intervalos de Confiança (IC 95%)

**Em uma frase:** estimativa do intervalo em que o valor "verdadeiro" da métrica provavelmente estaria se tivéssemos mais dados.

**Como ler:** apresentado como [lower, upper] com 95% de confiança. Por exemplo, acurácia = 0,78 com IC [0,67, 0,89] significa que, com 95% de confiança, o desempenho real está entre 67% e 89%. Intervalos largos indicam alta variabilidade — o dataset pode ser pequeno demais para conclusões definitivas.

**Como é calculado:** o método de bootstrap reamostraliza os casos com reposição 1.000 vezes (semente fixa = 42 para reprodutibilidade), calcula a métrica em cada reamostragem e extrai o 2,5º e 97,5º percentil.

**Por que importa aqui:** com apenas 27 casos sintéticos, as métricas pontuais podem variar bastante por acaso. O IC 95% comunica honestamente essa incerteza em vez de apresentar um número falso de precisão.

---

## Métricas de Estabilidade Linguística

**Em uma frase:** para um mesmo problema (mesmo template), o sistema infere as mesmas premissas independentemente de como o texto foi escrito?

**Como ler:** *concordância entre redações* vai de 0 a 1. Valor 1,0 significa que as 3 redações do template produziram exatamente as mesmas premissas. Valores abaixo de 0,8 indicam que o léxico é sensível à forma de escrever — um problema de robustez.

**Por que importa aqui:** a utilidade prática do sistema depende de que analistas com estilos de escrita diferentes obtenham recomendações comparáveis para o mesmo problema.

---

## Limitações declaradas

1. **Tamanho do dataset:** 27 casos sintéticos (9 templates × 3 redações) é suficiente para validação exploratória, mas insuficiente para conclusões estatísticas definitivas. Os ICs de bootstrap refletem essa incerteza.

2. **Dataset sintético:** os textos foram criados pelos próprios autores para cobrir os templates, não por analistas independentes. Isso pode superestimar o desempenho do NLP (o léxico foi calibrado sobre os mesmos tipos de texto).

3. **Ranking sem curadoria:** `ranking_esperado.csv` está vazio no estado atual do projeto. As métricas de ranking (P@k, nDCG, MRR, Kendall, Spearman) não podem ser calculadas sem preenchimento manual baseado na literatura ou em especialistas.

4. **Premissas ausentes:** algumas premissas (`ambiente_decisao`, `completude_pref`) têm cobertura lexical menor e podem apresentar taxa de não-inferido mais alta. Isso é esperado e documentado.

5. **Ontologia não modificada:** a avaliação valida o *sistema* (NLP + consulta), não a *completude* da ontologia. Métodos ausentes ou propriedades incorretas na ontologia não são detectados por estas métricas.
