# O que foi feito no projeto OntoMCDA

## Ponto de partida

Dois notebooks Jupyter para Google Colab entrelaçados, sem testes, sem reprodutibilidade fora do Colab, com dependências (`google.colab`, `ipywidgets`) que impediam execução local.

---

## O que foi construído

### Fase 1 — Estrutura de projeto

Criação de `pyproject.toml`, `requirements.txt` pinado, venv local, pacote instalável com `pip install -e .`.

### Fase 2 — Migração do pipeline (TDD)

Todo o código dos notebooks foi extraído, limpo e reescrito como pacote Python testável:

| Módulo | Função |
|---|---|
| `nlp/normalize.py` | Normalização de texto PT-BR |
| `nlp/lexicon.py` | Léxico de ~400 termos → premissas |
| `nlp/rules.py` | Regras de desambiguação `tipo_problema` |
| `nlp/inference.py` | Orquestrador: texto → premissas |
| `ontology.py` | Leitor OWL dual-namespace (rdflib) |
| `scoring.py` | Matching + scoring ponderado |
| `pipeline.py` | API pública: `recomendar()`, `batch_recomendar()` |

### Fase 3 — Dataset sintético

9 templates × 3 redações = 27 casos com gabarito de premissas, gerados por código (`python -m ontomcda.dataset`), reproduzíveis.

### Fase 4 — Métricas de avaliação

Suite completa de métricas: accuracy, F1, kappa, matrizes de confusão, P@k, Hit@k, nDCG, MRR, Kendall τ, Spearman ρ, bootstrap IC 95%, estabilidade linguística, export Excel.

### Fase 5 — Notebook de relatório

`notebooks/relatorio_validacao.ipynb` com 10 seções, executável headless, sem dependências Colab.

### Fase 6 — Documentação

- `docs/integracao_modulos.md` — explicação não-técnica com diagrama ASCII
- `docs/metricas.md` — todas as métricas em formato tri-bloco
- `README.md` — setup + 3 comandos de reprodução
- `docs/linha_de_raciocinio.md` — linha argumentativa do modelo

### Fase 7 — Limpeza e tag

Notebooks originais arquivados em `legacy/`, `CLAUDE.md` atualizado, validação end-to-end limpa, tag `v1.0.0`.

---

## Números finais

| Item | Valor |
|---|---|
| Testes automatizados | 64 passando |
| Métodos MCDA na ontologia | 123 |
| Casos de validação | 27 |
| Lint (`ruff check .`) | limpo |
| `.owl` modificado | não |
| Dependências Colab | zero |

---

## Arquitetura do pipeline

```
  ┌─────────────┐       ┌──────────────┐       ┌───────────────┐       ┌─────────────┐
  │    TEXTO    │──────▶│  INFERÊNCIA  │──────▶│   CONSULTA    │──────▶│   RANKING   │
  │  (PT-BR)   │       │    (NLP)     │       │  (ONTOLOGIA)  │       │  (TOP-K)    │
  └─────────────┘       └──────────────┘       └───────────────┘       └─────────────┘
```

1. **Texto** — descrição livre do problema de decisão em português
2. **Inferência NLP** — léxico + regras mapeiam o texto para premissas (ex: `tipo_problema = Escolha`)
3. **Consulta à ontologia** — perfis dos 123 métodos MCDA são comparados com as premissas inferidas
4. **Ranking** — métodos ordenados por pontuação de compatibilidade ponderada; retorna top-k aceitos e rejeitados

---

## Resultados da execução sobre os 27 casos

### Métricas PLN por atributo

| Atributo | Accuracy | F1 Macro | Kappa | Inferidos |
|---|---|---|---|---|
| `tipo_problema` | 1.00 ✅ | 1.00 | 1.00 | 27/27 |
| `estrutura_decisoria` | 1.00 ✅ | 1.00 | 1.00 | 27/27 |
| `ambiente_decisao` | 1.00 ✅ | 1.00 | 1.00 | 27/27 |
| `tipo_variavel` | 0.96 ✅ | 0.96 | 0.94 | 27/27 |
| `compensatoriedade` | 0.69 ⚠️ | 0.69 | 0.55 | 26/27 |
| `completude_pref` | 1.00 ✅ | 1.00 | 1.00 | 11/27 ⚠️ |
| `ponderabilidade` | 1.00 ✅ | 1.00 | — | 8/27 ⚠️ |
| `monotonicidade` | 0.00 ❌ | 0.00 | — | 1/27 ❌ |

### Bootstrap IC 95% (accuracy)

| Atributo | Média | IC 95% |
|---|---|---|
| `tipo_problema` | 1.000 | [1.000, 1.000] |
| `estrutura_decisoria` | 1.000 | [1.000, 1.000] |
| `ambiente_decisao` | 1.000 | [1.000, 1.000] |
| `tipo_variavel` | 0.964 | [0.889, 1.000] |
| `compensatoriedade` | 0.666 | [0.481, 0.815] |
| `completude_pref` | 0.409 | [0.222, 0.593] |
| `ponderabilidade` | 0.295 | [0.148, 0.444] |
| `monotonicidade` | 0.000 | [0.000, 0.000] |

> ICs largos em `completude_pref` e `ponderabilidade` refletem o pequeno número de casos inferidos, não erros de classificação.

### Taxa de não-inferido

| Atributo | Taxa |
|---|---|
| `monotonicidade` | 96% — léxico sem cobertura |
| `ponderabilidade` | 70% — só inferido quando texto menciona pesos |
| `completude_pref` | 59% — só inferido com menção explícita a preferências |
| `compensatoriedade` | 4% — cobertura quase total |

### Estabilidade linguística por template

| Template | Concordância |
|---|---|
| T01 escolha cardinal individual | 1.00 ✅ |
| T04 ordenacao cardinal individual | 1.00 ✅ |
| T07 classificacao cardinal individual | 1.00 ✅ |
| T05 ordenacao mista grupo | 0.96 ✅ |
| T02 escolha mista grupo | 0.96 ✅ |
| T09 classificacao ordinal individual | 0.96 ✅ |
| T03 escolha ordinal grupo | 0.94 ✅ |
| T06 ordenacao ordinal grupo | 0.94 ✅ |
| T08 classificacao mista grupo | 0.92 ✅ |

Todos os templates acima de 0.91 — o modelo é consistente independente de como o texto foi escrito.

---

## Análise de qualidade

### O modelo funciona bem para

- **`tipo_problema`** — regras explícitas de desambiguação + léxico rico → perfeito nos 27 casos
- **`tipo_variavel`** — termos técnicos distintos (quantitativo, ordinal, mista) → 96% de acerto
- **`estrutura_decisoria`** — sinais claros no texto (comitê, grupo, um decisor) → perfeito
- **`ambiente_decisao`** — expressões de certeza/incerteza bem cobertas → perfeito

### O modelo é mais fraco em

- **`compensatoriedade`** — vocabulário técnico ambíguo em PT-BR; o modelo confunde `NaoCompensatorio` e `ParcialmenteCompensatorio` com `Compensatorio`
- **`monotonicidade`** — praticamente não inferido; textos naturais raramente mencionam monotonicidade explicitamente
- **`ponderabilidade` e `completude_pref`** — inferidos com precisão quando o texto os menciona, mas a maioria dos textos não os menciona → alto não-inferido

---

## Limitações declaradas

1. **Dataset sintético** — 27 casos criados pelos próprios autores, calibrados com o léxico; tende a superestimar a qualidade real do NLP
2. **Ranking não validado** — `ranking_esperado.csv` está vazio; as métricas de ranking (P@k, nDCG, MRR) não foram calculadas
3. **Léxico em vez de ML** — cobertura depende de curadoria manual; não generaliza para sinônimos não cadastrados
4. **Ontologia não modificada** — erros ou lacunas nos perfis dos 123 métodos não são detectados por esta validação

---

## Próximos passos recomendados

- Preencher `data/ranking_esperado.csv` com ao menos 5–10 casos baseados na literatura MCDA clássica
- Expandir o léxico de `monotonicidade` e `compensatoriedade` com mais sinônimos em PT-BR
- Coletar redações de avaliadores externos para validar a estabilidade fora do conjunto de autores
