# OntoMCDA — Status da Implementação

**Última atualização:** 2026-04-22  
**Branch:** master  
**Último commit:** `38f832b` — fix: apply Phase 4 review corrections  
**Testes:** 64 passando

---

## O que foi feito

### Phase 1 — Bootstrap ✅
- `.gitignore`, `pyproject.toml`, `requirements.txt`, `requirements-dev.txt`
- `src/ontomcda/__init__.py`
- `.venv` criado com todas as dependências instaladas

### Phase 2 — Pipeline NLP + Ontologia ✅
| Módulo | Arquivo |
|--------|---------|
| Constantes | `src/ontomcda/config.py` |
| Normalização de texto | `src/ontomcda/nlp/normalize.py` |
| Léxico PT-BR | `src/ontomcda/nlp/lexicon.py` |
| Regras tipo_problema | `src/ontomcda/nlp/rules.py` |
| Orquestrador de inferência | `src/ontomcda/nlp/inference.py` |
| Loader OWL dual-namespace | `src/ontomcda/ontology.py` |
| Matching e scoring | `src/ontomcda/scoring.py` |
| API pública | `src/ontomcda/pipeline.py` + `__init__.py` |

Code review Phase 2 aplicado (commit `76b7a07`).

### Phase 3 — Dataset ✅
| Módulo | Arquivo |
|--------|---------|
| 9 templates sintéticos | `src/ontomcda/dataset/templates.py` |
| Gerador de CSVs | `src/ontomcda/dataset/generator.py` |
| CLI | `src/ontomcda/dataset/__main__.py` |
| Dados gerados | `data/casos.csv`, `data/gabarito_premissas.csv`, `data/ranking_esperado.csv`, `data/templates.json` |

Code review Phase 3 aplicado (commit `5250cc0`). Templates revisados para incluir triggers explícitos de `ambiente_decisao` e `completude_pref`. Teste de round-trip adicionado (tipo_problema correto em todas as 27 redações).

### Phase 4 — Métricas de avaliação ✅
| Módulo | Arquivo |
|--------|---------|
| PLN (accuracy, F1, kappa, confusão) | `src/ontomcda/evaluation/pln.py` |
| Ranking (P@k, Hit@k, nDCG, MRR, Kendall, Spearman) | `src/ontomcda/evaluation/ranking.py` |
| Bootstrap IC 95% | `src/ontomcda/evaluation/bootstrap.py` |
| Relatório por template + xlsx | `src/ontomcda/evaluation/report.py` |
| CLI | `src/ontomcda/evaluation/__main__.py` |

Code review Phase 4 aplicado (commit `38f832b`).

---

## O que falta fazer

### Phase 5 — Notebook de relatório (Task 20)

Criar `notebooks/relatorio_validacao.ipynb` com 10 seções:
1. Setup/imports
2. Carregar ontologia e dataset
3. Rodar pipeline (`batch_recomendar`)
4. Métricas PLN por atributo
5. PLN per-class + matrizes de confusão
6. Ranking (condicional)
7. Bootstrap IC 95%
8. Desempenho por template
9. Estabilidade linguística
10. Export consolidado (`exportar_excel`)

Criar também `scripts/build_notebook.py` para gerar o `.ipynb` via Python (garante JSON válido).

Verificar execução headless:
```bash
jupyter nbconvert --to notebook --execute notebooks/relatorio_validacao.ipynb --output relatorio_validacao_executed.ipynb
```

### Phase 6 — Documentação (Tasks 21–23)

**Task 21** — `docs/integracao_modulos.md`
- Diagrama ASCII do fluxo em 4 etapas (texto → inferência → ontologia → ranking)
- Analogias não-técnicas (médico, livro)
- Glossário mínimo

**Task 22** — `docs/metricas.md`
- Para cada métrica: "Em uma frase", "Como ler", "Por que importa aqui"
- Seção "Limitações declaradas"
- Cobre: accuracy, F1 macro/micro, kappa, taxa não-inferido, P@k, Hit@k, nDCG@k, MRR, Kendall τ, Spearman ρ, bootstrap IC, estabilidade linguística

**Task 23** — `README.md`
- Setup com venv
- Reprodução da validação (3 comandos)
- Uso programático
- Comandos de teste

### Phase 7 — Cleanup e tag (Tasks 24–25)

**Task 24**
```bash
mkdir legacy
git mv OntoMCDA_final.ipynb legacy/
git mv "OntoMCDA_metrica PLN.ipynb" legacy/
```
Atualizar `CLAUDE.md` para refletir nova arquitetura.

**Task 25** — Validação final end-to-end
```bash
# Clean reproduction
deactivate 2>/dev/null
rm -rf .venv outputs
python -m venv .venv
source .venv/Scripts/activate
pip install -r requirements.txt -e .
python -m ontomcda.dataset
python -m ontomcda.evaluation
pytest -v
ruff check .
jupyter nbconvert --to notebook --execute notebooks/relatorio_validacao.ipynb --output relatorio_validacao_executed.ipynb
rm notebooks/relatorio_validacao_executed.ipynb
git tag -a v1.0.0 -m "Refactored package with venv, tests, dataset templates, and refined metrics"
```
Seguido de code review final com `superpowers:requesting-code-review`.

---

## Estrutura atual do projeto

```
src/ontomcda/
  __init__.py          ← expõe recomendar, batch_recomendar, load_profiles
  config.py
  ontology.py
  pipeline.py
  scoring.py
  nlp/
    __init__.py
    normalize.py
    lexicon.py
    rules.py
    inference.py
  dataset/
    __init__.py
    templates.py       ← 9 templates, 3 redações cada
    generator.py
    __main__.py        ← python -m ontomcda.dataset
  evaluation/
    __init__.py
    pln.py
    ranking.py
    bootstrap.py
    report.py
    __main__.py        ← python -m ontomcda.evaluation

data/
  casos.csv            ← 27 casos gerados
  gabarito_premissas.csv
  ranking_esperado.csv ← vazio; preencher com curadoria
  templates.json

tests/
  conftest.py          ← fixture session-scoped profiles
  test_nlp_normalize.py
  test_nlp_rules.py
  test_nlp_inference.py
  test_ontology.py
  test_pipeline.py
  test_scoring.py
  test_dataset_generator.py
  test_evaluation_pln.py
  test_evaluation_ranking.py
  test_evaluation_bootstrap.py
  test_evaluation_report.py
```

---

## Comandos principais

```bash
# Ativar venv (Windows bash)
source .venv/Scripts/activate

# Rodar todos os testes
.venv/Scripts/python -m pytest -v

# Gerar dataset
.venv/Scripts/python -m ontomcda.dataset

# Gerar relatório xlsx
.venv/Scripts/python -m ontomcda.evaluation

# Smoke test rápido
.venv/Scripts/python -c "from ontomcda import load_profiles, recomendar; p = load_profiles('OntoMCDA_final.owl'); r = recomendar('Um analista precisa escolher o melhor fornecedor com criterios quantitativos.', p, top_k=5); print(list(r['aceitos']['metodo']))"

# Lint
.venv/Scripts/python -m ruff check .
```

---

## Notas importantes para o próximo chat

- O `.venv` está em `C:\Users\David\Documents\POLI\Ontologia_david\.venv`
- O notebook precisa de `OWL_PATH = '../OntoMCDA_final.owl'` (relativo a `notebooks/`)
- `ranking_esperado.csv` está vazio de propósito — David preenche com curadoria da literatura MCDA
- Warnings de kappa (`RuntimeWarning: invalid value encountered in scalar divide`) são esperados para classes com apenas uma amostra — estão suprimidos no código
- O plano completo está em `docs/plans/2026-04-22-ontomcda-validation-plan.md`
- O design doc está em `docs/plans/2026-04-22-ontomcda-validation-design.md`
