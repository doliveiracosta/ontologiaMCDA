# Integração dos Módulos — OntoMCDA

## O que o sistema faz

O OntoMCDA lê uma descrição em português de um problema de decisão e devolve uma lista ordenada de métodos MCDA (como AHP, TOPSIS, ELECTRE) cujo perfil na ontologia melhor combina com as características do problema.

---

## Fluxo em 4 etapas

```
  ┌─────────────┐       ┌──────────────┐       ┌───────────────┐       ┌─────────────┐
  │    TEXTO    │──────▶│  INFERÊNCIA  │──────▶│   CONSULTA    │──────▶│   RANKING   │
  │  (PT-BR)   │       │    (NLP)     │       │  (ONTOLOGIA)  │       │  (TOP-K)    │
  └─────────────┘       └──────────────┘       └───────────────┘       └─────────────┘
                               │                       │
                               ▼                       ▼
                          premissas             perfis dos ~100
                          inferidas             métodos MCDA na
                          do texto              ontologia OWL
                          (ex: tipo             (AHP, TOPSIS,
                          do problema,          VIKOR, ELECTRE,
                          tipo de               PROMETHEE, ...)
                          variável,
                          estrutura de
                          decisão, ...)
```

---

## Etapa 1 — Texto de entrada

O sistema recebe qualquer texto em português descrevendo um problema de decisão. Não há formulário nem perguntas — o analista escreve em linguagem natural, como faria num relatório.

**Exemplos válidos:**
- *"Um comitê precisa ordenar projetos de investimento por prioridade. Os critérios são quantitativos e qualitativos."*
- *"Um auditor sozinho deve classificar fornecedores em categorias pré-definidas com base em avaliações subjetivas."*

---

## Etapa 2 — Inferência (NLP)

**Analogia do médico:** assim como um médico lê os sintomas do paciente e mapeia cada um para um diagnóstico possível ("febre alta + tosse → suspeita de gripe"), o módulo de inferência lê o texto e mapeia expressões para *premissas* do problema.

Cada premissa é uma propriedade estrutural do problema:

| Premissa | O que captura | Exemplo de valor |
|---|---|---|
| `tipo_problema` | O que se quer fazer com as alternativas | Escolha, Ordenacao, Classificacao |
| `tipo_variavel` | Natureza dos dados dos critérios | Cardinal, Ordinal, Mista |
| `estrutura_decisoria` | Quem decide | Individual, Grupo |
| `compensatoriedade` | Se critérios ruins compensam os bons | Compensatorio, NaoCompensatorio |
| `completude_pref` | O decisor sabe todas as suas preferências? | Completo, Incompleto |
| `ambiente_decisao` | Há incerteza nos dados? | Certeza, Incerteza, Risco |
| `ponderabilidade` | Os critérios têm pesos? | Ponderavel, NaoPonderavel |
| `usa_pesos` | O método usa pesos? | Sim, Nao |

O mecanismo usa um **léxico** (lista de palavras e frases em português associadas a cada valor) e **regras** de desambiguação quando o texto é ambíguo.

Módulos envolvidos: `src/ontomcda/nlp/`

---

## Etapa 3 — Consulta à ontologia

**Analogia do livro de referência:** a ontologia é como um catálogo técnico onde cada método MCDA tem uma ficha com suas características. A etapa de consulta compara as premissas inferidas com cada ficha e atribui uma pontuação de compatibilidade.

A pontuação leva em conta:
- **Peso de cada premissa** — `tipo_problema` vale mais que `ponderabilidade`, por exemplo.
- **Compatibilidade não-exata** — um método que aceita variáveis *Mistas* também aceita problemas com variáveis *Cardinais* (regra de subsunção).
- **Método aceito vs. rejeitado** — um método é rejeitado se contradiz uma premissa obrigatória.

A ontologia (`OntoMCDA_final.owl`) contém ~100 métodos MCDA como indivíduos OWL. Cada indivíduo tem propriedades que descrevem seu perfil (e.g. `temTipoDeProblema`, `temCompensatoriedade`).

Módulos envolvidos: `src/ontomcda/ontology.py`, `src/ontomcda/scoring.py`

---

## Etapa 4 — Ranking

Os métodos aceitos são ordenados pela pontuação de compatibilidade. O sistema devolve os `top_k` mais compatíveis (padrão: 15), junto com os rejeitados e as premissas que não puderam ser inferidas.

O resultado final é um dicionário com:
- `premissas` — o que foi inferido do texto
- `aceitos` — tabela dos métodos recomendados, com pontuação
- `rejeitados` — métodos incompatíveis e o motivo
- `faltantes` — premissas obrigatórias não encontradas no texto

---

## Os três papéis do código

```
src/ontomcda/
  ├── nlp/          ← Inferência: texto → premissas
  ├── ontology.py   ← Leitura da ontologia OWL
  ├── scoring.py    ← Comparação e pontuação
  ├── pipeline.py   ← API pública: recomendar(), batch_recomendar()
  ├── dataset/      ← Geração de casos sintéticos para avaliação
  └── evaluation/   ← Métricas (PLN + ranking + bootstrap + relatório)
```

O módulo `dataset/` gera casos de teste a partir de *templates* com perfis conhecidos — ele não usa o pipeline para gerar as respostas, apenas as entradas. O módulo `evaluation/` usa tanto o pipeline quanto os casos gerados para medir o desempenho.

---

## Como isso valida a ontologia indiretamente

O sistema não avalia a ontologia diretamente (não usa um *reasoner* formal). Em vez disso, a validação é *indireta*:

1. Criamos casos com premissas conhecidas (gabarito).
2. O pipeline infere premissas a partir do texto.
3. Comparamos o que o pipeline inferiu com o gabarito — isso mede o NLP.
4. (Quando disponível) comparamos o ranking gerado com rankings de especialistas — isso mede se a ontologia "pensa" como um especialista.

Se o NLP infere corretamente e o ranking concorda com especialistas, a ontologia captura bem o conhecimento do domínio.

---

## Glossário mínimo

| Termo | Significado |
|---|---|
| **MCDA** | *Multi-Criteria Decision Aid* — família de métodos para decisões com múltiplos critérios |
| **Ontologia OWL** | Base de conhecimento formal; aqui, um catálogo estruturado de ~100 métodos MCDA com suas propriedades |
| **Premissa** | Característica estrutural do problema de decisão (ex: "os dados são numéricos") |
| **Léxico** | Lista de palavras e frases em português associadas a cada valor de premissa |
| **Top-k** | Os k métodos com maior pontuação de compatibilidade |
| **Bootstrap** | Técnica estatística para estimar intervalos de confiança reamostrado os dados |
| **Template** | Caso sintético de teste com premissas conhecidas, usado para avaliar o NLP |
