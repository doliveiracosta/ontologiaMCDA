# Design — Refatoração e validação acadêmica do OntoMCDA

**Data**: 2026-04-22
**Autor**: David (com Claude)
**Status**: Aprovado, pronto para plano de implementação

## Contexto e objetivo

Projeto recebido de terceiro. Consiste em:
- `OntoMCDA_final.owl` — ontologia RDF/XML com ~100+ métodos MCDA (intocável neste trabalho).
- `OntoMCDA_final.ipynb` — pipeline NLP + consulta à ontologia em um notebook Colab com widgets.
- `OntoMCDA_metrica PLN.ipynb` — avaliação com 3 casos inline, duplicando parte da lógica do primeiro notebook.

**Objetivo**: validação acadêmica (TCC/dissertação/artigo). Entregas:
1. Refinar dados e métricas de avaliação.
2. Separar dataset do escopo de avaliação.
3. Ajustar script/pipeline de validação.
4. Enxugar o projeto (só em Python; OWL fica intacta).
5. Propor métricas impactantes para o pipeline (camada NLP + ranking).
6. Criar venv + `requirements.txt`.
7. Documentar em Markdown para perfil não-técnico.

## Decisões de escopo

| Dimensão | Decisão |
|---|---|
| Formato do código | Pacote Python `src/ontomcda/` + **um** notebook de relatório |
| Target runtime | Local, Python 3.11, venv padrão; sem Colab |
| Dataset | Expandir via **templates controlados**; ~9 templates × 3–5 redações ≈ 36 casos |
| Gabarito de premissas | Derivado **automaticamente** do template (gold por construção) |
| Gabarito de ranking | `ranking_esperado.csv` gerado vazio; usuário preenche com curadoria baseada na literatura MCDA |
| Foco das métricas | Refinar pipeline NLP + ranking (não métricas estruturais da ontologia nem competency questions) |
| Ontologia OWL | **Intocada** — dual-namespace mantido |
| Enxugar | Consolidar dois notebooks em um; remover `google.colab` + `ipywidgets`; unificar inferência |
| Testes | `pytest`, 4 arquivos, rede de segurança (não coverage exaustivo) |
| CI / Docker | Fora de escopo (projeto acadêmico local) |

## Arquitetura

### Estrutura de diretórios

```
ontomcda/
├── OntoMCDA_final.owl              # intocada
├── requirements.txt
├── requirements-dev.txt
├── pyproject.toml
├── README.md
│
├── src/ontomcda/
│   ├── __init__.py                 # expõe API pública
│   ├── config.py                   # ATTRS, ATTR_WEIGHTS, NEW_NS, OLD_NS, MANDATORY_QUERY_ATTRS
│   ├── ontology.py                 # load_profiles, get_method_instances (dual-namespace)
│   ├── pipeline.py                 # recomendar(texto) — API principal
│   ├── scoring.py                  # tipo_variavel_match, ontology_match, consult_ontology
│   │
│   ├── nlp/
│   │   ├── __init__.py
│   │   ├── normalize.py            # norm_txt, canon_value, strip_accents
│   │   ├── lexicon.py              # LEX, ATTR_TO_PROP
│   │   ├── rules.py                # infer_tipo_problema_por_regras
│   │   └── inference.py            # infer_attr, infer_premissas
│   │
│   ├── dataset/
│   │   ├── __init__.py
│   │   ├── templates.py            # 9 templates base + 3–5 redações cada
│   │   ├── generator.py            # gerar_casos() → 4 DataFrames
│   │   └── __main__.py             # CLI: python -m ontomcda.dataset
│   │
│   └── evaluation/
│       ├── __init__.py
│       ├── pln.py                  # per-class P/R/F1, matriz confusão, κ
│       ├── ranking.py              # P@k, Hit@k, nDCG@k, MRR, Kendall τ, Spearman
│       ├── bootstrap.py            # IC 95%, seed fixa
│       ├── report.py               # consolidação + export xlsx
│       └── __main__.py             # CLI: python -m ontomcda.evaluation
│
├── data/                            # versionado
│   ├── casos.csv
│   ├── gabarito_premissas.csv
│   ├── ranking_esperado.csv
│   └── templates.json
│
├── notebooks/
│   └── relatorio_validacao.ipynb   # único notebook; importa do pacote
│
├── tests/
│   ├── test_nlp_inference.py
│   ├── test_ontology_load.py
│   ├── test_scoring.py
│   └── test_evaluation_metrics.py
│
└── docs/
    ├── plans/
    │   └── 2026-04-22-ontomcda-validation-design.md
    ├── integracao_modulos.md       # não-técnico: visão geral do sistema (com diagrama ASCII)
    └── metricas.md                 # não-técnico: o que cada métrica significa
```

### Princípios de divisão

- **Tabelas isoladas de lógica**: `config.py` e `nlp/lexicon.py` concentram todos os dicts/listas editáveis.
- **Um pipeline, uma versão**: eliminação da duplicação entre os dois notebooks antigos; `OntoMCDA_metrica PLN.ipynb` é totalmente substituído.
- **Dataset reprodutível**: `data/` gerado por código, versionado.
- **OWL preservada**: `ontology.py` replica o comportamento dual-namespace atual.

## Dataset — templates controlados

### Modelo de um template

```python
Template(
    id="T01_escolha_cardinal_individual",
    premissas={
        "tipo_problema": "Escolha",
        "tipo_variavel": "Cardinal",
        "estrutura_decisoria": "Individual",
        "compensatoriedade": "Compensatorio",
        "monotonicidade": "Monotonico",
        "completude_pref": "Completo",
        "ambiente_decisao": "Certeza",
        "ponderabilidade": "Ponderavel",
        "usa_pesos": "Sim",
        "requer_pesos": "Sim",
    },
    redacoes=[...],  # 3 a 5 strings PT-BR
)
```

### 9 templates base (arranjo ortogonal)

| ID  | tipo_problema | tipo_variavel | estrutura  | compensatoriedade        | completude |
|-----|----------------|----------------|------------|---------------------------|-------------|
| T01 | Escolha        | Cardinal       | Individual | Compensatório             | Completo    |
| T02 | Escolha        | Mista          | Grupo      | Parcialmente compensatório | Incompleto  |
| T03 | Escolha        | Ordinal        | Grupo      | Não compensatório         | Incompleto  |
| T04 | Ordenação      | Cardinal       | Individual | Compensatório             | Completo    |
| T05 | Ordenação      | Mista          | Grupo      | Parcialmente compensatório | Incompleto  |
| T06 | Ordenação      | Ordinal        | Grupo      | Não compensatório         | Incompleto  |
| T07 | Classificação  | Cardinal       | Individual | Compensatório             | Completo    |
| T08 | Classificação  | Mista          | Grupo      | Parcialmente compensatório | Incompleto  |
| T09 | Classificação  | Ordinal        | Individual | Não compensatório         | Completo    |

Os 3 casos inline antigos viram redações dentro de T01/T04/T02.

### CSVs gerados

- **`casos.csv`**: `id, template_id, redacao_idx, texto`
- **`gabarito_premissas.csv`**: derivado automaticamente do template (gold por construção)
- **`ranking_esperado.csv`**: `id, relevantes` — gerado **vazio**, usuário preenche
- **`templates.json`**: manifesto dos templates (apêndice da tese)

### Comportamento do avaliador quando `ranking_esperado` está vazio

Reporta só métricas de PLN, avisa explicitamente: "ranking não avaliado — gabarito ausente".

## Métricas

Organizadas em três camadas; cada métrica responde a uma pergunta específica.

### Camada 1 — PLN (inferência de premissas)

| Métrica | Status | Finalidade |
|---|---|---|
| Accuracy por atributo | Já existe | Visão rápida por dimensão |
| Precision / Recall / F1 por classe | **Novo** | Desbalanço de valores dentro de um atributo |
| Macro-F1 e Micro-F1 por atributo | **Novo** | Honestidade com classes raras vs. frequentes |
| Matriz de confusão por atributo | **Novo** | Revela onde o sistema confunde valores |
| Cohen's κ por atributo | **Novo** | Concordância descontando o acaso |
| Taxa de `não inferido` | **Novo** | Distingue erro de classificação de lacuna de cobertura |

### Camada 2 — Ranking (recomendação)

Condicional ao preenchimento de `ranking_esperado.csv`.

| Métrica | Status | Finalidade |
|---|---|---|
| P@k (k=3, 5, 10) | Já existe | Precisão dos top-k |
| Hit@k | Já existe | Há pelo menos um relevante no top-k? |
| nDCG@k | Já existe | Recompensa relevantes mais altos |
| MRR | **Novo** | Quão cedo aparece o primeiro relevante |
| Kendall τ parcial | **Novo** | Correlação entre ordens |
| Spearman ρ | **Novo** | Alternativa/complemento a Kendall |

### Camada 3 — Robustez

| Métrica | Status | Finalidade |
|---|---|---|
| Bootstrap IC 95% | **Novo, essencial** | Intervalos confiáveis com amostra pequena |
| Variância entre redações do mesmo template | **Novo** | Estabilidade linguística |
| Desempenho por template | **Novo** | Perfis difíceis orientam trabalho futuro |

### Saída

`outputs/relatorio.xlsx` com abas: `resumo`, `pln_por_atributo`, `confusao_<atributo>`, `ranking_por_caso`, `por_template`, `bootstrap`.

### Fora de escopo (confirmado na brainstorming)

- BLEU/ROUGE (output é categórico, não texto livre)
- AUC-ROC (saídas são multi-classe categóricas)
- Métricas estruturais da ontologia (profundidade, densidade, axiomas)
- Competency questions
- Reasoner (consistência lógica)

## Notebook `relatorio_validacao.ipynb`

### 10 blocos de células

1. Setup e imports
2. Carregar ontologia e dataset
3. Rodar pipeline em todos os casos (`batch_recomendar`)
4. Camada PLN — métricas por atributo
5. Camada PLN — per-class e matrizes de confusão (heatmaps)
6. Camada ranking (condicional ao `ranking_esperado`)
7. Camada robustez — bootstrap
8. Análise por template
9. Análise de estabilidade linguística
10. Export consolidado (`relatorio.xlsx`)

### Contrato

- Zero lógica nova: cada célula é 1–3 linhas que chamam o pacote.
- Reexecução idempotente (seed fixa = 42).
- Células independentes: falha numa não trava as anteriores.
- Gráficos com `dpi=300`, salvos em `outputs/figs/` pelo `report.py`.
- **Sem** `google.colab`, **sem** `ipywidgets`.

## Documentação para perfil não-técnico

Dois arquivos separados em `docs/`.

### `docs/integracao_modulos.md` (~2–3 páginas)

Público: orientador, banca, colegas não-técnicos.
Tom: analogia + diagrama ASCII + zero jargão sem explicação.

Seções:
- O que o sistema faz (uma frase)
- O fluxo em 4 etapas (com diagrama ASCII)
- Etapa 1: Texto de entrada
- Etapa 2: Inferência NLP (analogia do médico lendo sintomas)
- Etapa 3: Consulta à ontologia (analogia do livro de referência)
- Etapa 4: Ranking e recomendação
- Os três papéis do código (pipeline, dataset, avaliação)
- Como isso valida a ontologia (indiretamente)
- Glossário mínimo

### `docs/metricas.md` (~4–5 páginas)

Público: leitor do capítulo de avaliação da tese.
Formato por métrica: **uma frase** (o que mede) + **como ler** (faixas) + **por que importa aqui**.

Seções:
- Por que não basta "acertou ou errou"
- Camada 1 — inferência das premissas (accuracy, P/R, F1, matriz confusão, κ)
- Camada 2 — o ranking é bom (P@k, Hit@k, nDCG, MRR, Kendall, Spearman)
- Camada 3 — os números são confiáveis (IC bootstrap, estabilidade linguística, por template)
- Como ler a tabela-resumo do `relatorio.xlsx`
- Limitações declaradas (amostra sintética, 36 casos, gabarito de ranking curado pelo autor)

## Ambiente e reprodutibilidade

### Venv e instalação

```bash
python -m venv .venv
source .venv/bin/activate     # ou .venv\Scripts\activate no Windows
pip install -r requirements.txt
pip install -e .
```

### `requirements.txt` (pinado `==`)

```
owlready2==0.46
rdflib==7.0.0
pandas==2.1.4
numpy==1.26.3
unidecode==1.3.8
openpyxl==3.1.2
scipy==1.11.4
scikit-learn==1.3.2
matplotlib==3.8.2
seaborn==0.13.1
jupyter==1.0.0
ipykernel==6.28.0
```

### `requirements-dev.txt`

```
-r requirements.txt
pytest==7.4.4
pytest-cov==4.1.0
ruff==0.1.11
```

### `pyproject.toml`

- `[build-system]` setuptools moderno
- `[project]` name = "ontomcda", version = "1.0.0", requires-python ">=3.11"
- `[tool.setuptools.packages.find] where = ["src"]`
- `[tool.pytest.ini_options] testpaths = ["tests"]`
- `[tool.ruff]` line-length 100, target-version py311

### Testes (4 arquivos, < 5s total)

- `test_nlp_inference.py` — um texto por template simplificado, assert em premissas-chave
- `test_ontology_load.py` — smoke test: OWL carrega, métodos conhecidos presentes, dual-namespace ok
- `test_scoring.py` — casos canônicos do matcher (Mista×Cardinal, ParcialmenteCompensatorio×Compensatorio, aliases de estrutura_decisoria)
- `test_evaluation_metrics.py` — reprodutibilidade do bootstrap com seed, sanidade das fórmulas

### Lint

`ruff check .` + `ruff format .`

### Reprodução em um fluxo

```bash
# 1. ambiente
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt -e .

# 2. regenerar dataset
python -m ontomcda.dataset

# 3. avaliação completa
python -m ontomcda.evaluation

# 4. abrir notebook com plots
jupyter lab notebooks/relatorio_validacao.ipynb
```

## Fora de escopo deste trabalho

- Alterações na ontologia `OntoMCDA_final.owl`
- Limpeza do namespace legado (`OLD_NS`)
- Redução do catálogo de métodos MCDA
- Métricas estruturais da ontologia / competency questions / reasoner
- CI online (GitHub Actions)
- Containerização (Docker)
- Pre-commit hooks
- UI interativa (widgets) — pode virar `notebooks/demo_interativa.ipynb` depois, sem bloqueio

## Próximo passo

Invocar a skill `superpowers:writing-plans` para transformar este design em um plano de implementação detalhado (ordem de tarefas, critérios de conclusão por etapa, checkpoints de revisão).
