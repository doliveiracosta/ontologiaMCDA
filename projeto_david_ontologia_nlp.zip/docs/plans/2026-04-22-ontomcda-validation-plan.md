# OntoMCDA Validation Refactor — Implementation Plan

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Refactor the OntoMCDA codebase from two tangled Colab notebooks into a testable Python package (`src/ontomcda/`) with a single results notebook, a synthetic-template dataset, a refined metrics suite (NLP + ranking + bootstrap), a venv + pinned `requirements.txt`, and two non-technical markdown docs — all without modifying the `.owl` file.

**Architecture:** `src/ontomcda/` layout (config → ontology → nlp → scoring → pipeline → dataset → evaluation), with tabular data in `data/`, results notebook in `notebooks/relatorio_validacao.ipynb`, and CLIs (`python -m ontomcda.dataset`, `python -m ontomcda.evaluation`). TDD: each non-trivial function gets a failing pytest first. Zero `google.colab`/`ipywidgets` dependencies. Reproducibility via seed-fixed bootstrap and pinned `==` versions.

**Tech Stack:** Python 3.11, `owlready2`, `rdflib`, `pandas`, `numpy`, `scipy`, `scikit-learn`, `matplotlib`, `seaborn`, `openpyxl`, `pytest`, `ruff`. venv (stdlib), `pyproject.toml` build.

**Design doc:** `docs/plans/2026-04-22-ontomcda-validation-design.md` (approved source of truth).

**Source material** (old notebooks — migrate then delete):
- `OntoMCDA_final.ipynb` — NLP + ontology query logic lives in cells at file lines **518** (imports/constants) and **756** (functions `norm_txt`, `canon_value`, `infer_attr`, `infer_premissas`, `load_profiles`, `ontology_match`, `consult_ontology`, `recomendar`).
- `OntoMCDA_metrica PLN.ipynb` — evaluation logic in cell 2 (`strip_accents`, `run_pipeline`, `precision_recall_f1_per_premise`, `precision_at_k`, `hit_at_k`, `ndcg_at_k`, `topk_overlap`, `evaluate_ranking_case`).

Use `python -c "import json; nb = json.load(open('FILE.ipynb')); print(''.join(nb['cells'][N]['source']))"` to extract a cell cleanly.

---

## Phase 1 — Project bootstrap

### Task 1: Initialize git and create the core structure

**Files:**
- Create: `.gitignore`
- Create: `pyproject.toml`
- Create: `requirements.txt`
- Create: `requirements-dev.txt`
- Create: `src/ontomcda/__init__.py` (empty placeholder)

**Step 1: Initialize git**

Run:
```bash
git init
git config user.email "davfb.ferreira@gmail.com"
git config user.name "David"
```

**Step 2: Write `.gitignore`**

```gitignore
.venv/
__pycache__/
*.pyc
.pytest_cache/
.ruff_cache/
.ipynb_checkpoints/
outputs/
*.egg-info/
build/
dist/
.DS_Store
```

**Step 3: Write `requirements.txt` (runtime, pinned)**

```
owlready2==0.46
rdflib==7.0.0
pandas==2.1.4
numpy==1.26.3
unidecode==1.3.8
openpyxl==3.1.2
scipy==1.11.4
scikit-learn==1.3.2
matplotlib==3.8.2
seaborn==0.13.1
jupyter==1.0.0
ipykernel==6.28.0
```

**Step 4: Write `requirements-dev.txt`**

```
-r requirements.txt
pytest==7.4.4
pytest-cov==4.1.0
ruff==0.1.11
```

**Step 5: Write `pyproject.toml`**

```toml
[build-system]
requires = ["setuptools>=68"]
build-backend = "setuptools.build_meta"

[project]
name = "ontomcda"
version = "1.0.0"
description = "Ontology-driven MCDA method recommender with NLP-based premise inference"
requires-python = ">=3.11"
readme = "README.md"

[tool.setuptools.packages.find]
where = ["src"]

[tool.pytest.ini_options]
testpaths = ["tests"]
addopts = "-ra --strict-markers"

[tool.ruff]
line-length = 100
target-version = "py311"
exclude = [".venv", "notebooks", "legacy"]

[tool.ruff.lint]
select = ["E", "F", "I", "W", "UP"]
```

**Step 6: Create placeholder `src/ontomcda/__init__.py`**

```python
"""OntoMCDA — ontology-driven MCDA method recommender."""
__version__ = "1.0.0"
```

**Step 7: Commit the scaffold and the design doc**

```bash
git add .gitignore pyproject.toml requirements.txt requirements-dev.txt src/ontomcda/__init__.py docs/plans/
git add CLAUDE.md OntoMCDA_final.owl OntoMCDA_final.ipynb "OntoMCDA_metrica PLN.ipynb"
git commit -m "chore: initial scaffold with pinned requirements and design docs"
```

---

### Task 2: Create venv and install dependencies

**Step 1: Create and activate venv**

Run (Windows bash):
```bash
python -m venv .venv
source .venv/Scripts/activate
```

**Step 2: Install deps**

```bash
pip install --upgrade pip
pip install -r requirements-dev.txt
pip install -e .
```

**Step 3: Verify imports work**

```bash
python -c "import owlready2, rdflib, pandas, numpy, scipy, sklearn, matplotlib, seaborn, openpyxl, unidecode; import ontomcda; print('ok', ontomcda.__version__)"
```

Expected: `ok 1.0.0`

**Step 4: Verify pytest discovers no tests yet (empty is fine)**

```bash
pytest
```

Expected: `no tests ran in ...` (exit code 5 is expected — empty collection)

No commit yet — venv isn't tracked.

---

## Phase 2 — Core pipeline migration (TDD)

### Task 3: Create `config.py` with constants

**Files:**
- Create: `src/ontomcda/config.py`

**Step 1: Write `config.py`**

```python
"""Shared constants for the OntoMCDA pipeline.

Source of truth for attribute names, ontology namespaces, scoring weights,
and the NLP→ontology attribute mapping. Matches the contract used by the
original notebook so that OntoMCDA_final.owl works unchanged.
"""

NEW_NS = "http://www.ontomcda.org/onto#"
OLD_NS = "http://www.ontomcda.org/onto#OntologyMCDA#"

ATTRS = [
    "tipo_problema",
    "compensatoriedade",
    "tipo_variavel",
    "monotonicidade",
    "estrutura_decisoria",
    "completude_pref",
    "ambiente_decisao",
    "ponderabilidade",
    "usa_pesos",
    "requer_pesos",
    "gera_pesos",
    "auxilia_gerar_pesos",
    "sugere_pesos",
]

DATA_ATTRS = {
    "usa_pesos",
    "requer_pesos",
    "gera_pesos",
    "auxilia_gerar_pesos",
    "sugere_pesos",
}

HIDE_FROM_PREMISSES_PRINT = {
    "gera_pesos",
    "auxilia_gerar_pesos",
    "sugere_pesos",
}

MANDATORY_QUERY_ATTRS = ["tipo_problema"]

ATTR_WEIGHTS = {
    "tipo_problema": 4.0,
    "compensatoriedade": 3.5,
    "tipo_variavel": 3.0,
    "monotonicidade": 2.0,
    "estrutura_decisoria": 2.0,
    "completude_pref": 1.5,
    "ambiente_decisao": 2.0,
    "ponderabilidade": 1.5,
    "usa_pesos": 1.5,
    "requer_pesos": 1.2,
    "gera_pesos": 0.8,
    "auxilia_gerar_pesos": 1.0,
    "sugere_pesos": 0.5,
}

BOOTSTRAP_SEED = 42
BOOTSTRAP_ITERATIONS = 1000
```

**Step 2: Commit**

```bash
git add src/ontomcda/config.py
git commit -m "feat(config): extract pipeline constants to config module"
```

---

### Task 4: `nlp/normalize.py` — text normalization (TDD)

**Files:**
- Create: `tests/__init__.py` (empty)
- Create: `tests/test_nlp_normalize.py`
- Create: `src/ontomcda/nlp/__init__.py` (empty)
- Create: `src/ontomcda/nlp/normalize.py`

**Step 1: Write the failing tests**

`tests/test_nlp_normalize.py`:
```python
from ontomcda.nlp.normalize import norm_txt, canon_value, contains_term, has_negated_expression, local_name


def test_norm_txt_lowercases_and_strips_accents():
    assert norm_txt("Ordenação") == "ordenacao"
    assert norm_txt("CLASSIFICAÇÃO") == "classificacao"


def test_norm_txt_collapses_whitespace():
    assert norm_txt("  foo\t\nbar   baz  ") == "foo bar baz"


def test_contains_term_requires_word_boundary():
    assert contains_term("quero escolher a melhor", "escolher") == 1
    assert contains_term("desescolher o antigo", "escolher") == 0


def test_has_negated_expression_detects_nao():
    assert has_negated_expression("nao se pretende escolher", "escolher") is True
    assert has_negated_expression("se pretende escolher", "escolher") is False


def test_canon_value_maps_accents_and_variants():
    assert canon_value("tipo_problema", "Ordenação") == "Ordenacao"
    assert canon_value("tipo_problema", "Classificação") == "Classificacao"
    assert canon_value("compensatoriedade", "parcialmente compensatório") == "ParcialmenteCompensatorio"


def test_canon_value_none_passes_through():
    assert canon_value("tipo_problema", None) is None


def test_local_name_extracts_fragment():
    from rdflib import URIRef
    uri = URIRef("http://www.ontomcda.org/onto#TOPSIS")
    assert local_name(uri) == "TOPSIS"
```

**Step 2: Run — verify failure**

```bash
pytest tests/test_nlp_normalize.py -v
```

Expected: `ModuleNotFoundError: No module named 'ontomcda.nlp.normalize'`

**Step 3: Create `src/ontomcda/nlp/__init__.py` (empty file)**

Content: `"""NLP layer: lexicon-based premise inference."""`

**Step 4: Implement `src/ontomcda/nlp/normalize.py`**

Extract from `OntoMCDA_final.ipynb` cell at file line 756 (functions `norm_txt`, `canon_value`, `local_name`, `contains_term`, `has_negated_expression`). Cleaned and typed:

```python
"""Text normalization and value canonicalization.

Ported from OntoMCDA_final.ipynb. norm_txt is the entry point that every
other NLP function calls first. canon_value is the bridge between free-text
and ontology value identifiers.
"""
import re
import unicodedata
from typing import Optional

from unidecode import unidecode
from rdflib import URIRef


def norm_txt(s: str) -> str:
    """Lowercase, strip accents, collapse whitespace."""
    if s is None:
        return ""
    s = unidecode(str(s)).lower()
    s = re.sub(r"\s+", " ", s).strip()
    return s


def local_name(uri) -> str:
    """Extract fragment after # or last / from a URI/URIRef."""
    s = str(uri)
    if "#" in s:
        return s.rsplit("#", 1)[-1]
    return s.rsplit("/", 1)[-1]


def contains_term(text_norm: str, term: str) -> int:
    """Return 1 if `term` appears as a whole-word match in `text_norm`."""
    pattern = r"\b" + re.escape(norm_txt(term)) + r"\b"
    return 1 if re.search(pattern, text_norm) else 0


def has_negated_expression(text_norm: str, expr: str) -> bool:
    """Detect 'nao <expr>' / 'não <expr>' immediately preceding expr."""
    pattern = r"\bna[oõ]\s+(?:\w+\s+){0,2}" + re.escape(norm_txt(expr))
    return bool(re.search(pattern, text_norm))


_CANON_MAP = {
    "tipo_problema": {
        "escolha": "Escolha",
        "ordenacao": "Ordenacao",
        "ordenação": "Ordenacao",
        "classificacao": "Classificacao",
        "classificação": "Classificacao",
    },
    "compensatoriedade": {
        "compensatorio": "Compensatorio",
        "compensatório": "Compensatorio",
        "parcialmente compensatorio": "ParcialmenteCompensatorio",
        "parcialmente compensatório": "ParcialmenteCompensatorio",
        "nao compensatorio": "NaoCompensatorio",
        "não compensatório": "NaoCompensatorio",
    },
    "tipo_variavel": {
        "cardinal": "Cardinal",
        "ordinal": "Ordinal",
        "mista": "Mista",
        "pseudocardinal": "PseudoCardinal",
        "cardinal intervalar": "CardinalIntervalar",
        "cardinal fuzzy": "CardinalFuzzy",
        "cardinal grey": "CardinalGrey",
    },
    "monotonicidade": {
        "monotonico": "Monotonico",
        "monotônico": "Monotonico",
        "nao monotonico": "NaoMonotonico",
        "não monotônico": "NaoMonotonico",
        "monotonicidade fraca": "MonotonicidadeFraca",
    },
    "estrutura_decisoria": {
        "individual": "Individual",
        "grupo": "Grupo",
        "coletiva": "Coletiva",
        "monodecisor": "Monodecisor",
        "multidecisor": "Multidecisor",
    },
    "completude_pref": {
        "completo": "Completo",
        "incompleto": "Incompleto",
    },
    "ambiente_decisao": {
        "certeza": "Certeza",
        "incerteza": "Incerteza",
        "risco": "Risco",
    },
    "ponderabilidade": {
        "ponderavel": "Ponderavel",
        "ponderável": "Ponderavel",
        "nao ponderavel": "NaoPonderavel",
    },
}


def canon_value(attr: str, val: Optional[str]) -> Optional[str]:
    """Map a free-form string (possibly accented) to the ontology canonical value."""
    if val is None:
        return None
    key = norm_txt(val)
    mapping = _CANON_MAP.get(attr, {})
    if key in mapping:
        return mapping[key]
    # If the caller already passed a canonical form, preserve it.
    return str(val).strip().replace(" ", "")
```

**Step 5: Run tests — verify pass**

```bash
pytest tests/test_nlp_normalize.py -v
```

Expected: 7 passed.

**Step 6: Commit**

```bash
git add tests/__init__.py tests/test_nlp_normalize.py src/ontomcda/nlp/__init__.py src/ontomcda/nlp/normalize.py
git commit -m "feat(nlp): add normalize module with tests"
```

---

### Task 5: `nlp/lexicon.py` — port the LEX dictionary

**Files:**
- Create: `src/ontomcda/nlp/lexicon.py`

**Step 1: Extract LEX and ATTR_TO_PROP from the original notebook**

```bash
python -c "
import json
with open('OntoMCDA_final.ipynb', encoding='utf-8') as f: nb = json.load(f)
# Cell at notebook line ~756 defines LEX and ATTR_TO_PROP
src = ''.join(nb['cells'][3]['source'])
# Find and print the LEX/ATTR_TO_PROP blocks
import re
m = re.search(r'ATTR_TO_PROP = \{.*?\n\}', src, re.DOTALL); print(m.group() if m else 'NOT FOUND')
print()
m = re.search(r'LEX = \{.*?\n\}\n\n', src, re.DOTALL); print(m.group() if m else 'NOT FOUND')
" > /tmp/lex_extract.py
```

Open `/tmp/lex_extract.py`, copy the `ATTR_TO_PROP = {...}` and `LEX = {...}` blocks.

**Step 2: Write `src/ontomcda/nlp/lexicon.py`**

```python
"""Portuguese-language lexicon and ontology property mapping.

Tables that map free-text Portuguese terms to ontology canonical values
(LEX) and map attribute slugs to OWL property local names (ATTR_TO_PROP).

Editing these tables is the primary way to tune NLP coverage without
touching control flow in nlp/inference.py or nlp/rules.py.
"""

ATTR_TO_PROP = {
    "tipo_problema": ["temTipoProblema", "temTipoDeProblema"],
    "compensatoriedade": "temCompensatoriedade",
    "tipo_variavel": ["temTipoVariavel", "temTipoDeVariavel"],
    "monotonicidade": ["temMonotonicidade", "suportaMonotonicidade"],
    "estrutura_decisoria": "temEstruturaDecisoria",
    "completude_pref": "temCompletudePref",
    "ambiente_decisao": ["temAmbienteDecisao", "temAmbienteDeDecisao"],
    "ponderabilidade": "temPonderabilidade",
    "usa_pesos": "usaPesos",
    "requer_pesos": "requerPesos",
    "gera_pesos": "geraPesos",
    "auxilia_gerar_pesos": "auxiliaGerarPesos",
    "sugere_pesos": "sugerePesos",
}

# Paste the LEX dict from OntoMCDA_final.ipynb verbatim here.
# The dict is ~400 lines of PT-BR terms per attribute/value.
LEX = {
    # ... (paste from notebook)
}
```

**Step 3: Verify the dict loads**

```bash
python -c "from ontomcda.nlp.lexicon import LEX, ATTR_TO_PROP; print(sorted(LEX.keys())); print(sorted(ATTR_TO_PROP.keys()))"
```

Expected: both print attribute slug lists.

**Step 4: Commit**

```bash
git add src/ontomcda/nlp/lexicon.py
git commit -m "feat(nlp): port LEX and ATTR_TO_PROP tables from original notebook"
```

---

### Task 6: `nlp/rules.py` — tipo_problema disambiguation (TDD)

**Files:**
- Create: `tests/test_nlp_rules.py`
- Create: `src/ontomcda/nlp/rules.py`

**Step 1: Write failing tests**

```python
from ontomcda.nlp.rules import infer_tipo_problema_por_regras


def test_rule_detects_ordenacao_from_ranking():
    txt = "precisamos gerar um ranking das alternativas"
    valor, evid = infer_tipo_problema_por_regras(txt, [])
    assert valor == "Ordenacao"


def test_rule_detects_escolha_from_melhor_alternativa():
    txt = "o objetivo final e selecionar a melhor alternativa"
    valor, evid = infer_tipo_problema_por_regras(txt, [])
    assert valor == "Escolha"


def test_rule_detects_classificacao_from_categorias():
    txt = "classificar as alternativas em categorias previamente definidas"
    valor, evid = infer_tipo_problema_por_regras(txt, [])
    assert valor == "Classificacao"


def test_rule_returns_none_when_tied():
    txt = "avaliar as opcoes"
    valor, evid = infer_tipo_problema_por_regras(txt, [])
    assert valor is None
```

**Step 2: Run, verify failure**

```bash
pytest tests/test_nlp_rules.py -v
```

**Step 3: Port `infer_tipo_problema_por_regras` from the notebook**

Extract from `OntoMCDA_final.ipynb` (file line 1305). Paste into `src/ontomcda/nlp/rules.py`:

```python
"""Rule-based overrides for tipo_problema inference.

When the lexicon alone is ambiguous between Escolha/Ordenacao/Classificacao,
these higher-priority patterns disambiguate based on phrase-level context.
"""
from typing import List, Optional, Tuple

from ontomcda.nlp.normalize import contains_term


def infer_tipo_problema_por_regras(
    t: str, evidencias_atuais: List[str]
) -> Tuple[Optional[str], List[str]]:
    # [paste function body from OntoMCDA_final.ipynb cell at file line 1305]
    ...
```

**Step 4: Run tests, verify pass**

```bash
pytest tests/test_nlp_rules.py -v
```

Expected: 4 passed.

**Step 5: Commit**

```bash
git add tests/test_nlp_rules.py src/ontomcda/nlp/rules.py
git commit -m "feat(nlp): add tipo_problema rule-based disambiguation"
```

---

### Task 7: `nlp/inference.py` — premise inference orchestrator (TDD)

**Files:**
- Create: `tests/test_nlp_inference.py`
- Create: `src/ontomcda/nlp/inference.py`

**Step 1: Write failing tests** — one assertion per template from the design

```python
from ontomcda.nlp.inference import infer_premissas


def test_t01_escolha_cardinal_individual():
    t = ("Um analista precisa escolher a melhor alternativa de investimento. "
         "Os critérios são numéricos e admitem trade-off.")
    prem, evid, score = infer_premissas(t)
    assert prem["tipo_problema"] == "Escolha"
    assert prem["tipo_variavel"] == "Cardinal"
    assert prem["estrutura_decisoria"] == "Individual"
    assert prem["compensatoriedade"] == "Compensatorio"


def test_t05_ordenacao_mista_grupo():
    t = ("Um comitê precisa ordenar projetos para definir prioridade. "
         "Os critérios envolvem variáveis quantitativas e qualitativas. "
         "Nem todas as preferências são conhecidas.")
    prem, evid, score = infer_premissas(t)
    assert prem["tipo_problema"] == "Ordenacao"
    assert prem["tipo_variavel"] == "Mista"
    assert prem["estrutura_decisoria"] == "Grupo"
    assert prem["completude_pref"] == "Incompleto"


def test_t09_classificacao_ordinal_individual():
    t = ("Um auditor precisa classificar processos em categorias previamente definidas "
         "usando avaliações qualitativas ordenadas.")
    prem, evid, score = infer_premissas(t)
    assert prem["tipo_problema"] == "Classificacao"
    assert prem["tipo_variavel"] == "Ordinal"


def test_infer_premissas_returns_three_dicts_with_same_keys():
    prem, evid, score = infer_premissas("teste simples")
    assert set(prem.keys()) == set(evid.keys()) == set(score.keys())
```

**Step 2: Run, verify failure**

**Step 3: Port `infer_attr` and `infer_premissas` from the notebook**

Extract from `OntoMCDA_final.ipynb` (file lines 1282 and 1353). Write `src/ontomcda/nlp/inference.py`:

```python
"""Premise inference: the free-text → ontology-value classifier.

infer_premissas(texto) is the public entry. It runs infer_attr per
attribute using the LEX lexicon, then lets rules.py override tipo_problema
where lexicon matches are ambiguous.
"""
from typing import Dict, List, Optional, Tuple

from ontomcda.config import ATTRS
from ontomcda.nlp.normalize import norm_txt, canon_value, contains_term, has_negated_expression
from ontomcda.nlp.lexicon import LEX
from ontomcda.nlp.rules import infer_tipo_problema_por_regras


def infer_attr(text_norm: str, attr: str) -> Tuple[Optional[str], List[str], int]:
    # [paste from notebook cell at file line 1282]
    ...


def infer_premissas(
    texto: str,
) -> Tuple[Dict[str, Optional[str]], Dict[str, List[str]], Dict[str, int]]:
    # [paste from notebook cell at file line 1353 — the full orchestrator]
    ...
```

**Step 4: Run tests, verify pass**

```bash
pytest tests/test_nlp_inference.py -v
```

Expected: 4 passed.

**Step 5: Commit**

```bash
git add tests/test_nlp_inference.py src/ontomcda/nlp/inference.py
git commit -m "feat(nlp): add infer_premissas orchestrator with template coverage tests"
```

---

### Task 8: `ontology.py` — OWL loader (TDD, dual-namespace)

**Files:**
- Create: `tests/test_ontology.py`
- Create: `src/ontomcda/ontology.py`

**Step 1: Write failing tests**

```python
from ontomcda.ontology import load_profiles


def test_load_profiles_finds_many_methods():
    profiles = load_profiles("OntoMCDA_final.owl")
    assert len(profiles) >= 50


def test_load_profiles_includes_canonical_methods():
    profiles = load_profiles("OntoMCDA_final.owl")
    for m in ["TOPSIS", "AHP", "PROMETHEE_III", "BWM_TOPSIS", "PSI"]:
        assert m in profiles, f"method {m} not loaded"


def test_load_profiles_dual_namespace_reads_attributes():
    """PROMETHEE_III has attributes in both NEW_NS and OLD_NS. Reader must merge."""
    profiles = load_profiles("OntoMCDA_final.owl")
    prof = profiles["PROMETHEE_III"]
    assert prof["tipo_problema"] == "Ordenacao"
    assert prof["compensatoriedade"] == "ParcialmenteCompensatorio"
    assert prof["estrutura_decisoria"] == "Coletiva"


def test_load_profiles_parses_boolean_data_attrs():
    profiles = load_profiles("OntoMCDA_final.owl")
    # Pick any method that has usa_pesos set — TOPSIS typically does
    topsis = profiles["TOPSIS"]
    assert topsis["usa_pesos"] in {"Sim", "Nao", None}
```

**Step 2: Run, verify failure**

**Step 3: Port from notebook** — `get_method_instances`, `parse_bool_literal`, `load_profiles`

Extract from `OntoMCDA_final.ipynb` (file lines 1789, 1799, 1813). Write `src/ontomcda/ontology.py`:

```python
"""OWL ontology loader.

Preserves the dual-namespace behavior of the original notebook: properties
under NEW_NS and OLD_NS are merged transparently. The .owl file is
never modified; this module is read-only.
"""
from typing import Dict, Optional

from rdflib import Graph, URIRef, RDF, Literal

from ontomcda.config import ATTRS, DATA_ATTRS, NEW_NS, OLD_NS
from ontomcda.nlp.lexicon import ATTR_TO_PROP
from ontomcda.nlp.normalize import canon_value, local_name, norm_txt


def get_method_instances(g: Graph):
    # [paste from notebook cell at file line 1789]
    ...


def parse_bool_literal(v) -> str:
    # [paste from notebook cell at file line 1799]
    ...


def load_profiles(owl_path: str) -> Dict[str, Dict[str, Optional[str]]]:
    # [paste from notebook cell at file line 1813]
    ...
```

**Step 4: Run tests, verify pass**

```bash
pytest tests/test_ontology.py -v
```

Expected: 4 passed.

**Step 5: Commit**

```bash
git add tests/test_ontology.py src/ontomcda/ontology.py
git commit -m "feat(ontology): OWL loader with dual-namespace support"
```

---

### Task 9: `scoring.py` — matcher and query consultation (TDD)

**Files:**
- Create: `tests/test_scoring.py`
- Create: `src/ontomcda/scoring.py`

**Step 1: Write failing tests**

```python
from ontomcda.scoring import tipo_variavel_match, ontology_match, consult_ontology, build_query_profile


def test_tipo_variavel_mista_accepts_cardinal_and_ordinal():
    assert tipo_variavel_match("Mista", "Cardinal") is True
    assert tipo_variavel_match("Mista", "Ordinal") is True
    assert tipo_variavel_match("Mista", "PseudoCardinal") is True


def test_tipo_variavel_ordinal_rejects_cardinal():
    assert tipo_variavel_match("Ordinal", "Cardinal") is False


def test_ontology_match_parcialmente_compensatorio_is_flexible():
    ok, _ = ontology_match("compensatoriedade", "ParcialmenteCompensatorio", "Compensatorio")
    assert ok is True
    ok, _ = ontology_match("compensatoriedade", "ParcialmenteCompensatorio", "NaoCompensatorio")
    assert ok is True


def test_ontology_match_estrutura_decisoria_monomulti_accepts_both():
    ok_ind, _ = ontology_match("estrutura_decisoria", "Individual", "MonoMulti")
    ok_grp, _ = ontology_match("estrutura_decisoria", "Grupo", "MonoMulti")
    assert ok_ind is True and ok_grp is True


def test_ontology_match_returns_none_when_premise_missing():
    ok, _ = ontology_match("ambiente_decisao", None, "Certeza")
    assert ok is None


def test_build_query_profile_includes_all_attrs():
    prem = {"tipo_problema": "Escolha"}
    score_map = {"tipo_problema": 2}
    qp = build_query_profile(prem, score_map)
    assert "tipo_problema" in qp
    assert qp["tipo_problema"]["value"] == "Escolha"
```

**Step 2: Run, verify failure**

**Step 3: Port from notebook** (file lines 1842, 1862, 1898, 1918) — write `src/ontomcda/scoring.py`:

```python
"""Scoring: match inferred premises against method ontology profiles.

ontology_match is attribute-aware — the rules for tipo_variavel,
estrutura_decisoria, and compensatoriedade are not pure equality.
consult_ontology produces the accepted/rejected DataFrames.
"""
from typing import Dict, Optional, Tuple

import pandas as pd

from ontomcda.config import ATTRS, ATTR_WEIGHTS, MANDATORY_QUERY_ATTRS
from ontomcda.nlp.normalize import canon_value


def tipo_variavel_match(inferido: str, metodo_val: Optional[str]) -> bool:
    # [paste from notebook cell at file line 1842]
    ...


def ontology_match(
    attr: str, problem_value: Optional[str], method_value: Optional[str]
) -> Tuple[Optional[bool], str]:
    # [paste from notebook cell at file line 1862]
    ...


def build_query_profile(prem, score_map):
    # [paste from notebook cell at file line 1898]
    ...


def consult_ontology(query_profile, profiles, top_k: int = 15):
    # [paste from notebook cell at file line 1918]
    ...
```

**Step 4: Run tests, verify pass**

```bash
pytest tests/test_scoring.py -v
```

Expected: 6 passed.

**Step 5: Commit**

```bash
git add tests/test_scoring.py src/ontomcda/scoring.py
git commit -m "feat(scoring): ontology matcher and consultation with attribute-aware rules"
```

---

### Task 10: `pipeline.py` — public API (TDD)

**Files:**
- Create: `tests/test_pipeline.py`
- Create: `src/ontomcda/pipeline.py`

**Step 1: Write failing tests**

```python
import pandas as pd
from ontomcda.pipeline import recomendar, batch_recomendar
from ontomcda.ontology import load_profiles


def test_recomendar_returns_structured_result():
    profiles = load_profiles("OntoMCDA_final.owl")
    texto = "Precisamos ranquear projetos; decisão em grupo, variáveis mistas."
    r = recomendar(texto, profiles, top_k=5)
    assert set(r.keys()) == {"premissas", "query_profile", "aceitos", "rejeitados", "faltantes"}
    assert isinstance(r["aceitos"], pd.DataFrame)
    assert len(r["aceitos"]) <= 5


def test_recomendar_flags_missing_mandatory_premise():
    profiles = load_profiles("OntoMCDA_final.owl")
    r = recomendar("texto vazio irrelevante xyz", profiles)
    # tipo_problema is mandatory; if not inferred, should return faltantes non-empty
    if "tipo_problema" in r["faltantes"]:
        assert r["aceitos"].empty


def test_batch_recomendar_processes_all_rows():
    profiles = load_profiles("OntoMCDA_final.owl")
    casos = pd.DataFrame([
        {"id": "a", "texto": "escolher melhor fornecedor com dados numericos"},
        {"id": "b", "texto": "ordenar projetos por prioridade em grupo"},
    ])
    out = batch_recomendar(casos, profiles, top_k=3)
    assert len(out) == 2
    assert set(out[0].keys()) >= {"id", "premissas", "ranking"}
```

**Step 2: Run, verify failure**

**Step 3: Write `src/ontomcda/pipeline.py`**

```python
"""Public API: recomendar() glues NLP inference and ontology scoring."""
from typing import Dict, List, Optional

import pandas as pd

from ontomcda.config import MANDATORY_QUERY_ATTRS
from ontomcda.nlp.inference import infer_premissas
from ontomcda.scoring import build_query_profile, consult_ontology


def recomendar(
    texto: str,
    profiles: Dict[str, Dict[str, Optional[str]]],
    top_k: int = 15,
) -> dict:
    prem, evid_map, score_map = infer_premissas(texto)
    query_profile = build_query_profile(prem, score_map)

    faltantes = [a for a in MANDATORY_QUERY_ATTRS if prem.get(a) is None]
    if faltantes:
        return {
            "premissas": prem,
            "query_profile": query_profile,
            "aceitos": pd.DataFrame(),
            "rejeitados": pd.DataFrame(),
            "faltantes": faltantes,
        }

    acc_df, rej_df = consult_ontology(query_profile, profiles, top_k=top_k)
    return {
        "premissas": prem,
        "query_profile": query_profile,
        "aceitos": acc_df,
        "rejeitados": rej_df,
        "faltantes": [],
    }


def batch_recomendar(casos: pd.DataFrame, profiles, top_k: int = 15) -> List[dict]:
    out = []
    for _, row in casos.iterrows():
        r = recomendar(row["texto"], profiles, top_k=top_k)
        out.append({
            "id": row["id"],
            "premissas": r["premissas"],
            "ranking": list(r["aceitos"]["metodo"]) if not r["aceitos"].empty else [],
            "faltantes": r["faltantes"],
        })
    return out
```

**Step 4: Run tests, verify pass**

```bash
pytest tests/test_pipeline.py -v
```

Expected: 3 passed.

**Step 5: Expose public API in `src/ontomcda/__init__.py`**

Replace contents:
```python
"""OntoMCDA — ontology-driven MCDA method recommender."""
from ontomcda.pipeline import recomendar, batch_recomendar
from ontomcda.ontology import load_profiles

__version__ = "1.0.0"
__all__ = ["recomendar", "batch_recomendar", "load_profiles"]
```

**Step 6: Commit**

```bash
git add tests/test_pipeline.py src/ontomcda/pipeline.py src/ontomcda/__init__.py
git commit -m "feat(pipeline): public recomendar and batch_recomendar API"
```

---

### Task 11: End-to-end sanity run

**Step 1: Run a smoke script**

```bash
python -c "
from ontomcda import load_profiles, recomendar
p = load_profiles('OntoMCDA_final.owl')
print('methods loaded:', len(p))
r = recomendar('Um analista precisa escolher o melhor fornecedor com base em criterios quantitativos.', p, top_k=5)
print('premissas:', r['premissas'])
print('top 5:', list(r['aceitos']['metodo'])[:5] if not r['aceitos'].empty else 'EMPTY')
"
```

Expected: methods loaded ~100+, premissas has `tipo_problema: Escolha`, top-5 list non-empty.

**Step 2: Run full test suite**

```bash
pytest -v
```

Expected: all green.

**Step 3: Commit (only if any tweaks made — likely nothing)**

No commit if nothing changed.

---

## Phase 3 — Dataset templates and generator

### Task 12: `dataset/templates.py` — 9 template objects

**Files:**
- Create: `src/ontomcda/dataset/__init__.py`
- Create: `src/ontomcda/dataset/templates.py`

**Step 1: Create `src/ontomcda/dataset/__init__.py`**

```python
"""Synthetic dataset generation for validation."""
```

**Step 2: Write `src/ontomcda/dataset/templates.py`** with 9 templates as described in the design doc.

Each template is a `@dataclass`:

```python
"""Synthetic case templates.

Each template fixes a known premise profile (the gold standard) and lists
3–5 PT-BR redações that reword the same situation differently. This stresses
the NLP layer against synonyms/restructuring without changing the gold.
"""
from dataclasses import dataclass, field
from typing import Dict, List


@dataclass
class Template:
    id: str
    premissas: Dict[str, str]
    redacoes: List[str]


TEMPLATES: List[Template] = [
    Template(
        id="T01_escolha_cardinal_individual",
        premissas={
            "tipo_problema": "Escolha",
            "tipo_variavel": "Cardinal",
            "estrutura_decisoria": "Individual",
            "compensatoriedade": "Compensatorio",
            "monotonicidade": "Monotonico",
            "completude_pref": "Completo",
            "ambiente_decisao": "Certeza",
            "ponderabilidade": "Ponderavel",
            "usa_pesos": "Sim",
            "requer_pesos": "Sim",
        },
        redacoes=[
            "Um gerente precisa escolher o fornecedor mais adequado entre quatro opcoes. "
            "Os criterios sao quantitativos (custo, prazo, qualidade) e admitem trade-off. "
            "O decisor atribui pesos diretos aos criterios.",
            "Selecao da melhor alternativa de investimento por um unico analista. "
            "Dados numericos completos, compensacao entre criterios permitida, "
            "pesos definidos pelo decisor.",
            "Um engenheiro precisa escolher entre tres equipamentos. Todos os indicadores "
            "sao quantitativos, ha pesos explicitos por criterio, e admite-se compensacao.",
        ],
    ),
    # T02–T09: follow the same pattern per the design doc table.
    # Write ALL 9 templates with 3 redações each.
]


def get_template(tid: str) -> Template:
    for t in TEMPLATES:
        if t.id == tid:
            return t
    raise KeyError(tid)
```

Write all 9 templates. For each, use 3 redações varying in verbosity, ordering, and synonyms (ranquear/ordenar/priorizar; monodecisor/individual/um decisor; quantitativo/numerico/cardinal). Keep redações between 2 and 4 sentences.

**Step 3: Quick sanity check**

```bash
python -c "from ontomcda.dataset.templates import TEMPLATES; print(len(TEMPLATES)); [print(t.id, len(t.redacoes)) for t in TEMPLATES]"
```

Expected: 9 templates, each with 3+ redações.

**Step 4: Commit**

```bash
git add src/ontomcda/dataset/__init__.py src/ontomcda/dataset/templates.py
git commit -m "feat(dataset): add 9 synthetic case templates with PT-BR redações"
```

---

### Task 13: `dataset/generator.py` — build the four CSVs (TDD)

**Files:**
- Create: `tests/test_dataset_generator.py`
- Create: `src/ontomcda/dataset/generator.py`

**Step 1: Write failing tests**

```python
import json
from pathlib import Path
import pandas as pd
from ontomcda.dataset.generator import gerar_casos, escrever_csvs


def test_gerar_casos_produces_case_per_redacao():
    out = gerar_casos()
    assert len(out["casos"]) >= 27  # 9 templates × 3 redações minimum
    assert set(out["casos"].columns) == {"id", "template_id", "redacao_idx", "texto"}


def test_gabarito_has_all_required_attrs():
    out = gerar_casos()
    required = {"id", "tipo_problema", "tipo_variavel", "estrutura_decisoria"}
    assert required.issubset(set(out["gabarito"].columns))


def test_ranking_esperado_starts_empty():
    out = gerar_casos()
    re_df = out["ranking_esperado"]
    assert set(re_df.columns) == {"id", "relevantes"}
    assert re_df["relevantes"].isna().all() or (re_df["relevantes"] == "").all()


def test_escrever_csvs_creates_four_files(tmp_path):
    escrever_csvs(gerar_casos(), tmp_path)
    for name in ["casos.csv", "gabarito_premissas.csv", "ranking_esperado.csv"]:
        assert (tmp_path / name).exists()
    assert (tmp_path / "templates.json").exists()
    # templates.json should list 9 template IDs
    manifest = json.loads((tmp_path / "templates.json").read_text())
    assert len(manifest["templates"]) == 9
```

**Step 2: Run, verify failure**

**Step 3: Write `src/ontomcda/dataset/generator.py`**

```python
"""Generate the four dataset CSVs from templates."""
import json
from pathlib import Path
from typing import Dict

import pandas as pd

from ontomcda.dataset.templates import TEMPLATES


def gerar_casos() -> Dict[str, pd.DataFrame]:
    casos_rows = []
    gabarito_rows = []
    for tmpl in TEMPLATES:
        for i, redacao in enumerate(tmpl.redacoes, start=1):
            case_id = f"{tmpl.id}-r{i}"
            casos_rows.append({
                "id": case_id,
                "template_id": tmpl.id,
                "redacao_idx": i,
                "texto": redacao,
            })
            gabarito_rows.append({"id": case_id, **tmpl.premissas})

    casos_df = pd.DataFrame(casos_rows)
    gabarito_df = pd.DataFrame(gabarito_rows)
    ranking_df = pd.DataFrame({"id": casos_df["id"], "relevantes": [""] * len(casos_df)})

    return {
        "casos": casos_df,
        "gabarito": gabarito_df,
        "ranking_esperado": ranking_df,
    }


def escrever_csvs(data: Dict[str, pd.DataFrame], out_dir: Path) -> None:
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    data["casos"].to_csv(out_dir / "casos.csv", index=False, encoding="utf-8")
    data["gabarito"].to_csv(out_dir / "gabarito_premissas.csv", index=False, encoding="utf-8")
    data["ranking_esperado"].to_csv(out_dir / "ranking_esperado.csv", index=False, encoding="utf-8")

    manifest = {
        "templates": [
            {
                "id": t.id,
                "premissas": t.premissas,
                "n_redacoes": len(t.redacoes),
            }
            for t in TEMPLATES
        ],
    }
    (out_dir / "templates.json").write_text(
        json.dumps(manifest, indent=2, ensure_ascii=False), encoding="utf-8"
    )
```

**Step 4: Run, verify pass**

```bash
pytest tests/test_dataset_generator.py -v
```

Expected: 4 passed.

**Step 5: Commit**

```bash
git add tests/test_dataset_generator.py src/ontomcda/dataset/generator.py
git commit -m "feat(dataset): generator producing casos, gabarito, ranking, templates.json"
```

---

### Task 14: `dataset/__main__.py` — CLI

**Files:**
- Create: `src/ontomcda/dataset/__main__.py`

**Step 1: Write CLI**

```python
"""CLI: python -m ontomcda.dataset  — regenerates data/ CSVs."""
from pathlib import Path

from ontomcda.dataset.generator import gerar_casos, escrever_csvs


def main() -> None:
    out = gerar_casos()
    target = Path("data")
    escrever_csvs(out, target)
    print(f"Wrote {len(out['casos'])} cases → {target.resolve()}")


if __name__ == "__main__":
    main()
```

**Step 2: Run it**

```bash
python -m ontomcda.dataset
```

Expected: `Wrote 27+ cases → .../data`

**Step 3: Verify files**

```bash
ls data/
head -3 data/casos.csv
head -3 data/gabarito_premissas.csv
```

**Step 4: Commit data and CLI**

```bash
git add src/ontomcda/dataset/__main__.py data/
git commit -m "feat(dataset): CLI entry point and initial generated data"
```

---

## Phase 4 — Evaluation metrics

### Task 15: `evaluation/pln.py` — per-class metrics, confusion, kappa (TDD)

**Files:**
- Create: `src/ontomcda/evaluation/__init__.py`
- Create: `tests/test_evaluation_pln.py`
- Create: `src/ontomcda/evaluation/pln.py`

**Step 1: Create `src/ontomcda/evaluation/__init__.py`**

```python
"""Evaluation metrics: PLN, ranking, bootstrap, report."""
```

**Step 2: Write failing tests**

```python
import pandas as pd
from ontomcda.evaluation.pln import (
    metricas_por_atributo,
    per_class_report,
    matriz_confusao,
    taxa_nao_inferido,
    ATRIBUTOS_CATEGORICOS,
)


def _gold():
    return pd.DataFrame([
        {"id": 1, "tipo_problema": "Escolha", "tipo_variavel": "Cardinal"},
        {"id": 2, "tipo_problema": "Ordenacao", "tipo_variavel": "Mista"},
        {"id": 3, "tipo_problema": "Escolha", "tipo_variavel": "Cardinal"},
    ])


def _pred_perfect():
    return _gold()


def _pred_one_wrong():
    df = _gold().copy()
    df.loc[0, "tipo_problema"] = "Ordenacao"
    return df


def test_metricas_perfect_accuracy_is_one():
    m = metricas_por_atributo(_gold(), _pred_perfect(), ["tipo_problema", "tipo_variavel"])
    assert (m["accuracy"] == 1.0).all()


def test_metricas_per_class_report_returns_frame():
    r = per_class_report("tipo_problema", _gold(), _pred_perfect())
    assert isinstance(r, pd.DataFrame)
    assert {"classe", "precision", "recall", "f1", "support"}.issubset(r.columns)


def test_matriz_confusao_returns_square():
    cm = matriz_confusao("tipo_problema", _gold(), _pred_one_wrong())
    assert cm.shape[0] == cm.shape[1]


def test_taxa_nao_inferido_counts_none_and_nan():
    pred = _gold().copy()
    pred.loc[0, "tipo_problema"] = None
    pred.loc[1, "tipo_problema"] = pd.NA
    t = taxa_nao_inferido(pred, ["tipo_problema", "tipo_variavel"])
    assert t["tipo_problema"] == 2 / 3
    assert t["tipo_variavel"] == 0.0


def test_kappa_is_between_minus_one_and_one():
    m = metricas_por_atributo(_gold(), _pred_one_wrong(), ["tipo_problema"])
    assert -1.0 <= m.iloc[0]["kappa"] <= 1.0
```

**Step 3: Run, verify failure**

**Step 4: Write `src/ontomcda/evaluation/pln.py`**

```python
"""PLN metrics: per-attribute accuracy, per-class P/R/F1, confusion, kappa."""
from typing import List

import pandas as pd
from sklearn.metrics import (
    accuracy_score,
    classification_report,
    cohen_kappa_score,
    confusion_matrix,
    f1_score,
    precision_score,
    recall_score,
)

ATRIBUTOS_CATEGORICOS = [
    "tipo_problema",
    "tipo_variavel",
    "estrutura_decisoria",
    "compensatoriedade",
    "monotonicidade",
    "completude_pref",
    "ambiente_decisao",
    "ponderabilidade",
]


def _align(gold: pd.DataFrame, pred: pd.DataFrame, attr: str):
    g = gold[["id", attr]].rename(columns={attr: "g"})
    p = pred[["id", attr]].rename(columns={attr: "p"})
    merged = g.merge(p, on="id")
    merged = merged.dropna(subset=["g", "p"])
    return merged["g"].astype(str), merged["p"].astype(str)


def metricas_por_atributo(gold, pred, atributos=None) -> pd.DataFrame:
    atributos = atributos or ATRIBUTOS_CATEGORICOS
    rows = []
    for a in atributos:
        if a not in gold.columns or a not in pred.columns:
            continue
        y_true, y_pred = _align(gold, pred, a)
        if len(y_true) == 0:
            continue
        rows.append({
            "atributo": a,
            "accuracy": accuracy_score(y_true, y_pred),
            "precision_macro": precision_score(y_true, y_pred, average="macro", zero_division=0),
            "recall_macro": recall_score(y_true, y_pred, average="macro", zero_division=0),
            "f1_macro": f1_score(y_true, y_pred, average="macro", zero_division=0),
            "f1_micro": f1_score(y_true, y_pred, average="micro", zero_division=0),
            "kappa": cohen_kappa_score(y_true, y_pred),
            "n": len(y_true),
        })
    return pd.DataFrame(rows)


def per_class_report(atributo, gold, pred) -> pd.DataFrame:
    y_true, y_pred = _align(gold, pred, atributo)
    rep = classification_report(y_true, y_pred, output_dict=True, zero_division=0)
    rows = [
        {"classe": k, "precision": v["precision"], "recall": v["recall"],
         "f1": v["f1-score"], "support": v["support"]}
        for k, v in rep.items()
        if k not in {"accuracy", "macro avg", "weighted avg"}
    ]
    return pd.DataFrame(rows)


def matriz_confusao(atributo, gold, pred) -> pd.DataFrame:
    y_true, y_pred = _align(gold, pred, atributo)
    labels = sorted(set(y_true) | set(y_pred))
    cm = confusion_matrix(y_true, y_pred, labels=labels)
    return pd.DataFrame(cm, index=labels, columns=labels)


def taxa_nao_inferido(pred: pd.DataFrame, atributos=None):
    atributos = atributos or ATRIBUTOS_CATEGORICOS
    result = {}
    for a in atributos:
        if a not in pred.columns:
            continue
        missing = pred[a].isna().sum()
        result[a] = missing / len(pred) if len(pred) else 0.0
    return pd.Series(result)


def plot_matriz_confusao(atributo, gold, pred, ax=None):
    import matplotlib.pyplot as plt
    import seaborn as sns
    cm = matriz_confusao(atributo, gold, pred)
    if ax is None:
        _, ax = plt.subplots(figsize=(5, 4))
    sns.heatmap(cm, annot=True, fmt="d", cmap="Blues", ax=ax, cbar=False)
    ax.set_xlabel("predito")
    ax.set_ylabel("gabarito")
    ax.set_title(f"Confusão — {atributo}")
    return ax
```

**Step 5: Run, verify pass**

```bash
pytest tests/test_evaluation_pln.py -v
```

Expected: 5 passed.

**Step 6: Commit**

```bash
git add src/ontomcda/evaluation/__init__.py tests/test_evaluation_pln.py src/ontomcda/evaluation/pln.py
git commit -m "feat(evaluation): PLN per-attribute and per-class metrics + kappa + confusion"
```

---

### Task 16: `evaluation/ranking.py` — ranking metrics (TDD)

**Files:**
- Create: `tests/test_evaluation_ranking.py`
- Create: `src/ontomcda/evaluation/ranking.py`

**Step 1: Write failing tests**

```python
from ontomcda.evaluation.ranking import (
    precision_at_k, hit_at_k, ndcg_at_k, mrr, kendall_tau_parcial, spearman_parcial
)


def test_precision_at_k_full_match():
    assert precision_at_k(["A", "B", "C"], ["A", "B", "C", "D"], k=3) == 1.0


def test_precision_at_k_partial():
    assert abs(precision_at_k(["A", "B"], ["A", "X", "B"], k=3) - 2/3) < 1e-9


def test_hit_at_k_true_when_any_relevant_present():
    assert hit_at_k(["A"], ["X", "A", "Y"], k=3) == 1.0
    assert hit_at_k(["A"], ["X", "Y", "Z"], k=3) == 0.0


def test_ndcg_higher_when_relevant_is_first():
    better = ndcg_at_k(["A"], ["A", "X", "Y"], k=3)
    worse = ndcg_at_k(["A"], ["X", "Y", "A"], k=3)
    assert better > worse


def test_mrr_mean_across_cases():
    rankings = [["A", "B"], ["X", "A"], ["Y", "X"]]
    relevantes = [["A"], ["A"], ["A"]]
    # positions: 1, 2, inf → RR = 1, 0.5, 0 → mean = 0.5
    assert abs(mrr(relevantes, rankings) - 0.5) < 1e-9


def test_kendall_tau_parcial_same_order_is_one():
    t, _ = kendall_tau_parcial(["A", "B", "C"], ["A", "B", "C", "D"])
    assert t == 1.0


def test_spearman_parcial_works_with_partial_overlap():
    rho, _ = spearman_parcial(["A", "B", "C"], ["A", "C", "B"])
    assert -1.0 <= rho <= 1.0
```

**Step 2: Run, verify failure**

**Step 3: Write `src/ontomcda/evaluation/ranking.py`**

```python
"""Ranking metrics: P@k, Hit@k, nDCG@k, MRR, Kendall τ, Spearman ρ."""
import math
from typing import List, Optional, Tuple

import pandas as pd
from scipy.stats import kendalltau, spearmanr


def _topk(ranking: List[str], k: int) -> List[str]:
    return list(ranking)[:k]


def precision_at_k(relevantes, ranking, k: int) -> float:
    topk = _topk(ranking, k)
    if not topk:
        return 0.0
    rel_set = set(relevantes)
    return sum(1 for x in topk if x in rel_set) / len(topk)


def hit_at_k(relevantes, ranking, k: int) -> float:
    return 1.0 if set(_topk(ranking, k)) & set(relevantes) else 0.0


def ndcg_at_k(relevantes, ranking, k: int) -> float:
    topk = _topk(ranking, k)
    rel_set = set(relevantes)
    dcg = sum(1.0 / math.log2(i + 2) for i, x in enumerate(topk) if x in rel_set)
    ideal_n = min(len(rel_set), k)
    idcg = sum(1.0 / math.log2(i + 2) for i in range(ideal_n))
    return dcg / idcg if idcg > 0 else 0.0


def mrr(relevantes_por_caso, rankings_por_caso) -> float:
    rr = []
    for rel, rank in zip(relevantes_por_caso, rankings_por_caso):
        rel_set = set(rel)
        pos = next((i + 1 for i, m in enumerate(rank) if m in rel_set), None)
        rr.append(1.0 / pos if pos else 0.0)
    return sum(rr) / len(rr) if rr else 0.0


def _common_positions(a: List[str], b: List[str]):
    a_pos = {x: i for i, x in enumerate(a)}
    b_pos = {x: i for i, x in enumerate(b)}
    common = [x for x in a if x in b_pos]
    return [a_pos[x] for x in common], [b_pos[x] for x in common]


def kendall_tau_parcial(ranking_sistema, ranking_esperado) -> Tuple[Optional[float], int]:
    ra, rb = _common_positions(ranking_sistema, ranking_esperado)
    if len(ra) < 2:
        return None, len(ra)
    tau, _ = kendalltau(ra, rb)
    return float(tau), len(ra)


def spearman_parcial(ranking_sistema, ranking_esperado) -> Tuple[Optional[float], int]:
    ra, rb = _common_positions(ranking_sistema, ranking_esperado)
    if len(ra) < 2:
        return None, len(ra)
    rho, _ = spearmanr(ra, rb)
    return float(rho), len(ra)


def metricas_completas(ranking_esperado_df, resultados, ks=(3, 5, 10)) -> pd.DataFrame:
    """Per-case metrics for all cases with non-empty ranking_esperado."""
    rows = []
    for r in resultados:
        rel_row = ranking_esperado_df[ranking_esperado_df["id"] == r["id"]]
        if rel_row.empty:
            continue
        rel = str(rel_row.iloc[0]["relevantes"] or "")
        relevantes = [x.strip() for x in rel.split(";") if x.strip()]
        if not relevantes:
            continue
        rank = r["ranking"]
        row = {"id": r["id"]}
        for k in ks:
            row[f"p@{k}"] = precision_at_k(relevantes, rank, k)
            row[f"hit@{k}"] = hit_at_k(relevantes, rank, k)
            row[f"ndcg@{k}"] = ndcg_at_k(relevantes, rank, k)
        row["mrr"] = mrr([relevantes], [rank])
        tau, n = kendall_tau_parcial(rank, relevantes)
        rho, _ = spearman_parcial(rank, relevantes)
        row["kendall_tau"] = tau
        row["spearman_rho"] = rho
        row["n_common"] = n
        rows.append(row)
    return pd.DataFrame(rows)
```

**Step 4: Run, verify pass**

```bash
pytest tests/test_evaluation_ranking.py -v
```

Expected: 7 passed.

**Step 5: Commit**

```bash
git add tests/test_evaluation_ranking.py src/ontomcda/evaluation/ranking.py
git commit -m "feat(evaluation): ranking metrics P@k, Hit@k, nDCG, MRR, Kendall, Spearman"
```

---

### Task 17: `evaluation/bootstrap.py` — confidence intervals (TDD)

**Files:**
- Create: `tests/test_evaluation_bootstrap.py`
- Create: `src/ontomcda/evaluation/bootstrap.py`

**Step 1: Write failing tests**

```python
import numpy as np
import pandas as pd
from ontomcda.evaluation.bootstrap import intervalos_ic, resample_with_seed


def test_resample_is_reproducible_with_seed():
    df = pd.DataFrame({"x": list(range(100))})
    a = resample_with_seed(df, seed=42)
    b = resample_with_seed(df, seed=42)
    pd.testing.assert_frame_equal(a.reset_index(drop=True), b.reset_index(drop=True))


def test_resample_differs_with_different_seed():
    df = pd.DataFrame({"x": list(range(100))})
    a = resample_with_seed(df, seed=1)
    b = resample_with_seed(df, seed=2)
    assert not a.equals(b)


def test_intervalos_ic_produces_lower_and_upper():
    rng = np.random.default_rng(0)
    values = pd.Series(rng.normal(0, 1, size=200))
    def stat(s):
        return float(s.mean())
    ic = intervalos_ic(values, stat, n_iter=500, seed=42)
    assert ic["lower"] < ic["mean"] < ic["upper"]


def test_intervalos_ic_stable_with_seed():
    values = pd.Series([1.0] * 50 + [0.0] * 50)
    def stat(s):
        return float(s.mean())
    ic1 = intervalos_ic(values, stat, n_iter=200, seed=42)
    ic2 = intervalos_ic(values, stat, n_iter=200, seed=42)
    assert ic1 == ic2
```

**Step 2: Run, verify failure**

**Step 3: Write `src/ontomcda/evaluation/bootstrap.py`**

```python
"""Bootstrap confidence intervals over metrics."""
from typing import Callable, Dict

import numpy as np
import pandas as pd

from ontomcda.config import BOOTSTRAP_ITERATIONS, BOOTSTRAP_SEED


def resample_with_seed(df: pd.DataFrame, seed: int) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    idx = rng.integers(0, len(df), size=len(df))
    return df.iloc[idx].copy()


def intervalos_ic(
    values: pd.Series,
    statistic: Callable[[pd.Series], float],
    n_iter: int = BOOTSTRAP_ITERATIONS,
    seed: int = BOOTSTRAP_SEED,
    alpha: float = 0.05,
) -> Dict[str, float]:
    rng = np.random.default_rng(seed)
    n = len(values)
    stats = []
    for _ in range(n_iter):
        idx = rng.integers(0, n, size=n)
        stats.append(statistic(values.iloc[idx]))
    stats_arr = np.array(stats)
    return {
        "mean": float(stats_arr.mean()),
        "lower": float(np.quantile(stats_arr, alpha / 2)),
        "upper": float(np.quantile(stats_arr, 1 - alpha / 2)),
        "n_iter": n_iter,
    }


def ic_for_metric_over_cases(
    metric_per_case: pd.Series,
    n_iter: int = BOOTSTRAP_ITERATIONS,
    seed: int = BOOTSTRAP_SEED,
) -> Dict[str, float]:
    return intervalos_ic(metric_per_case, lambda s: float(s.mean()), n_iter, seed)
```

**Step 4: Run, verify pass**

```bash
pytest tests/test_evaluation_bootstrap.py -v
```

Expected: 4 passed.

**Step 5: Commit**

```bash
git add tests/test_evaluation_bootstrap.py src/ontomcda/evaluation/bootstrap.py
git commit -m "feat(evaluation): bootstrap confidence intervals with seeded reproducibility"
```

---

### Task 18: `evaluation/report.py` — per-template, stability, xlsx export (TDD)

**Files:**
- Create: `tests/test_evaluation_report.py`
- Create: `src/ontomcda/evaluation/report.py`

**Step 1: Write failing tests**

```python
from pathlib import Path
import pandas as pd
from ontomcda.evaluation.report import (
    desempenho_por_template, estabilidade_linguistica, exportar_excel,
)


def _mock_inputs():
    casos = pd.DataFrame([
        {"id": "T01-r1", "template_id": "T01", "redacao_idx": 1, "texto": "x"},
        {"id": "T01-r2", "template_id": "T01", "redacao_idx": 2, "texto": "y"},
        {"id": "T02-r1", "template_id": "T02", "redacao_idx": 1, "texto": "z"},
    ])
    gabarito = pd.DataFrame([
        {"id": "T01-r1", "tipo_problema": "Escolha"},
        {"id": "T01-r2", "tipo_problema": "Escolha"},
        {"id": "T02-r1", "tipo_problema": "Ordenacao"},
    ])
    resultados = [
        {"id": "T01-r1", "premissas": {"tipo_problema": "Escolha"}, "ranking": []},
        {"id": "T01-r2", "premissas": {"tipo_problema": "Ordenacao"}, "ranking": []},
        {"id": "T02-r1", "premissas": {"tipo_problema": "Ordenacao"}, "ranking": []},
    ]
    return casos, gabarito, resultados


def test_desempenho_por_template_returns_one_row_per_template():
    casos, gabarito, resultados = _mock_inputs()
    df = desempenho_por_template(resultados, gabarito, casos)
    assert set(df["template_id"]) == {"T01", "T02"}


def test_estabilidade_flags_template_with_divergent_redacoes():
    casos, gabarito, resultados = _mock_inputs()
    est = estabilidade_linguistica(resultados, gabarito, casos)
    # T01 has 2 redações with different predictions → deveria marcar instabilidade
    t01 = est[est["template_id"] == "T01"].iloc[0]
    assert t01["concordancia_redacoes"] < 1.0


def test_exportar_excel_creates_file(tmp_path):
    casos, gabarito, resultados = _mock_inputs()
    path = tmp_path / "relatorio.xlsx"
    exportar_excel(resultados, gabarito, pd.DataFrame({"id": [], "relevantes": []}), casos, path)
    assert path.exists()
```

**Step 2: Run, verify failure**

**Step 3: Write `src/ontomcda/evaluation/report.py`**

```python
"""Reporting: per-template and stability analysis + Excel export."""
from pathlib import Path
from typing import List, Optional

import pandas as pd

from ontomcda.evaluation import pln, ranking, bootstrap


def _pred_premissas_df(resultados) -> pd.DataFrame:
    rows = []
    for r in resultados:
        row = {"id": r["id"], **r["premissas"]}
        rows.append(row)
    return pd.DataFrame(rows)


def desempenho_por_template(resultados, gabarito, casos) -> pd.DataFrame:
    pred = _pred_premissas_df(resultados)
    merged = casos[["id", "template_id"]].merge(gabarito, on="id").merge(
        pred, on="id", suffixes=("_gold", "_pred")
    )
    rows = []
    for tid, g in merged.groupby("template_id"):
        gold_sub = g[["id"] + [c for c in g.columns if c.endswith("_gold")]].rename(
            columns=lambda c: c.replace("_gold", "")
        )
        pred_sub = g[["id"] + [c for c in g.columns if c.endswith("_pred")]].rename(
            columns=lambda c: c.replace("_pred", "")
        )
        m = pln.metricas_por_atributo(gold_sub, pred_sub)
        if not m.empty:
            row = {"template_id": tid, "n_casos": len(g), **{f"f1_macro_{r.atributo}": r.f1_macro for r in m.itertuples()}}
            row["f1_macro_medio"] = float(m["f1_macro"].mean())
            rows.append(row)
    return pd.DataFrame(rows)


def estabilidade_linguistica(resultados, gabarito, casos) -> pd.DataFrame:
    pred = _pred_premissas_df(resultados)
    merged = casos[["id", "template_id"]].merge(pred, on="id")
    attrs = [c for c in pred.columns if c != "id"]
    rows = []
    for tid, g in merged.groupby("template_id"):
        if len(g) < 2:
            rows.append({"template_id": tid, "concordancia_redacoes": 1.0, "n_redacoes": len(g)})
            continue
        # For each attribute, fraction of redações that agree with modal value
        frac_agree = []
        for a in attrs:
            vals = g[a].dropna()
            if vals.empty:
                continue
            modal = vals.mode().iloc[0]
            frac_agree.append((vals == modal).mean())
        rows.append({
            "template_id": tid,
            "concordancia_redacoes": float(sum(frac_agree) / len(frac_agree)) if frac_agree else 1.0,
            "n_redacoes": len(g),
        })
    return pd.DataFrame(rows)


def exportar_excel(
    resultados, gabarito, ranking_esperado, casos, path: Path,
) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    pred_pr = _pred_premissas_df(resultados)
    m_atr = pln.metricas_por_atributo(gabarito, pred_pr)
    por_tmpl = desempenho_por_template(resultados, gabarito, casos)
    estab = estabilidade_linguistica(resultados, gabarito, casos)

    resumo_rows = [{"metric": row.atributo, "f1_macro": row.f1_macro, "kappa": row.kappa, "n": row.n}
                   for row in m_atr.itertuples()]
    resumo = pd.DataFrame(resumo_rows)

    with pd.ExcelWriter(path, engine="openpyxl") as w:
        resumo.to_excel(w, sheet_name="resumo", index=False)
        m_atr.to_excel(w, sheet_name="pln_por_atributo", index=False)
        for a in pln.ATRIBUTOS_CATEGORICOS:
            if a in gabarito.columns and a in pred_pr.columns:
                cm = pln.matriz_confusao(a, gabarito, pred_pr)
                cm.to_excel(w, sheet_name=f"confusao_{a}"[:31])
        if not ranking_esperado.empty and ranking_esperado["relevantes"].astype(str).str.strip().any():
            rk = ranking.metricas_completas(ranking_esperado, resultados)
            rk.to_excel(w, sheet_name="ranking_por_caso", index=False)
        por_tmpl.to_excel(w, sheet_name="por_template", index=False)
        estab.to_excel(w, sheet_name="estabilidade", index=False)
```

**Step 4: Run, verify pass**

```bash
pytest tests/test_evaluation_report.py -v
```

Expected: 3 passed.

**Step 5: Commit**

```bash
git add tests/test_evaluation_report.py src/ontomcda/evaluation/report.py
git commit -m "feat(evaluation): per-template, stability, and Excel reporting"
```

---

### Task 19: `evaluation/__main__.py` — evaluation CLI

**Files:**
- Create: `src/ontomcda/evaluation/__main__.py`

**Step 1: Write CLI**

```python
"""CLI: python -m ontomcda.evaluation  — runs full pipeline over data/ and writes outputs/relatorio.xlsx."""
from pathlib import Path

import pandas as pd

from ontomcda import load_profiles, batch_recomendar
from ontomcda.evaluation.report import exportar_excel


def main() -> None:
    owl = "OntoMCDA_final.owl"
    data_dir = Path("data")
    out_path = Path("outputs/relatorio.xlsx")

    profiles = load_profiles(owl)
    casos = pd.read_csv(data_dir / "casos.csv")
    gabarito = pd.read_csv(data_dir / "gabarito_premissas.csv")
    ranking_esperado = pd.read_csv(data_dir / "ranking_esperado.csv")

    resultados = batch_recomendar(casos, profiles, top_k=15)
    exportar_excel(resultados, gabarito, ranking_esperado, casos, out_path)

    print(f"Relatório gerado em {out_path.resolve()}")


if __name__ == "__main__":
    main()
```

**Step 2: Run it**

```bash
python -m ontomcda.evaluation
```

Expected: `Relatório gerado em .../outputs/relatorio.xlsx`

**Step 3: Verify file**

```bash
ls outputs/
```

**Step 4: Commit CLI (outputs/ is gitignored)**

```bash
git add src/ontomcda/evaluation/__main__.py
git commit -m "feat(evaluation): CLI for full pipeline + report export"
```

---

## Phase 5 — Results notebook

### Task 20: Create `notebooks/relatorio_validacao.ipynb`

**Files:**
- Create: `notebooks/relatorio_validacao.ipynb`

**Step 1: Create the notebook via Python (to guarantee valid JSON)**

Write a helper script `scripts/build_notebook.py`:

```python
import json

cells = [
    {"cell_type": "markdown", "metadata": {}, "source": [
        "# Relatório de Validação — OntoMCDA\n",
        "\n",
        "Notebook único de relatório. Toda lógica vive no pacote `ontomcda/`.\n",
        "Executa sequencialmente; cada célula é 1-3 linhas.\n",
    ]},
    {"cell_type": "code", "metadata": {}, "execution_count": None, "outputs": [], "source": [
        "import pandas as pd\n",
        "import matplotlib.pyplot as plt\n",
        "import seaborn as sns\n",
        "from ontomcda import load_profiles, batch_recomendar\n",
        "from ontomcda.evaluation import pln, ranking, bootstrap, report\n",
        "\n",
        "SEED = 42\n",
        "OWL_PATH = '../OntoMCDA_final.owl'\n",
    ]},
    {"cell_type": "markdown", "metadata": {}, "source": ["## 2. Carregar ontologia e dataset"]},
    {"cell_type": "code", "metadata": {}, "execution_count": None, "outputs": [], "source": [
        "profiles = load_profiles(OWL_PATH)\n",
        "casos = pd.read_csv('../data/casos.csv')\n",
        "gabarito = pd.read_csv('../data/gabarito_premissas.csv')\n",
        "ranking_esperado = pd.read_csv('../data/ranking_esperado.csv')\n",
        "n_with_ranking = ranking_esperado['relevantes'].astype(str).str.strip().ne('').sum()\n",
        "print(f'{len(profiles)} métodos | {len(casos)} casos | {n_with_ranking} com ranking esperado')\n",
    ]},
    {"cell_type": "markdown", "metadata": {}, "source": ["## 3. Rodar pipeline"]},
    {"cell_type": "code", "metadata": {}, "execution_count": None, "outputs": [], "source": [
        "resultados = batch_recomendar(casos, profiles, top_k=15)\n",
        "pred_premissas = pd.DataFrame([{'id': r['id'], **r['premissas']} for r in resultados])\n",
        "pred_premissas.head()\n",
    ]},
    {"cell_type": "markdown", "metadata": {}, "source": ["## 4. Métricas PLN por atributo"]},
    {"cell_type": "code", "metadata": {}, "execution_count": None, "outputs": [], "source": [
        "m_atr = pln.metricas_por_atributo(gabarito, pred_premissas)\n",
        "m_atr\n",
    ]},
    {"cell_type": "markdown", "metadata": {}, "source": ["## 5. PLN per-class + matrizes de confusão"]},
    {"cell_type": "code", "metadata": {}, "execution_count": None, "outputs": [], "source": [
        "for atributo in pln.ATRIBUTOS_CATEGORICOS:\n",
        "    if atributo in gabarito.columns and atributo in pred_premissas.columns:\n",
        "        print(f'\\n--- {atributo} ---')\n",
        "        display(pln.per_class_report(atributo, gabarito, pred_premissas))\n",
    ]},
    {"cell_type": "code", "metadata": {}, "execution_count": None, "outputs": [], "source": [
        "fig, axes = plt.subplots(2, 4, figsize=(18, 8))\n",
        "for ax, atributo in zip(axes.flat, pln.ATRIBUTOS_CATEGORICOS):\n",
        "    if atributo in gabarito.columns and atributo in pred_premissas.columns:\n",
        "        pln.plot_matriz_confusao(atributo, gabarito, pred_premissas, ax=ax)\n",
        "plt.tight_layout(); plt.show()\n",
    ]},
    {"cell_type": "markdown", "metadata": {}, "source": ["## 6. Ranking (condicional)"]},
    {"cell_type": "code", "metadata": {}, "execution_count": None, "outputs": [], "source": [
        "if n_with_ranking > 0:\n",
        "    mr = ranking.metricas_completas(ranking_esperado, resultados, ks=[3, 5, 10])\n",
        "    display(mr)\n",
        "    display(mr.mean(numeric_only=True).to_frame('média').T)\n",
        "else:\n",
        "    print('ranking_esperado vazio — pulando camada de ranking')\n",
    ]},
    {"cell_type": "markdown", "metadata": {}, "source": ["## 7. Bootstrap IC 95%"]},
    {"cell_type": "code", "metadata": {}, "execution_count": None, "outputs": [], "source": [
        "ic_rows = []\n",
        "for row in m_atr.itertuples():\n",
        "    # bootstrap the per-case accuracy to get IC on macro accuracy\n",
        "    merged = gabarito.merge(pred_premissas, on='id', suffixes=('_g', '_p'))\n",
        "    per_case = (merged[f'{row.atributo}_g'].astype(str) == merged[f'{row.atributo}_p'].astype(str)).astype(float)\n",
        "    ic = bootstrap.ic_for_metric_over_cases(per_case, n_iter=1000, seed=SEED)\n",
        "    ic_rows.append({'atributo': row.atributo, 'accuracy_mean': ic['mean'], 'lower': ic['lower'], 'upper': ic['upper']})\n",
        "pd.DataFrame(ic_rows)\n",
    ]},
    {"cell_type": "markdown", "metadata": {}, "source": ["## 8. Desempenho por template"]},
    {"cell_type": "code", "metadata": {}, "execution_count": None, "outputs": [], "source": [
        "por_tmpl = report.desempenho_por_template(resultados, gabarito, casos)\n",
        "por_tmpl\n",
    ]},
    {"cell_type": "markdown", "metadata": {}, "source": ["## 9. Estabilidade linguística"]},
    {"cell_type": "code", "metadata": {}, "execution_count": None, "outputs": [], "source": [
        "est = report.estabilidade_linguistica(resultados, gabarito, casos)\n",
        "est\n",
    ]},
    {"cell_type": "markdown", "metadata": {}, "source": ["## 10. Export consolidado"]},
    {"cell_type": "code", "metadata": {}, "execution_count": None, "outputs": [], "source": [
        "from pathlib import Path\n",
        "report.exportar_excel(resultados, gabarito, ranking_esperado, casos, Path('../outputs/relatorio.xlsx'))\n",
        "print('ok')\n",
    ]},
]

nb = {
    "cells": cells,
    "metadata": {"kernelspec": {"name": "python3", "display_name": "Python 3"}, "language_info": {"name": "python"}},
    "nbformat": 4, "nbformat_minor": 5,
}
with open("notebooks/relatorio_validacao.ipynb", "w", encoding="utf-8") as f:
    json.dump(nb, f, indent=1, ensure_ascii=False)
```

**Step 2: Run it**

```bash
mkdir -p notebooks scripts
python scripts/build_notebook.py
```

**Step 3: Execute the notebook headless**

```bash
jupyter nbconvert --to notebook --execute notebooks/relatorio_validacao.ipynb --output relatorio_validacao_executed.ipynb
```

Expected: no errors; `relatorio_validacao_executed.ipynb` created with outputs.

**Step 4: Clean up executed copy (not committed)**

```bash
rm notebooks/relatorio_validacao_executed.ipynb
```

**Step 5: Commit**

```bash
git add notebooks/relatorio_validacao.ipynb scripts/build_notebook.py
git commit -m "feat(notebook): relatorio_validacao notebook with 10 sections"
```

---

## Phase 6 — Documentation

### Task 21: Write `docs/integracao_modulos.md`

**Files:**
- Create: `docs/integracao_modulos.md`

**Step 1: Write the doc per the design spec (Seção 5.1)**

Use an ASCII diagram, analogies, zero jargon without explanation. Target ~2-3 pages. Sections:
- O que o sistema faz (uma frase)
- Fluxo em 4 etapas (ASCII diagram)
- Etapa 1 — Texto
- Etapa 2 — Inferência (analogia do médico)
- Etapa 3 — Consulta à ontologia (analogia do livro)
- Etapa 4 — Ranking
- Os três papéis do código (pipeline, dataset, avaliação)
- Como isso valida a ontologia indiretamente
- Glossário mínimo

ASCII diagram skeleton:

```
  ┌─────────────┐       ┌──────────────┐       ┌───────────────┐       ┌─────────────┐
  │   TEXTO     │──────▶│   INFERÊNCIA │──────▶│   CONSULTA    │──────▶│   RANKING   │
  │  (PT-BR)    │       │     (NLP)    │       │  (ONTOLOGIA)  │       │  (TOP-K)    │
  └─────────────┘       └──────────────┘       └───────────────┘       └─────────────┘
                              │                        │
                              ▼                        ▼
                        premissas               perfis dos ~100
                        (ex: Escolha,           métodos MCDA
                         Cardinal, Grupo)       (AHP, TOPSIS, ...)
```

**Step 2: Commit**

```bash
git add docs/integracao_modulos.md
git commit -m "docs: non-technical module-integration overview"
```

---

### Task 22: Write `docs/metricas.md`

**Files:**
- Create: `docs/metricas.md`

**Step 1: Write the doc per Seção 5.2**

Target ~4-5 pages. For each metric, use the tri-block format:
1. **Em uma frase** — what it measures
2. **Como ler** — ranges, what's good
3. **Por que importa aqui** — why it matters for this project

Cover all metrics listed in design Seção 3. Include a "Limitações declaradas" section at the end (sample size, synthetic dataset, author-curated ranking).

**Step 2: Commit**

```bash
git add docs/metricas.md
git commit -m "docs: non-technical metrics explanation"
```

---

### Task 23: Write `README.md` with full reproduction flow

**Files:**
- Create: `README.md` (replaces any existing)

**Step 1: Write**

```markdown
# OntoMCDA

Recomendador de métodos MCDA a partir de descrição em português, guiado por ontologia OWL.

## Setup

```bash
python -m venv .venv
source .venv/Scripts/activate    # Windows bash
# source .venv/bin/activate      # Linux/Mac
pip install -r requirements.txt -e .
```

Dev extras: `pip install -r requirements-dev.txt`.

## Reproduzir a validação

```bash
python -m ontomcda.dataset       # regenera data/
python -m ontomcda.evaluation    # gera outputs/relatorio.xlsx
jupyter lab notebooks/relatorio_validacao.ipynb
```

## Uso programático

```python
from ontomcda import load_profiles, recomendar
p = load_profiles("OntoMCDA_final.owl")
r = recomendar("Um analista precisa escolher o melhor fornecedor...", p, top_k=5)
print(r["aceitos"])
```

## Testes

```bash
pytest              # all tests
pytest -k nlp       # NLP layer only
ruff check .
```

## Estrutura

Ver `CLAUDE.md` e `docs/integracao_modulos.md`.

## Validação

Ver `docs/metricas.md` para explicação das métricas.
Dataset sintético: `data/casos.csv`, `data/gabarito_premissas.csv`.
Templates documentados em `data/templates.json`.
```

**Step 2: Commit**

```bash
git add README.md
git commit -m "docs: top-level README with setup, reproduction, and usage"
```

---

## Phase 7 — Cleanup

### Task 24: Archive old notebooks and update CLAUDE.md

**Files:**
- Move: `OntoMCDA_final.ipynb` → `legacy/OntoMCDA_final.ipynb`
- Move: `OntoMCDA_metrica PLN.ipynb` → `legacy/OntoMCDA_metrica PLN.ipynb`
- Modify: `CLAUDE.md`

**Step 1: Move old notebooks**

```bash
mkdir legacy
git mv OntoMCDA_final.ipynb legacy/
git mv "OntoMCDA_metrica PLN.ipynb" legacy/
```

**Step 2: Update `CLAUDE.md`** to reflect new architecture

Replace the "Repository layout" and "Running the notebooks" sections with:
- New package structure (`src/ontomcda/`)
- venv-based setup
- CLI entry points
- Pointer to `docs/integracao_modulos.md` and `docs/metricas.md`

Keep the "Dual-namespace OWL pattern" section — it's still true for `src/ontomcda/ontology.py`.

Note under "Legacy" that `legacy/*.ipynb` are the original Colab notebooks, preserved for traceability.

**Step 3: Commit**

```bash
git add legacy/ CLAUDE.md
git commit -m "chore: archive original notebooks to legacy/ and update CLAUDE.md"
```

---

### Task 25: Full end-to-end validation and tag

**Step 1: Clean reproduction from scratch**

```bash
deactivate 2>/dev/null
rm -rf .venv outputs
python -m venv .venv
source .venv/Scripts/activate
pip install -r requirements.txt -e .
python -m ontomcda.dataset
python -m ontomcda.evaluation
ls outputs/relatorio.xlsx
```

Expected: `outputs/relatorio.xlsx` exists.

**Step 2: Run full test + lint**

```bash
pytest -v
ruff check .
```

Expected: all tests pass, lint is clean.

**Step 3: Execute the notebook headless**

```bash
jupyter nbconvert --to notebook --execute notebooks/relatorio_validacao.ipynb --output relatorio_validacao_executed.ipynb
```

Expected: no errors.

**Step 4: Clean up executed notebook**

```bash
rm notebooks/relatorio_validacao_executed.ipynb
```

**Step 5: Tag release**

```bash
git tag -a v1.0.0 -m "Refactored package with venv, tests, dataset templates, and refined metrics"
```

**Step 6: Final verification: code review**

Use @superpowers:requesting-code-review to check:
- All tests green
- No `google.colab` or `ipywidgets` imports remain
- No lint errors
- Design doc decisions all implemented
- `docs/integracao_modulos.md` has the ASCII diagram
- `docs/metricas.md` covers all metrics from design Seção 3

---

## Out of scope (per design doc)

- Modifications to `OntoMCDA_final.owl`
- Legacy-namespace cleanup
- Catalog reduction
- Ontology structural metrics / competency questions / reasoner
- GitHub Actions CI
- Docker
- Pre-commit hooks
- Interactive widget UI

## Checkpoints for review

After **Phase 2** (Task 11), **Phase 3** (Task 14), **Phase 4** (Task 19), and **Phase 7** (Task 25), pause for code review using @superpowers:requesting-code-review.

## Ordering rationale

- Phase 1 unblocks everything (venv + pyproject).
- Phase 2 (pipeline) must precede Phase 3 (dataset generator) because the generator does not strictly depend on the pipeline, but Phase 4 (evaluation) needs both. Doing them in sequence keeps commits focused.
- Phase 3 before Phase 4 because the evaluation tests use the generated CSVs.
- Phase 5 (notebook) after Phase 4 because the notebook imports from `evaluation/`.
- Phase 6 (docs) after the code stabilizes — avoid rewriting docs when code is still moving.
- Phase 7 (cleanup + tag) last.
