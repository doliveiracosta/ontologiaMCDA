import json
import uuid
from pathlib import Path


def _cell_id():
    return uuid.uuid4().hex[:8]


cells = [
    {
        "cell_type": "markdown",
        "id": _cell_id(),
        "metadata": {},
        "source": [
            "# Relatório de Validação — OntoMCDA\n",
            "\n",
            "Notebook único de relatório. Toda lógica vive no pacote `ontomcda/`.\n",
            "Executa sequencialmente; cada célula é 1-3 linhas.\n",
        ],
    },
    {
        "cell_type": "markdown",
        "metadata": {},
        "source": ["## 1. Imports e configuração"],
    },
    {
        "cell_type": "code",
        "metadata": {},
        "execution_count": None,
        "outputs": [],
        "source": [
            "import pandas as pd\n",
            "import matplotlib.pyplot as plt\n",
            "from ontomcda import load_profiles, batch_recomendar\n",
            "from ontomcda.evaluation import pln, ranking, bootstrap, report\n",
            "\n",
            "SEED = 42\n",
            "OWL_PATH = '../OntoMCDA_final.owl'\n",
        ],
    },
    {
        "cell_type": "markdown",
        "metadata": {},
        "source": ["## 2. Carregar ontologia e dataset"],
    },
    {
        "cell_type": "code",
        "metadata": {},
        "execution_count": None,
        "outputs": [],
        "source": [
            "profiles = load_profiles(OWL_PATH)\n",
            "casos = pd.read_csv('../data/casos.csv')\n",
            "gabarito = pd.read_csv('../data/gabarito_premissas.csv')\n",
            "ranking_esperado = pd.read_csv('../data/ranking_esperado.csv')\n",
            "n_with_ranking = (\n",
            "    ranking_esperado['relevantes'].astype(str).str.strip().ne('').sum()\n",
            ")\n",
            "print(\n",
            "    f'{len(profiles)} métodos | {len(casos)} casos'"
            " f' | {n_with_ranking} com ranking esperado'\n",
            ")\n",
        ],
    },
    {
        "cell_type": "markdown",
        "metadata": {},
        "source": ["## 3. Rodar pipeline"],
    },
    {
        "cell_type": "code",
        "metadata": {},
        "execution_count": None,
        "outputs": [],
        "source": [
            "resultados = batch_recomendar(casos, profiles, top_k=15)\n",
            "pred_premissas = pd.DataFrame(\n",
            "    [{'id': r['id'], **r['premissas']} for r in resultados]\n",
            ")\n",
            "pred_premissas.head()\n",
        ],
    },
    {
        "cell_type": "markdown",
        "metadata": {},
        "source": ["## 4. Métricas PLN por atributo"],
    },
    {
        "cell_type": "code",
        "metadata": {},
        "execution_count": None,
        "outputs": [],
        "source": [
            "m_atr = pln.metricas_por_atributo(gabarito, pred_premissas)\n",
            "m_atr\n",
        ],
    },
    {
        "cell_type": "markdown",
        "metadata": {},
        "source": ["## 5. PLN per-class + matrizes de confusão"],
    },
    {
        "cell_type": "code",
        "metadata": {},
        "execution_count": None,
        "outputs": [],
        "source": [
            "for atributo in pln.ATRIBUTOS_CATEGORICOS:\n",
            "    if atributo in gabarito.columns and atributo in pred_premissas.columns:\n",
            "        print(f'\\n--- {atributo} ---')\n",
            "        display(pln.per_class_report(atributo, gabarito, pred_premissas))\n",
        ],
    },
    {
        "cell_type": "code",
        "metadata": {},
        "execution_count": None,
        "outputs": [],
        "source": [
            "fig, axes = plt.subplots(2, 4, figsize=(18, 8))\n",
            "for ax, atributo in zip(axes.flat, pln.ATRIBUTOS_CATEGORICOS):\n",
            "    if atributo in gabarito.columns and atributo in pred_premissas.columns:\n",
            "        pln.plot_matriz_confusao(atributo, gabarito, pred_premissas, ax=ax)\n",
            "plt.tight_layout(); plt.show()\n",
        ],
    },
    {
        "cell_type": "markdown",
        "metadata": {},
        "source": ["## 6. Ranking (condicional)"],
    },
    {
        "cell_type": "code",
        "metadata": {},
        "execution_count": None,
        "outputs": [],
        "source": [
            "if n_with_ranking > 0:\n",
            "    mr = ranking.metricas_completas(ranking_esperado, resultados, ks=[3, 5, 10])\n",
            "    display(mr)\n",
            "    display(mr.mean(numeric_only=True).to_frame('média').T)\n",
            "else:\n",
            "    print('ranking_esperado vazio — pulando camada de ranking')\n",
        ],
    },
    {
        "cell_type": "markdown",
        "metadata": {},
        "source": ["## 7. Bootstrap IC 95%"],
    },
    {
        "cell_type": "code",
        "metadata": {},
        "execution_count": None,
        "outputs": [],
        "source": [
            "ic_rows = []\n",
            "for row in m_atr.itertuples():\n",
            "    col_g = f'{row.atributo}_g'\n",
            "    col_p = f'{row.atributo}_p'\n",
            "    merged = gabarito[['id', row.atributo]].merge(\n",
            "        pred_premissas[['id', row.atributo]], on='id', suffixes=('_g', '_p')\n",
            "    )\n",
            "    if col_g not in merged.columns or col_p not in merged.columns:\n",
            "        continue\n",
            "    per_case = (\n",
            "        (merged[col_g].astype(str) == merged[col_p].astype(str)).astype(float)\n",
            "    )\n",
            "    ic = bootstrap.ic_for_metric_over_cases(per_case, n_iter=1000, seed=SEED)\n",
            "    ic_rows.append({'atributo': row.atributo, 'accuracy_mean': ic['mean'],\n",
            "                    'lower': ic['lower'], 'upper': ic['upper']})\n",
            "pd.DataFrame(ic_rows)\n",
        ],
    },
    {
        "cell_type": "markdown",
        "metadata": {},
        "source": ["## 8. Desempenho por template"],
    },
    {
        "cell_type": "code",
        "metadata": {},
        "execution_count": None,
        "outputs": [],
        "source": [
            "por_tmpl = report.desempenho_por_template(resultados, gabarito, casos)\n",
            "por_tmpl\n",
        ],
    },
    {
        "cell_type": "markdown",
        "metadata": {},
        "source": ["## 9. Estabilidade linguística"],
    },
    {
        "cell_type": "code",
        "metadata": {},
        "execution_count": None,
        "outputs": [],
        "source": [
            "est = report.estabilidade_linguistica(resultados, gabarito, casos)\n",
            "est\n",
        ],
    },
    {
        "cell_type": "markdown",
        "metadata": {},
        "source": ["## 10. Export consolidado"],
    },
    {
        "cell_type": "code",
        "metadata": {},
        "execution_count": None,
        "outputs": [],
        "source": [
            "from pathlib import Path\n",
            "report.exportar_excel(resultados, gabarito, ranking_esperado, casos,\n",
            "                      Path('../outputs/relatorio.xlsx'))\n",
            "print('ok')\n",
        ],
    },
]

for cell in cells:
    if "id" not in cell:
        cell["id"] = _cell_id()

nb = {
    "cells": cells,
    "metadata": {
        "kernelspec": {"name": "python3", "display_name": "Python 3"},
        "language_info": {"name": "python"},
    },
    "nbformat": 4,
    "nbformat_minor": 5,
}

out = Path("notebooks/relatorio_validacao.ipynb")
out.parent.mkdir(parents=True, exist_ok=True)
with open(out, "w", encoding="utf-8") as f:
    json.dump(nb, f, indent=1, ensure_ascii=False)

print(f"Notebook escrito em {out.resolve()}")
