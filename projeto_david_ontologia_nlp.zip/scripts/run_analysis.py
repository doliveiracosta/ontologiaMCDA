"""Executa pipeline completo e gera métricas + gráficos para análise."""
import warnings
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns

warnings.filterwarnings("ignore")

from ontomcda import batch_recomendar, load_profiles
from ontomcda.evaluation import bootstrap, pln, report

OUT = Path("outputs/analysis")
OUT.mkdir(parents=True, exist_ok=True)

print("Carregando ontologia...")
profiles = load_profiles("OntoMCDA_final.owl")
casos = pd.read_csv("data/casos.csv")
gabarito = pd.read_csv("data/gabarito_premissas.csv")

print(f"  {len(profiles)} métodos | {len(casos)} casos")

print("Rodando pipeline...")
resultados = batch_recomendar(casos, profiles, top_k=15)
pred = pd.DataFrame([{"id": r["id"], **r["premissas"]} for r in resultados])

# ── 1. Métricas PLN por atributo ──────────────────────────────────────────────
print("\n=== MÉTRICAS PLN POR ATRIBUTO ===")
m = pln.metricas_por_atributo(gabarito, pred)
print(m[["atributo", "accuracy", "f1_macro", "kappa", "n"]].to_string(index=False))

# ── 2. Taxa de não-inferido ───────────────────────────────────────────────────
print("\n=== TAXA DE NÃO-INFERIDO ===")
taxa = pln.taxa_nao_inferido(pred)
print(taxa[taxa > 0].to_string() if (taxa > 0).any() else "  nenhum atributo com não-inferido")

# ── 3. Bootstrap IC 95% ───────────────────────────────────────────────────────
print("\n=== BOOTSTRAP IC 95% (accuracy) ===")
ic_rows = []
for row in m.itertuples():
    merged = gabarito[["id", row.atributo]].merge(
        pred[["id", row.atributo]], on="id", suffixes=("_g", "_p")
    )
    col_g, col_p = f"{row.atributo}_g", f"{row.atributo}_p"
    if col_g not in merged.columns:
        continue
    per_case = (merged[col_g].astype(str) == merged[col_p].astype(str)).astype(float)
    ic = bootstrap.ic_for_metric_over_cases(per_case, n_iter=1000, seed=42)
    ic_rows.append({
        "atributo": row.atributo,
        "mean": round(ic["mean"], 3),
        "lower": round(ic["lower"], 3),
        "upper": round(ic["upper"], 3),
    })
    print(f"  {row.atributo:<22} {ic['mean']:.3f}  [{ic['lower']:.3f}, {ic['upper']:.3f}]")

ic_df = pd.DataFrame(ic_rows)

# ── 4. Estabilidade linguística ───────────────────────────────────────────────
print("\n=== ESTABILIDADE LINGUÍSTICA ===")
est = report.estabilidade_linguistica(resultados, gabarito, casos)
print(est.sort_values("concordancia_redacoes").to_string(index=False))

# ═══════════════════════════════════════════════════════════════════
# GRÁFICO 1 — F1 macro por atributo (barras horizontais)
# ═══════════════════════════════════════════════════════════════════
fig, ax = plt.subplots(figsize=(8, 4))
colors = ["#2ecc71" if v >= 0.8 else "#f39c12" if v >= 0.6 else "#e74c3c"
          for v in m["f1_macro"]]
bars = ax.barh(m["atributo"], m["f1_macro"], color=colors, edgecolor="white")
ax.axvline(0.8, color="green", linestyle="--", linewidth=1, alpha=0.6, label="0.80")
ax.axvline(0.6, color="orange", linestyle="--", linewidth=1, alpha=0.6, label="0.60")
ax.set_xlabel("F1 Macro")
ax.set_title("F1 Macro por Atributo")
ax.set_xlim(0, 1.05)
for bar, val in zip(bars, m["f1_macro"]):
    ax.text(val + 0.01, bar.get_y() + bar.get_height() / 2,
            f"{val:.2f}", va="center", fontsize=9)
ax.legend(fontsize=8)
plt.tight_layout()
plt.savefig(OUT / "f1_por_atributo.png", dpi=150)
plt.close()
print("\nGráfico salvo: outputs/analysis/f1_por_atributo.png")

# ═══════════════════════════════════════════════════════════════════
# GRÁFICO 2 — Bootstrap IC 95% (errorbar)
# ═══════════════════════════════════════════════════════════════════
fig, ax = plt.subplots(figsize=(8, 4))
y = range(len(ic_df))
ax.barh(ic_df["atributo"], ic_df["mean"], color="#3498db", alpha=0.7)
ax.errorbar(
    ic_df["mean"], ic_df["atributo"],
    xerr=[ic_df["mean"] - ic_df["lower"], ic_df["upper"] - ic_df["mean"]],
    fmt="none", color="black", capsize=4, linewidth=1.5
)
ax.axvline(0.8, color="green", linestyle="--", linewidth=1, alpha=0.6)
ax.set_xlabel("Accuracy (IC 95%)")
ax.set_title("Bootstrap IC 95% — Accuracy por Atributo")
ax.set_xlim(0, 1.1)
plt.tight_layout()
plt.savefig(OUT / "bootstrap_ic.png", dpi=150)
plt.close()
print("Gráfico salvo: outputs/analysis/bootstrap_ic.png")

# ═══════════════════════════════════════════════════════════════════
# GRÁFICO 3 — Matrizes de confusão (atributos com >1 classe)
# ═══════════════════════════════════════════════════════════════════
attrs_com_confusao = [
    a for a in pln.ATRIBUTOS_CATEGORICOS
    if a in gabarito.columns and a in pred.columns
    and gabarito[a].nunique() > 1
]
n = len(attrs_com_confusao)
ncols = 3
nrows = (n + ncols - 1) // ncols
fig, axes = plt.subplots(nrows, ncols, figsize=(5 * ncols, 4 * nrows))
axes = axes.flat

for ax, attr in zip(axes, attrs_com_confusao):
    cm = pln.matriz_confusao(attr, gabarito, pred)
    sns.heatmap(cm, annot=True, fmt="d", cmap="Blues", ax=ax,
                cbar=False, linewidths=0.5)
    ax.set_title(attr, fontsize=10)
    ax.set_xlabel("predito", fontsize=8)
    ax.set_ylabel("gabarito", fontsize=8)
    ax.tick_params(labelsize=7)

for ax in list(axes)[len(attrs_com_confusao):]:
    ax.set_visible(False)

plt.suptitle("Matrizes de Confusão por Atributo", fontsize=13, y=1.01)
plt.tight_layout()
plt.savefig(OUT / "matrizes_confusao.png", dpi=150, bbox_inches="tight")
plt.close()
print("Gráfico salvo: outputs/analysis/matrizes_confusao.png")

# ═══════════════════════════════════════════════════════════════════
# GRÁFICO 4 — Estabilidade linguística por template
# ═══════════════════════════════════════════════════════════════════
fig, ax = plt.subplots(figsize=(9, 4))
colors_est = ["#2ecc71" if v == 1.0 else "#f39c12" if v >= 0.8 else "#e74c3c"
              for v in est["concordancia_redacoes"]]
ax.bar(est["template_id"], est["concordancia_redacoes"], color=colors_est, edgecolor="white")
ax.axhline(1.0, color="green", linestyle="--", linewidth=1, alpha=0.6)
ax.axhline(0.8, color="orange", linestyle="--", linewidth=1, alpha=0.6)
ax.set_ylim(0, 1.1)
ax.set_ylabel("Concordância entre redações")
ax.set_title("Estabilidade Linguística por Template")
plt.xticks(rotation=30, ha="right", fontsize=8)
plt.tight_layout()
plt.savefig(OUT / "estabilidade.png", dpi=150)
plt.close()
print("Gráfico salvo: outputs/analysis/estabilidade.png")

print("\nAnálise completa.")
