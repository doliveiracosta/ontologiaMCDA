"""OntoMCDA — ontology-driven MCDA method recommender."""
from ontomcda.ontology import load_profiles
from ontomcda.pipeline import batch_recomendar, recomendar

__version__ = "1.0.0"
__all__ = ["recomendar", "batch_recomendar", "load_profiles"]
