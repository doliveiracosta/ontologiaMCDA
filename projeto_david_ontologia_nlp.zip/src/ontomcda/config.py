"""Shared constants for the OntoMCDA pipeline.

Source of truth for attribute names, ontology namespaces, scoring weights,
and the NLP→ontology attribute mapping. Matches the contract used by the
original notebook so that OntoMCDA_final.owl works unchanged.
"""

NEW_NS = "http://www.ontomcda.org/onto#"
OLD_NS = "http://www.ontomcda.org/onto#OntologyMCDA#"

ATTRS = [
    "tipo_problema",
    "compensatoriedade",
    "tipo_variavel",
    "monotonicidade",
    "estrutura_decisoria",
    "completude_pref",
    "ambiente_decisao",
    "ponderabilidade",
    "usa_pesos",
    "requer_pesos",
    "gera_pesos",
    "auxilia_gerar_pesos",
    "sugere_pesos",
]

DATA_ATTRS = {
    "usa_pesos",
    "requer_pesos",
    "gera_pesos",
    "auxilia_gerar_pesos",
    "sugere_pesos",
}

HIDE_FROM_PREMISSES_PRINT = {
    "gera_pesos",
    "auxilia_gerar_pesos",
    "sugere_pesos",
}

MANDATORY_QUERY_ATTRS = ["tipo_problema"]

ATTR_WEIGHTS = {
    "tipo_problema": 4.0,
    "compensatoriedade": 3.5,
    "tipo_variavel": 3.0,
    "monotonicidade": 2.0,
    "estrutura_decisoria": 2.0,
    "completude_pref": 1.5,
    "ambiente_decisao": 2.0,
    "ponderabilidade": 1.5,
    "usa_pesos": 1.5,
    "requer_pesos": 1.2,
    "gera_pesos": 0.8,
    "auxilia_gerar_pesos": 1.0,
    "sugere_pesos": 0.5,
}

BOOTSTRAP_SEED = 42
BOOTSTRAP_ITERATIONS = 1000
