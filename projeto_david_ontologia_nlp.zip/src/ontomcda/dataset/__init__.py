"""Synthetic dataset generation for validation."""
