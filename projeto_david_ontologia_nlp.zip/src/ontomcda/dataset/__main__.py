"""CLI: python -m ontomcda.dataset  — regenerates data/ CSVs."""
from pathlib import Path

from ontomcda.dataset.generator import escrever_csvs, gerar_casos


def main() -> None:
    out = gerar_casos()
    target = Path("data")
    escrever_csvs(out, target)
    print(f"Wrote {len(out['casos'])} cases -> {target.resolve()}")


if __name__ == "__main__":
    main()
