"""Generate the four dataset CSVs from templates."""
import json
from pathlib import Path

import pandas as pd

from ontomcda.dataset.templates import TEMPLATES


def gerar_casos() -> dict[str, pd.DataFrame]:
    casos_rows = []
    gabarito_rows = []
    for tmpl in TEMPLATES:
        for i, redacao in enumerate(tmpl.redacoes, start=1):
            case_id = f"{tmpl.id}-r{i}"
            casos_rows.append({
                "id": case_id,
                "template_id": tmpl.id,
                "redacao_idx": i,
                "texto": redacao,
            })
            gabarito_rows.append({"id": case_id, **tmpl.premissas})

    casos_df = pd.DataFrame(casos_rows)
    gabarito_df = pd.DataFrame(gabarito_rows)
    ranking_df = pd.DataFrame({"id": casos_df["id"], "relevantes": [None] * len(casos_df)})

    return {
        "casos": casos_df,
        "gabarito": gabarito_df,
        "ranking_esperado": ranking_df,
    }


def escrever_csvs(data: dict[str, pd.DataFrame], out_dir: Path) -> None:
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    data["casos"].to_csv(out_dir / "casos.csv", index=False, encoding="utf-8")
    data["gabarito"].to_csv(out_dir / "gabarito_premissas.csv", index=False, encoding="utf-8")
    data["ranking_esperado"].to_csv(out_dir / "ranking_esperado.csv", index=False, encoding="utf-8")

    manifest = {
        "templates": [
            {
                "id": t.id,
                "premissas": t.premissas,
                "n_redacoes": len(t.redacoes),
            }
            for t in TEMPLATES
        ],
    }
    (out_dir / "templates.json").write_text(
        json.dumps(manifest, indent=2, ensure_ascii=False), encoding="utf-8"
    )
