"""Synthetic case templates.

Each template fixes a known premise profile (the gold standard) and lists
3 PT-BR redações that reword the same situation differently. This stresses
the NLP layer against synonyms/restructuring without changing the gold.

Template arrangement follows the orthogonal design in the validation design doc.
Each redação includes explicit surface forms for all high-weight attributes so
the NLP pipeline can infer the gold label without paraphrase gaps.
"""
from dataclasses import dataclass


@dataclass
class Template:
    id: str
    premissas: dict[str, str]
    redacoes: list[str]


TEMPLATES: list[Template] = [
    # -----------------------------------------------------------------
    # T01 — Escolha / Cardinal / Individual / Compensatorio / Completo
    # -----------------------------------------------------------------
    Template(
        id="T01_escolha_cardinal_individual",
        premissas={
            "tipo_problema": "Escolha",
            "tipo_variavel": "Cardinal",
            "estrutura_decisoria": "Individual",
            "compensatoriedade": "Compensatorio",
            "monotonicidade": "Monotonico",
            "completude_pref": "Completo",
            "ambiente_decisao": "Certeza",
            "ponderabilidade": "Ponderavel",
            "usa_pesos": "Sim",
            "requer_pesos": "Sim",
        },
        redacoes=[
            "Um gerente precisa escolher o fornecedor mais adequado entre quatro opcoes. "
            "Os criterios sao numericos (custo, prazo, qualidade de entrega) e admitem trade-off. "
            "O decisor atribui pesos explicitos e trabalha em ambiente de certeza, "
            "com preferencias completas entre todas as alternativas.",

            "Selecao da melhor alternativa de investimento por um unico analista. "
            "Dados quantitativos completos estao disponiveis em ambiente deterministico. "
            "Admite-se compensacao entre criterios ponderados, "
            "e o decisor conhece todas as preferencias.",

            "Um engenheiro precisa escolher entre tres equipamentos industriais. "
            "Todos os indicadores sao numericos com pesos explicitos; "
            "o desempenho fraco em um criterio pode ser compensado por outro. "
            "O ambiente de decisao e de certeza e as preferencias sao completas.",
        ],
    ),

    # -----------------------------------------------------------------
    # T02 — Escolha / Mista / Grupo / ParcialmenteCompensatorio / Incompleto
    # -----------------------------------------------------------------
    Template(
        id="T02_escolha_mista_grupo",
        premissas={
            "tipo_problema": "Escolha",
            "tipo_variavel": "Mista",
            "estrutura_decisoria": "Grupo",
            "compensatoriedade": "ParcialmenteCompensatorio",
            "monotonicidade": "Monotonico",
            "completude_pref": "Incompleto",
            "ambiente_decisao": "Incerteza",
            "ponderabilidade": "Ponderavel",
            "usa_pesos": "Sim",
            "requer_pesos": "Sim",
        },
        redacoes=[
            "Um comite precisa escolher a melhor proposta entre cinco candidatas. "
            "Os criterios sao mistos: indicadores numericos e avaliacoes qualitativas. "
            "As preferencias entre algumas propostas sao incompletas devido a incerteza. "
            "A compensacao e apenas parcial entre os criterios ponderados.",

            "Uma equipe de especialistas precisa selecionar o fornecedor mais adequado "
            "considerando criterios quantitativos e qualitativos em ambiente de incerteza. "
            "O grupo admite compensacao parcial e possui preferencias incompletas "
            "sobre algumas alternativas.",

            "Decisao em grupo para escolher a melhor tecnologia de automacao. "
            "Os avaliadores utilizam variaveis mistas com pesos e aceitam compensacao parcial. "
            "As preferencias do grupo sao incompletas e o contexto envolve incerteza.",
        ],
    ),

    # -----------------------------------------------------------------
    # T03 — Escolha / Ordinal / Grupo / NaoCompensatorio / Incompleto
    # -----------------------------------------------------------------
    Template(
        id="T03_escolha_ordinal_grupo",
        premissas={
            "tipo_problema": "Escolha",
            "tipo_variavel": "Ordinal",
            "estrutura_decisoria": "Grupo",
            "compensatoriedade": "NaoCompensatorio",
            "monotonicidade": "Monotonico",
            "completude_pref": "Incompleto",
            "ambiente_decisao": "Incerteza",
            "ponderabilidade": "Ponderavel",
            "usa_pesos": "Sim",
            "requer_pesos": "Sim",
        },
        redacoes=[
            "Um painel de especialistas precisa escolher o melhor candidato. "
            "As avaliacoes sao qualitativas ordenadas (alto, medio, baixo). "
            "A decisao e nao compensatoria: um criterio fraco nao pode ser compensado por outro. "
            "As preferencias do grupo sao incompletas em ambiente de incerteza.",

            "Uma comissao precisa selecionar a melhor proposta com escalas verbais ordinais. "
            "O processo nao admite compensacao entre criterios ponderados. "
            "Algumas preferencias permanecem desconhecidas e o ambiente e de incerteza.",

            "Um colegiado precisa escolher entre projetos avaliados por julgamentos ordinais. "
            "A decisao nao compensatoria implica veto; nenhum desempenho pode compensar outro. "
            "As preferencias sao incompletas e ha incerteza nas avaliacoes subjetivas.",
        ],
    ),

    # -----------------------------------------------------------------
    # T04 — Ordenacao / Cardinal / Individual / Compensatorio / Completo
    # -----------------------------------------------------------------
    Template(
        id="T04_ordenacao_cardinal_individual",
        premissas={
            "tipo_problema": "Ordenacao",
            "tipo_variavel": "Cardinal",
            "estrutura_decisoria": "Individual",
            "compensatoriedade": "Compensatorio",
            "monotonicidade": "Monotonico",
            "completude_pref": "Completo",
            "ambiente_decisao": "Certeza",
            "ponderabilidade": "Ponderavel",
            "usa_pesos": "Sim",
            "requer_pesos": "Sim",
        },
        redacoes=[
            "Um analista precisa ordenar projetos de investimento do mais ao menos rentavel. "
            "Os criterios sao numericos e admitem trade-off com pesos explicitos. "
            "O decisor trabalha em ambiente de certeza "
            "e as preferencias entre todos os projetos sao completas.",

            "Um gestor deve gerar um ranking de fornecedores com indicadores quantitativos. "
            "A compensacao entre criterios ponderados e permitida. "
            "O ambiente e deterministico e o decisor possui preferencias completas.",

            "Um unico especialista precisa hierarquizar alternativas de expansao "
            "usando dados numericos com pesos e compensacao entre criterios. "
            "O ambiente de certeza garante preferencias completas entre todas as opcoes.",
        ],
    ),

    # -----------------------------------------------------------------
    # T05 — Ordenacao / Mista / Grupo / ParcialmenteCompensatorio / Incompleto
    # -----------------------------------------------------------------
    Template(
        id="T05_ordenacao_mista_grupo",
        premissas={
            "tipo_problema": "Ordenacao",
            "tipo_variavel": "Mista",
            "estrutura_decisoria": "Grupo",
            "compensatoriedade": "ParcialmenteCompensatorio",
            "monotonicidade": "Monotonico",
            "completude_pref": "Incompleto",
            "ambiente_decisao": "Incerteza",
            "ponderabilidade": "Ponderavel",
            "usa_pesos": "Sim",
            "requer_pesos": "Sim",
        },
        redacoes=[
            "Um comite precisa ordenar projetos para definir prioridade. "
            "Os criterios sao mistos: variaveis quantitativas e qualitativas. "
            "As preferencias entre alguns projetos sao incompletas "
            "e a compensacao e apenas parcial em ambiente de incerteza.",

            "Uma equipe de gestores deve ranquear candidatos a financiamento. "
            "Os criterios incluem indicadores numericos e avaliacoes qualitativas com pesos. "
            "Admite-se compensacao parcial; as preferencias sao incompletas e ha incerteza.",

            "Um grupo de avaliadores precisa estabelecer ordem de prioridade entre propostas. "
            "Os criterios mistos sao ponderados e a compensacao entre eles e limitada. "
            "As preferencias do grupo sao incompletas em contexto de incerteza.",
        ],
    ),

    # -----------------------------------------------------------------
    # T06 — Ordenacao / Ordinal / Grupo / NaoCompensatorio / Incompleto
    # -----------------------------------------------------------------
    Template(
        id="T06_ordenacao_ordinal_grupo",
        premissas={
            "tipo_problema": "Ordenacao",
            "tipo_variavel": "Ordinal",
            "estrutura_decisoria": "Grupo",
            "compensatoriedade": "NaoCompensatorio",
            "monotonicidade": "Monotonico",
            "completude_pref": "Incompleto",
            "ambiente_decisao": "Incerteza",
            "ponderabilidade": "Ponderavel",
            "usa_pesos": "Sim",
            "requer_pesos": "Sim",
        },
        redacoes=[
            "Uma comissao deve ordenar candidatos com avaliacoes qualitativas ordenadas. "
            "A decisao e nao compensatoria: criterios ponderados nao se compensam entre si. "
            "Algumas preferencias do grupo sao incompletas em ambiente de incerteza.",

            "Um painel de especialistas gera um ranking de projetos "
            "com julgamentos ordinais e pesos por criterio. "
            "Nao ha compensacao entre os criterios "
            "e as preferencias sao incompletas com incerteza nas avaliacoes.",

            "Um colegiado precisa hierarquizar fornecedores "
            "por escalas verbais (alto, medio, baixo). "
            "A decisao nao compensatoria e com preferencias incompletas "
            "reflete subjetividade e incerteza nas avaliacoes do grupo.",
        ],
    ),

    # -----------------------------------------------------------------
    # T07 — Classificacao / Cardinal / Individual / Compensatorio / Completo
    # -----------------------------------------------------------------
    Template(
        id="T07_classificacao_cardinal_individual",
        premissas={
            "tipo_problema": "Classificacao",
            "tipo_variavel": "Cardinal",
            "estrutura_decisoria": "Individual",
            "compensatoriedade": "Compensatorio",
            "monotonicidade": "Monotonico",
            "completude_pref": "Completo",
            "ambiente_decisao": "Certeza",
            "ponderabilidade": "Ponderavel",
            "usa_pesos": "Sim",
            "requer_pesos": "Sim",
        },
        redacoes=[
            "Um analista precisa classificar projetos em categorias de risco "
            "usando indicadores numericos com pesos. "
            "Os criterios admitem trade-off em ambiente de certeza, "
            "com preferencias completas entre todas as alternativas.",

            "Um gestor enquadra fornecedores em classes de desempenho previamente definidas. "
            "Os dados sao quantitativos, a compensacao entre criterios ponderados e permitida "
            "e o ambiente e deterministico com preferencias completas.",

            "Um unico avaliador categoriza equipamentos em faixas de qualidade "
            "usando metricas numericas e pesos por criterio. "
            "A compensacao e admitida; o ambiente de certeza permite preferencias completas.",
        ],
    ),

    # -----------------------------------------------------------------
    # T08 — Classificacao / Mista / Grupo / ParcialmenteCompensatorio / Incompleto
    # -----------------------------------------------------------------
    Template(
        id="T08_classificacao_mista_grupo",
        premissas={
            "tipo_problema": "Classificacao",
            "tipo_variavel": "Mista",
            "estrutura_decisoria": "Grupo",
            "compensatoriedade": "ParcialmenteCompensatorio",
            "monotonicidade": "Monotonico",
            "completude_pref": "Incompleto",
            "ambiente_decisao": "Incerteza",
            "ponderabilidade": "Ponderavel",
            "usa_pesos": "Sim",
            "requer_pesos": "Sim",
        },
        redacoes=[
            "Um comite classifica propostas em categorias previamente definidas. "
            "Os criterios sao mistos: dados numericos e avaliacoes qualitativas com pesos. "
            "A compensacao e parcial e as preferencias do grupo sao incompletas "
            "em ambiente de incerteza.",

            "Uma equipe de especialistas aloca projetos em classes de risco "
            "usando criterios quantitativos e qualitativos. "
            "Admite-se compensacao parcial; as preferencias sao incompletas e ha incerteza.",

            "Um grupo de avaliadores enquadra candidatos em categorias pre-definidas. "
            "Os criterios mistos sao ponderados e a compensacao entre eles e limitada. "
            "As preferencias do grupo sao incompletas em contexto de incerteza.",
        ],
    ),

    # -----------------------------------------------------------------
    # T09 — Classificacao / Ordinal / Individual / NaoCompensatorio / Completo
    # -----------------------------------------------------------------
    Template(
        id="T09_classificacao_ordinal_individual",
        premissas={
            "tipo_problema": "Classificacao",
            "tipo_variavel": "Ordinal",
            "estrutura_decisoria": "Individual",
            "compensatoriedade": "NaoCompensatorio",
            "monotonicidade": "Monotonico",
            "completude_pref": "Completo",
            "ambiente_decisao": "Certeza",
            "ponderabilidade": "Ponderavel",
            "usa_pesos": "Sim",
            "requer_pesos": "Sim",
        },
        redacoes=[
            "Um auditor classifica processos em categorias previamente definidas "
            "usando avaliacoes qualitativas ordenadas e pesos por criterio. "
            "A decisao e nao compensatoria e o ambiente e de certeza, "
            "com preferencias completas entre todas as alternativas.",

            "Um unico avaliador enquadra alternativas em classes "
            "com julgamentos ordinais e pesos. "
            "O processo nao admite compensacao entre criterios; "
            "o ambiente deterministico permite preferencias completas.",

            "Um especialista classifica fornecedores nas faixas "
            "estrategico, monitorado e critico usando escalas verbais. "
            "A decisao nao compensatoria em ambiente de certeza "
            "conta com preferencias completas e pesos definidos.",
        ],
    ),
]


def get_template(tid: str) -> Template:
    for t in TEMPLATES:
        if t.id == tid:
            return t
    raise KeyError(tid)
