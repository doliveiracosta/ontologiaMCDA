"""CLI: python -m ontomcda.evaluation.

Runs full pipeline over data/ and writes outputs/relatorio.xlsx.
"""
from pathlib import Path

import pandas as pd

from ontomcda import batch_recomendar, load_profiles
from ontomcda.evaluation.report import exportar_excel


def main() -> None:
    owl = "OntoMCDA_final.owl"
    data_dir = Path("data")
    out_path = Path("outputs/relatorio.xlsx")

    profiles = load_profiles(owl)
    casos = pd.read_csv(data_dir / "casos.csv")
    gabarito = pd.read_csv(data_dir / "gabarito_premissas.csv")
    ranking_esperado = pd.read_csv(data_dir / "ranking_esperado.csv")

    resultados = batch_recomendar(casos, profiles, top_k=15)
    exportar_excel(resultados, gabarito, ranking_esperado, casos, out_path)

    print(f"Relatorio gerado em {out_path.resolve()}")


if __name__ == "__main__":
    main()
