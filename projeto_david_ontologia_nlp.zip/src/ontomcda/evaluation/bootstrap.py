"""Bootstrap confidence intervals over metrics."""
from collections.abc import Callable

import numpy as np
import pandas as pd

from ontomcda.config import BOOTSTRAP_ITERATIONS, BOOTSTRAP_SEED


def resample_with_seed(df: pd.DataFrame, seed: int) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    idx = rng.integers(0, len(df), size=len(df))
    return df.iloc[idx].copy()


def intervalos_ic(
    values: pd.Series,
    statistic: Callable[[pd.Series], float],
    n_iter: int = BOOTSTRAP_ITERATIONS,
    seed: int = BOOTSTRAP_SEED,
    alpha: float = 0.05,
) -> dict[str, float]:
    rng = np.random.default_rng(seed)
    n = len(values)
    stats = []
    for _ in range(n_iter):
        idx = rng.integers(0, n, size=n)
        stats.append(statistic(values.iloc[idx]))
    stats_arr = np.array(stats)
    return {
        "mean": float(stats_arr.mean()),
        "lower": float(np.quantile(stats_arr, alpha / 2)),
        "upper": float(np.quantile(stats_arr, 1 - alpha / 2)),
        "n_iter": n_iter,
    }


def ic_for_metric_over_cases(
    metric_per_case: pd.Series,
    n_iter: int = BOOTSTRAP_ITERATIONS,
    seed: int = BOOTSTRAP_SEED,
) -> dict[str, float]:
    return intervalos_ic(metric_per_case, lambda s: float(s.mean()), n_iter, seed)
