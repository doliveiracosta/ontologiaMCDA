"""PLN metrics: per-attribute accuracy, per-class P/R/F1, confusion, kappa."""
import warnings

import pandas as pd
from sklearn.metrics import (
    accuracy_score,
    classification_report,
    cohen_kappa_score,
    confusion_matrix,
    f1_score,
    precision_score,
    recall_score,
)

from ontomcda.config import ATTRS, DATA_ATTRS

ATRIBUTOS_CATEGORICOS = [a for a in ATTRS if a not in DATA_ATTRS]


def _align(gold: pd.DataFrame, pred: pd.DataFrame, attr: str):
    g = gold[["id", attr]].rename(columns={attr: "g"})
    p = pred[["id", attr]].rename(columns={attr: "p"})
    merged = g.merge(p, on="id")
    merged = merged.dropna(subset=["g", "p"])
    return merged["g"].astype(str), merged["p"].astype(str)


def metricas_por_atributo(
    gold: pd.DataFrame,
    pred: pd.DataFrame,
    atributos: list[str] | None = None,
) -> pd.DataFrame:
    atributos = atributos or ATRIBUTOS_CATEGORICOS
    rows = []
    for a in atributos:
        if a not in gold.columns or a not in pred.columns:
            continue
        y_true, y_pred = _align(gold, pred, a)
        if len(y_true) == 0:
            continue
        kappa = float("nan")
        if len(set(y_true)) >= 2:
            with warnings.catch_warnings():
                warnings.simplefilter("ignore", RuntimeWarning)
                kappa = cohen_kappa_score(y_true, y_pred)
        rows.append({
            "atributo": a,
            "accuracy": accuracy_score(y_true, y_pred),
            "precision_macro": precision_score(y_true, y_pred, average="macro", zero_division=0),
            "recall_macro": recall_score(y_true, y_pred, average="macro", zero_division=0),
            "f1_macro": f1_score(y_true, y_pred, average="macro", zero_division=0),
            "f1_micro": f1_score(y_true, y_pred, average="micro", zero_division=0),
            "kappa": kappa,
            "n": len(y_true),
        })
    return pd.DataFrame(rows)


def per_class_report(atributo: str, gold: pd.DataFrame, pred: pd.DataFrame) -> pd.DataFrame:
    y_true, y_pred = _align(gold, pred, atributo)
    rep = classification_report(y_true, y_pred, output_dict=True, zero_division=0)
    rows = [
        {
            "classe": k,
            "precision": v["precision"],
            "recall": v["recall"],
            "f1": v["f1-score"],
            "support": v["support"],
        }
        for k, v in rep.items()
        if k not in {"accuracy", "macro avg", "weighted avg"}
    ]
    return pd.DataFrame(rows)


def matriz_confusao(atributo: str, gold: pd.DataFrame, pred: pd.DataFrame) -> pd.DataFrame:
    y_true, y_pred = _align(gold, pred, atributo)
    labels = sorted(set(y_true) | set(y_pred))
    cm = confusion_matrix(y_true, y_pred, labels=labels)
    return pd.DataFrame(cm, index=labels, columns=labels)


def taxa_nao_inferido(
    pred: pd.DataFrame,
    atributos: list[str] | None = None,
) -> pd.Series:
    atributos = atributos or ATRIBUTOS_CATEGORICOS
    result = {}
    for a in atributos:
        if a not in pred.columns:
            continue
        missing = pred[a].isna().sum()
        result[a] = missing / len(pred) if len(pred) else 0.0
    return pd.Series(result)


def plot_matriz_confusao(atributo: str, gold: pd.DataFrame, pred: pd.DataFrame, ax=None):
    import matplotlib.pyplot as plt
    import seaborn as sns
    cm = matriz_confusao(atributo, gold, pred)
    if ax is None:
        _, ax = plt.subplots(figsize=(5, 4))
    sns.heatmap(cm, annot=True, fmt="d", cmap="Blues", ax=ax, cbar=False)
    ax.set_xlabel("predito")
    ax.set_ylabel("gabarito")
    ax.set_title(f"Confusão — {atributo}")
    return ax
