"""Ranking metrics: P@k, Hit@k, nDCG@k, MRR, Kendall τ, Spearman ρ."""
import math

import pandas as pd
from scipy.stats import kendalltau, spearmanr


def _topk(ranking: list[str], k: int) -> list[str]:
    return list(ranking)[:k]


def precision_at_k(relevantes: list[str], ranking: list[str], k: int) -> float:
    if k == 0:
        return 0.0
    topk = _topk(ranking, k)
    rel_set = set(relevantes)
    return sum(1 for x in topk if x in rel_set) / k


def hit_at_k(relevantes: list[str], ranking: list[str], k: int) -> float:
    return 1.0 if set(_topk(ranking, k)) & set(relevantes) else 0.0


def ndcg_at_k(relevantes: list[str], ranking: list[str], k: int) -> float:
    topk = _topk(ranking, k)
    rel_set = set(relevantes)
    dcg = sum(1.0 / math.log2(i + 2) for i, x in enumerate(topk) if x in rel_set)
    ideal_n = min(len(rel_set), k)
    idcg = sum(1.0 / math.log2(i + 2) for i in range(ideal_n))
    return dcg / idcg if idcg > 0 else 0.0


def mrr(relevantes_por_caso: list[list[str]], rankings_por_caso: list[list[str]]) -> float:
    rr = []
    for rel, rank in zip(relevantes_por_caso, rankings_por_caso):
        rel_set = set(rel)
        pos = next((i + 1 for i, m in enumerate(rank) if m in rel_set), None)
        rr.append(1.0 / pos if pos else 0.0)
    return sum(rr) / len(rr) if rr else 0.0


def _common_positions(a: list[str], b: list[str]):
    a_pos = {x: i for i, x in enumerate(a)}
    b_pos = {x: i for i, x in enumerate(b)}
    common = [x for x in a if x in b_pos]
    return [a_pos[x] for x in common], [b_pos[x] for x in common]


def kendall_tau_parcial(
    ranking_sistema: list[str], ranking_esperado: list[str]
) -> tuple[float | None, int]:
    ra, rb = _common_positions(ranking_sistema, ranking_esperado)
    if len(ra) < 2:
        return None, len(ra)
    tau, _ = kendalltau(ra, rb)
    return float(tau), len(ra)


def spearman_parcial(
    ranking_sistema: list[str], ranking_esperado: list[str]
) -> tuple[float | None, int]:
    ra, rb = _common_positions(ranking_sistema, ranking_esperado)
    if len(ra) < 2:
        return None, len(ra)
    rho, _ = spearmanr(ra, rb)
    return float(rho), len(ra)


def metricas_completas(
    ranking_esperado_df: pd.DataFrame,
    resultados: list[dict],
    ks: tuple = (3, 5, 10),
) -> pd.DataFrame:
    """Per-case ranking metrics for cases with non-empty ranking_esperado."""
    rows = []
    for r in resultados:
        rel_row = ranking_esperado_df[ranking_esperado_df["id"] == r["id"]]
        if rel_row.empty:
            continue
        rel = str(rel_row.iloc[0]["relevantes"] or "")
        relevantes = [x.strip() for x in rel.split(";") if x.strip()]
        if not relevantes:
            continue
        rank = r["ranking"]
        row = {"id": r["id"]}
        for k in ks:
            row[f"p@{k}"] = precision_at_k(relevantes, rank, k)
            row[f"hit@{k}"] = hit_at_k(relevantes, rank, k)
            row[f"ndcg@{k}"] = ndcg_at_k(relevantes, rank, k)
        row["mrr"] = mrr([relevantes], [rank])
        tau, n = kendall_tau_parcial(rank, relevantes)
        rho, _ = spearman_parcial(rank, relevantes)
        row["kendall_tau"] = tau
        row["spearman_rho"] = rho
        row["n_common"] = n
        rows.append(row)
    return pd.DataFrame(rows)
