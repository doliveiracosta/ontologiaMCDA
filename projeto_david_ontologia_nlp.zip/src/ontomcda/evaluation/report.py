"""Reporting: per-template and stability analysis + Excel export."""
from pathlib import Path

import pandas as pd

from ontomcda.evaluation import bootstrap, pln, ranking


def _pred_premissas_df(resultados: list[dict]) -> pd.DataFrame:
    rows = [{"id": r["id"], **r["premissas"]} for r in resultados]
    return pd.DataFrame(rows)


def desempenho_por_template(
    resultados: list[dict],
    gabarito: pd.DataFrame,
    casos: pd.DataFrame,
) -> pd.DataFrame:
    pred = _pred_premissas_df(resultados)
    gold_safe = gabarito[[c for c in gabarito.columns if c != "template_id"]]
    merged = (
        casos[["id", "template_id"]]
        .merge(gold_safe, on="id")
        .merge(pred, on="id", suffixes=("_gold", "_pred"))
    )
    rows = []
    for tid, g in merged.groupby("template_id"):
        gold_cols = [c for c in g.columns if c.endswith("_gold")]
        pred_cols = [c for c in g.columns if c.endswith("_pred")]
        gold_sub = g[["id"] + gold_cols].rename(columns=lambda c: c.replace("_gold", ""))
        pred_sub = g[["id"] + pred_cols].rename(columns=lambda c: c.replace("_pred", ""))
        m = pln.metricas_por_atributo(gold_sub, pred_sub)
        if not m.empty:
            row = {
                "template_id": tid,
                "n_casos": len(g),
                **{f"f1_macro_{r.atributo}": r.f1_macro for r in m.itertuples()},
            }
            row["f1_macro_medio"] = float(m["f1_macro"].mean())
            rows.append(row)
    return pd.DataFrame(rows)


def estabilidade_linguistica(
    resultados: list[dict],
    gabarito: pd.DataFrame,
    casos: pd.DataFrame,
) -> pd.DataFrame:
    pred = _pred_premissas_df(resultados)
    merged = casos[["id", "template_id"]].merge(pred, on="id")
    attrs = [c for c in pred.columns if c != "id"]
    rows = []
    for tid, g in merged.groupby("template_id"):
        if len(g) < 2:
            rows.append({"template_id": tid, "concordancia_redacoes": 1.0, "n_redacoes": len(g)})
            continue
        frac_agree = []
        for a in attrs:
            if a not in g.columns:
                continue
            vals = g[a].dropna()
            if vals.empty:
                continue
            modal = vals.mode().iloc[0]
            frac_agree.append((vals == modal).mean())
        concordancia = float(sum(frac_agree) / len(frac_agree)) if frac_agree else 1.0
        rows.append({
            "template_id": tid,
            "concordancia_redacoes": concordancia,
            "n_redacoes": len(g),
        })
    return pd.DataFrame(rows)


def _bootstrap_sheet(
    gabarito: pd.DataFrame,
    pred_pr: pd.DataFrame,
    m_atr: pd.DataFrame,
    writer,
) -> None:
    ic_rows = []
    merged = gabarito.merge(pred_pr, on="id", suffixes=("_g", "_p"))
    for row in m_atr.itertuples():
        g_col = f"{row.atributo}_g"
        p_col = f"{row.atributo}_p"
        if g_col not in merged.columns or p_col not in merged.columns:
            continue
        per_case = (
            merged[g_col].astype(str) == merged[p_col].astype(str)
        ).astype(float)
        ic = bootstrap.ic_for_metric_over_cases(per_case)
        ic_rows.append({
            "atributo": row.atributo,
            "accuracy_mean": ic["mean"],
            "ic_lower_95": ic["lower"],
            "ic_upper_95": ic["upper"],
            "n_iter": ic["n_iter"],
        })
    pd.DataFrame(ic_rows).to_excel(writer, sheet_name="bootstrap_ic", index=False)


def exportar_excel(
    resultados: list[dict],
    gabarito: pd.DataFrame,
    ranking_esperado: pd.DataFrame,
    casos: pd.DataFrame,
    path: Path,
) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)

    pred_pr = _pred_premissas_df(resultados)
    m_atr = pln.metricas_por_atributo(gabarito, pred_pr)
    por_tmpl = desempenho_por_template(resultados, gabarito, casos)
    estab = estabilidade_linguistica(resultados, gabarito, casos)

    resumo_rows = [
        {"metric": r.atributo, "f1_macro": r.f1_macro, "kappa": r.kappa, "n": r.n}
        for r in m_atr.itertuples()
    ]
    resumo = pd.DataFrame(resumo_rows)

    with pd.ExcelWriter(path, engine="openpyxl") as w:
        resumo.to_excel(w, sheet_name="resumo", index=False)
        m_atr.to_excel(w, sheet_name="pln_por_atributo", index=False)
        for a in pln.ATRIBUTOS_CATEGORICOS:
            if a in gabarito.columns and a in pred_pr.columns:
                cm = pln.matriz_confusao(a, gabarito, pred_pr)
                cm.to_excel(w, sheet_name=f"confusao_{a}"[:31])
        has_ranking = (
            not ranking_esperado.empty
            and ranking_esperado["relevantes"].astype(str).str.strip().ne("").any()
        )
        if has_ranking:
            rk = ranking.metricas_completas(ranking_esperado, resultados)
            rk.to_excel(w, sheet_name="ranking_por_caso", index=False)
        por_tmpl.to_excel(w, sheet_name="por_template", index=False)
        estab.to_excel(w, sheet_name="estabilidade", index=False)
        _bootstrap_sheet(gabarito, pred_pr, m_atr, w)
