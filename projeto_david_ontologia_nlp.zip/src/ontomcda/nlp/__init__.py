"""NLP layer: lexicon-based premise inference."""
