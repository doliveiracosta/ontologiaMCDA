"""Premise inference: the free-text → ontology-value classifier.

infer_premissas(texto) is the public entry. It runs infer_attr per
attribute using the LEX lexicon, then applies rule-based overrides and
multi-attribute heuristics derived from the original notebook.
"""
from ontomcda.config import ATTRS
from ontomcda.nlp.lexicon import LEX
from ontomcda.nlp.normalize import contains_term, has_negated_expression, norm_txt
from ontomcda.nlp.rules import infer_tipo_problema_por_regras


def infer_attr(text_norm: str, attr: str) -> tuple[str | None, list[str], int]:
    scores = {}
    evidencias = {}
    for value, terms in LEX[attr].items():
        total = 0
        encontrados = []
        for term in terms:
            c = contains_term(text_norm, term)
            if c > 0:
                total += c
                encontrados.append(f"{term}({c})")
        scores[value] = total
        evidencias[value] = encontrados

    if not scores:
        return None, [], 0
    best = max(scores, key=scores.get)
    best_score = scores[best]

    if best_score == 0:
        return None, [], 0
    if list(scores.values()).count(best_score) > 1:
        return None, ["empate_lexico"], best_score
    return best, evidencias[best], best_score


def infer_premissas(
    texto: str,
) -> tuple[dict[str, str | None], dict[str, list[str]], dict[str, int]]:
    t = norm_txt(texto)
    prem: dict[str, str | None] = {}
    evid_map: dict[str, list[str]] = {}
    score_map: dict[str, int] = {}

    for attr in ATTRS:
        value, evid, score = infer_attr(t, attr)
        prem[attr] = value
        evid_map[attr] = evid
        score_map[attr] = score

    # --- tipo_problema ---
    score_tp = {"Escolha": 0, "Ordenacao": 0, "Classificacao": 0}
    evid_tp: dict[str, list[str]] = {"Escolha": [], "Ordenacao": [], "Classificacao": []}

    termos_escolha = [
        "escolher", "escolha", "selecionar", "selecao", "seleção",
        "alternativa mais adequada", "melhor alternativa", "decidir qual", "eleger",
        "portfolio", "portfólio", "carteira", "conjunto de projetos",
        "selecao de projetos", "seleção de projetos",
        "alocar recursos entre projetos", "escolher um conjunto",
        "selecionar um conjunto", "orcamento limitado", "orçamento limitado",
        "restricao orcamentaria", "restrição orçamentária",
    ]
    termos_ordenacao = [
        "ordenar", "ordenacao", "ordenação", "ranking", "ranquear", "rankear",
        "hierarquizar", "priorizar", "ordenamento",
    ]
    termos_classificacao = [
        "classificar", "classificacao", "classificação", "categorizar",
        "enquadrar em classes", "atribuir classes", "niveis de desempenho",
        "níveis de desempenho", "classes de risco", "faixas de desempenho",
    ]

    for termo in termos_escolha:
        if contains_term(t, termo) > 0:
            score_tp["Escolha"] += 1
            evid_tp["Escolha"].append(f"texto:{norm_txt(termo)}")

    for termo in termos_ordenacao:
        if contains_term(t, termo) > 0:
            score_tp["Ordenacao"] += 2
            evid_tp["Ordenacao"].append(f"texto:{norm_txt(termo)}")

    for termo in termos_classificacao:
        if contains_term(t, termo) > 0:
            score_tp["Classificacao"] += 2
            evid_tp["Classificacao"].append(f"texto:{norm_txt(termo)}")

    if score_tp["Classificacao"] > 0:
        prem["tipo_problema"] = "Classificacao"
        evid_map["tipo_problema"] = evid_tp["Classificacao"] + ["regra_precedencia_classificacao"]
        score_map["tipo_problema"] = max(score_map["tipo_problema"], score_tp["Classificacao"])
    elif score_tp["Ordenacao"] > 0:
        prem["tipo_problema"] = "Ordenacao"
        evid_map["tipo_problema"] = evid_tp["Ordenacao"] + ["regra_precedencia_ordenacao"]
        score_map["tipo_problema"] = max(score_map["tipo_problema"], score_tp["Ordenacao"])
    elif score_tp["Escolha"] > 0 and prem.get("tipo_problema") is None:
        prem["tipo_problema"] = "Escolha"
        evid_map["tipo_problema"] = evid_tp["Escolha"] + ["regra_inferencia_escolha"]
        score_map["tipo_problema"] = max(score_map["tipo_problema"], score_tp["Escolha"])

    tp_regra, evid_tp_regra = infer_tipo_problema_por_regras(t, evid_map["tipo_problema"])
    if tp_regra is not None:
        prem["tipo_problema"] = tp_regra
        evid_map["tipo_problema"] = evid_tp_regra
        score_map["tipo_problema"] += 1

    # --- tipo_variavel ---
    score_tv = {"Cardinal": 0, "Ordinal": 0, "Mista": 0}
    evid_tv: dict[str, list[str]] = {"Cardinal": [], "Ordinal": [], "Mista": []}

    termos_cardinais = [
        "custo", "preco", "preço", "valor", "prazo", "tempo", "distancia", "distância",
        "quantidade", "percentual",
        "numerico", "numericos", "numérico", "numéricos",
        "numerica", "numericas", "numérica", "numéricas",
        "quantitativo", "quantitativos", "quantitativa", "quantitativas",
        "medido", "mensuravel", "mensurável", "indicador numerico", "indicadores numericos",
    ]
    termos_ordinais = [
        "confiabilidade", "suporte", "reputacao", "reputação",
        "preferencia", "preferência",
        "avaliacao qualitativa", "avaliação qualitativa",
        "avaliacoes qualitativas", "avaliações qualitativas",
        "julgamentos qualitativos", "julgamento qualitativo",
        "qualitativo", "qualitativa", "qualitativos", "qualitativas",
        "escala verbal", "escalas verbais",
        "nivel", "nível", "niveis", "níveis",
        "linguistico", "linguístico", "linguistica", "linguística",
        "ordinal", "ordinais",
    ]
    marcadores_mistos = [
        "criterios quantitativos e qualitativos",
        "critérios quantitativos e qualitativos",
        "variaveis quantitativas e qualitativas",
        "variáveis quantitativas e qualitativas",
        "criterios mistos", "critérios mistos",
        "variaveis mistas", "variáveis mistas",
        "alguns criterios sao quantitativos e outros qualitativos",
        "alguns critérios são quantitativos e outros qualitativos",
        "dados quantitativos e qualitativos",
        "informacoes quantitativas e qualitativas",
        "informações quantitativas e qualitativas",
        "indicadores numericos e qualitativos",
        "indicadores quantitativos e qualitativos",
    ]

    for termo in termos_cardinais:
        if contains_term(t, termo) > 0:
            score_tv["Cardinal"] += 1
            evid_tv["Cardinal"].append(f"texto:{norm_txt(termo)}")

    for termo in termos_ordinais:
        if contains_term(t, termo) > 0:
            score_tv["Ordinal"] += 1
            evid_tv["Ordinal"].append(f"texto:{norm_txt(termo)}")

    for termo in marcadores_mistos:
        if contains_term(t, termo) > 0:
            score_tv["Mista"] += 3
            evid_tv["Mista"].append(f"texto:{norm_txt(termo)}")

    if score_tv["Mista"] > 0 and prem.get("tipo_variavel") is None:
        prem["tipo_variavel"] = "Mista"
        evid_map["tipo_variavel"] = evid_tv["Mista"] + ["regra_misto_explicito"]
        score_map["tipo_variavel"] = max(score_map["tipo_variavel"], score_tv["Mista"])
    elif score_tv["Cardinal"] > 0 and score_tv["Ordinal"] > 0 and prem.get("tipo_variavel") is None:
        prem["tipo_variavel"] = "Mista"
        evid_map["tipo_variavel"] = (
            evid_tv["Cardinal"] + evid_tv["Ordinal"] + ["regra_cardinal_mais_ordinal_gera_mista"]
        )
        score_map["tipo_variavel"] = max(
            score_map["tipo_variavel"], score_tv["Cardinal"] + score_tv["Ordinal"]
        )
    elif score_tv["Cardinal"] > 0 and prem.get("tipo_variavel") is None:
        prem["tipo_variavel"] = "Cardinal"
        evid_map["tipo_variavel"] = evid_tv["Cardinal"] + ["regra_inferencia_cardinal"]
        score_map["tipo_variavel"] = max(score_map["tipo_variavel"], score_tv["Cardinal"])
    elif score_tv["Ordinal"] > 0 and prem.get("tipo_variavel") is None:
        prem["tipo_variavel"] = "Ordinal"
        evid_map["tipo_variavel"] = evid_tv["Ordinal"] + ["regra_inferencia_ordinal"]
        score_map["tipo_variavel"] = max(score_map["tipo_variavel"], score_tv["Ordinal"])

    # --- estrutura_decisoria ---
    if prem.get("estrutura_decisoria") is None:
        termos_grupo = [
            "comite", "comitê", "grupo", "equipe", "especialistas", "avaliadores",
            "decisores", "multiplos decisores", "múltiplos decisores",
            "varios decisores", "vários decisores",
        ]
        termos_individual = [
            "um gestor", "um decisor", "decisor unico", "decisor único",
            "decisao individual", "decisão individual",
            "tomador de decisao", "tomador de decisão",
        ]
        if any(contains_term(t, x) > 0 for x in termos_grupo):
            prem["estrutura_decisoria"] = "Grupo"
            evid_map["estrutura_decisoria"].append("regra_contextual_grupo")
            score_map["estrutura_decisoria"] += 1
        elif any(contains_term(t, x) > 0 for x in termos_individual):
            prem["estrutura_decisoria"] = "Individual"
            evid_map["estrutura_decisoria"].append("regra_contextual_individual")
            score_map["estrutura_decisoria"] += 1

    # Fallback: "analista" / "gestor" / "engenheiro" implica Individual
    if prem.get("estrutura_decisoria") is None:
        termos_individual_fraco = [
            "analista", "gestor", "engenheiro", "auditor", "gerente",
            "unico avaliador", "único avaliador",
            "unico especialista", "único especialista",
        ]
        if any(contains_term(t, x) > 0 for x in termos_individual_fraco):
            prem["estrutura_decisoria"] = "Individual"
            evid_map["estrutura_decisoria"].append("regra_contextual_individual_fraco")
            score_map["estrutura_decisoria"] += 1

    # --- pesos ---
    if prem.get("usa_pesos") is None and prem.get("ponderabilidade") == "Ponderavel":
        prem["usa_pesos"] = "Sim"
        evid_map["usa_pesos"].append("regra_ponderavel_usa_pesos")
        score_map["usa_pesos"] += 1

    if prem.get("ponderabilidade") is None and prem.get("usa_pesos") == "Sim":
        prem["ponderabilidade"] = "Ponderavel"
        evid_map["ponderabilidade"].append("regra_usa_pesos_ponderavel")
        score_map["ponderabilidade"] += 1

    if prem.get("requer_pesos") is None and prem.get("usa_pesos") == "Sim":
        prem["requer_pesos"] = "Sim"
        evid_map["requer_pesos"].append("regra_usa_pesos_requer")
        score_map["requer_pesos"] += 1

    if prem.get("auxilia_gerar_pesos") is None:
        if (
            "julgamentos especialistas" in t
            or "comparacoes par a par" in t
            or "comparações par a par" in t
            or "comparacoes entre criterios" in t
            or "comparações entre critérios" in t
        ):
            prem["auxilia_gerar_pesos"] = "Sim"
            evid_map["auxilia_gerar_pesos"].append("regra_julgamento_ou_comparacao")
            score_map["auxilia_gerar_pesos"] += 1

    # --- compensatoriedade ---
    if prem.get("compensatoriedade") is None:
        termos_comp = [
            "compensacao", "compensação", "trade off", "trade-off",
            "substituicao entre criterios", "substituição entre critérios",
            "um mau desempenho pode ser compensado",
            "um criterio pode compensar outro",
            "media ponderada", "soma ponderada", "valor global",
        ]
        termos_nao_comp = [
            "nao compensatorio", "não compensatório", "sem compensacao", "sem compensação",
            "nao admite compensacao", "não admite compensação",
            "incomparabilidade", "outranking", "sobreclassificacao", "sobreclassificação",
            "veto", "limiar de veto",
        ]
        termos_parcial = [
            "parcialmente compensatorio", "parcialmente compensatório",
            "compensacao parcial", "compensação parcial",
            "compromisso entre criterios", "concordancia e discordancia",
            "concordância e discordância",
        ]

        sc, sn, sp = 0, 0, 0
        ec: list[str] = []
        en: list[str] = []
        ep: list[str] = []

        for termo in termos_comp:
            if contains_term(t, termo) > 0 and not has_negated_expression(t, termo):
                sc += 1
                ec.append(f"texto:{norm_txt(termo)}")
        for termo in termos_nao_comp:
            if contains_term(t, termo) > 0 and not has_negated_expression(t, termo):
                sn += 1
                en.append(f"texto:{norm_txt(termo)}")
        for termo in termos_parcial:
            if contains_term(t, termo) > 0 and not has_negated_expression(t, termo):
                sp += 1
                ep.append(f"texto:{norm_txt(termo)}")

        if sp > 0:
            prem["compensatoriedade"] = "ParcialmenteCompensatorio"
            evid_map["compensatoriedade"].extend(ep + ["regra_compensacao_parcial_explicita"])
            score_map["compensatoriedade"] += sp
        elif sc > 0 and sn == 0:
            prem["compensatoriedade"] = "Compensatorio"
            evid_map["compensatoriedade"].extend(ec + ["regra_compensatorio_explicito"])
            score_map["compensatoriedade"] += sc
        elif sn > 0 and sc == 0:
            prem["compensatoriedade"] = "NaoCompensatorio"
            evid_map["compensatoriedade"].extend(en + ["regra_nao_compensatorio_explicito"])
            score_map["compensatoriedade"] += sn
        elif sc > 0 and sn > 0:
            prem["compensatoriedade"] = "ParcialmenteCompensatorio"
            evid_map["compensatoriedade"].extend(ec + en + ["regra_conflito_compensacao"])
            score_map["compensatoriedade"] += sc + sn

    # --- completude_pref ---
    if prem.get("completude_pref") is None:
        termos_incompleto = [
            "informacoes incompletas", "informações incompletas", "dados incompletos",
            "preferencias incompletas", "preferências incompletas",
            "comparacoes parciais", "comparações parciais",
            "nem todas as alternativas sao comparaveis",
            "nem todas as alternativas são comparáveis",
            "incomparabilidade",
        ]
        termos_completo = [
            "todas as alternativas sao comparaveis",
            "todas as alternativas são comparáveis",
            "preferencias completas", "preferências completas",
            "ordem completa", "ranking completo",
        ]

        si, sc_pref = 0, 0
        ei: list[str] = []
        ecp: list[str] = []

        for termo in termos_incompleto:
            if contains_term(t, termo) > 0 and not has_negated_expression(t, termo):
                si += 1
                ei.append(f"texto:{norm_txt(termo)}")
        for termo in termos_completo:
            if contains_term(t, termo) > 0 and not has_negated_expression(t, termo):
                sc_pref += 1
                ecp.append(f"texto:{norm_txt(termo)}")

        if si > 0 and sc_pref == 0:
            prem["completude_pref"] = "Incompleto"
            evid_map["completude_pref"].extend(ei + ["regra_incompletude_explicita"])
            score_map["completude_pref"] += si
        elif sc_pref > 0 and si == 0:
            prem["completude_pref"] = "Completo"
            evid_map["completude_pref"].extend(ecp + ["regra_completude_explicita"])
            score_map["completude_pref"] += sc_pref

    # --- completude_pref fallback: "nem todas as preferências são conhecidas" ---
    if prem.get("completude_pref") is None:
        termos_incompleto_fraco = [
            "nem todas as preferencias sao conhecidas",
            "nem todas as preferências são conhecidas",
        ]
        if any(contains_term(t, x) > 0 for x in termos_incompleto_fraco):
            prem["completude_pref"] = "Incompleto"
            evid_map["completude_pref"].append("regra_preferencias_nao_conhecidas")
            score_map["completude_pref"] += 1

    # --- ambiente_decisao ---
    if prem.get("ambiente_decisao") is None:
        risco_terms = [
            "probabilidade", "probabilidades", "probabilistico", "probabilístico",
            "cenario probabilistico", "cenário probabilístico",
            "distribuicao de probabilidade", "distribuição de probabilidade",
        ]
        incerteza_terms = [
            "incerteza", "ambiente de incerteza", "cenario incerto", "cenário incerto",
            "imprecisao", "imprecisão", "informacao incompleta", "informação incompleta",
            "dados incompletos", "ambiguidade", "subjetividade",
            "julgamentos especialistas", "apreciacoes subjetivas",
            "apreciações subjetivas", "fuzzy", "intervalar", "grey",
        ]
        certeza_terms = [
            "certeza", "ambiente de certeza", "deterministico", "determinístico",
            "sem incerteza", "dados completos", "informacao completa",
            "informação completa", "valores exatos",
        ]

        sr, si_amb, sc_amb = 0, 0, 0
        er: list[str] = []
        ei_amb: list[str] = []
        ec_amb: list[str] = []

        for termo in risco_terms:
            if contains_term(t, termo) > 0 and not has_negated_expression(t, termo):
                sr += 1
                er.append(f"texto:{norm_txt(termo)}")
        for termo in incerteza_terms:
            if contains_term(t, termo) > 0 and not has_negated_expression(t, termo):
                si_amb += 1
                ei_amb.append(f"texto:{norm_txt(termo)}")
        for termo in certeza_terms:
            if contains_term(t, termo) > 0 and not has_negated_expression(t, termo):
                sc_amb += 1
                ec_amb.append(f"texto:{norm_txt(termo)}")

        if sr > 0:
            prem["ambiente_decisao"] = "Risco"
            evid_map["ambiente_decisao"].extend(er + ["regra_precedencia_risco"])
            score_map["ambiente_decisao"] += sr
        elif si_amb > 0:
            prem["ambiente_decisao"] = "Incerteza"
            evid_map["ambiente_decisao"].extend(ei_amb + ["regra_inferencia_incerteza"])
            score_map["ambiente_decisao"] += si_amb
        elif sc_amb > 0:
            prem["ambiente_decisao"] = "Certeza"
            evid_map["ambiente_decisao"].extend(ec_amb + ["regra_inferencia_certeza"])
            score_map["ambiente_decisao"] += sc_amb

    # --- monotonicidade ---
    if prem.get("monotonicidade") is None:
        termos_nao_mono = [
            "nao monotono", "não monótono", "nao monotonico", "não monotônico",
            "relacao nao monotona", "relação não monótona",
        ]
        termos_mono = [
            "monotono", "monótono", "monotonico", "monotônico",
            "relacao monotona", "relação monótona",
        ]

        sn_mono, sm_mono = 0, 0
        en_mono: list[str] = []
        em_mono: list[str] = []

        for termo in termos_nao_mono:
            if contains_term(t, termo) > 0 and not has_negated_expression(t, termo):
                sn_mono += 1
                en_mono.append(f"texto:{norm_txt(termo)}")
        for termo in termos_mono:
            if contains_term(t, termo) > 0 and not has_negated_expression(t, termo):
                sm_mono += 1
                em_mono.append(f"texto:{norm_txt(termo)}")

        if sn_mono > 0 and sm_mono == 0:
            prem["monotonicidade"] = "NaoMonotonico"
            evid_map["monotonicidade"].extend(en_mono + ["regra_nao_monotonicidade_explicita"])
            score_map["monotonicidade"] += sn_mono
        elif sm_mono > 0 and sn_mono == 0:
            prem["monotonicidade"] = "Monotonico"
            evid_map["monotonicidade"].extend(em_mono + ["regra_monotonicidade_explicita"])
            score_map["monotonicidade"] += sm_mono

    return prem, evid_map, score_map
