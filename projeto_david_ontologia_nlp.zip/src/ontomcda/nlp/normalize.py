"""Text normalization and value canonicalization.

Ported from OntoMCDA_final.ipynb. norm_txt is the entry point that every
other NLP function calls first. canon_value is the bridge between free-text
and ontology value identifiers.
"""
import re

from unidecode import unidecode


def norm_txt(s: str) -> str:
    """Lowercase, strip accents, collapse whitespace."""
    if s is None:
        return ""
    s = unidecode(str(s)).lower()
    s = re.sub(r"\s+", " ", s).strip()
    return s


def local_name(uri) -> str:
    """Extract fragment after # or last / from a URI/URIRef."""
    s = str(uri)
    if "#" in s:
        return s.rsplit("#", 1)[-1]
    return s.rsplit("/", 1)[-1]


def contains_term(text_norm: str, term: str) -> int:
    """Return 1 if `term` appears as a whole-word match in `text_norm`."""
    pattern = r"\b" + re.escape(norm_txt(term)) + r"\b"
    return 1 if re.search(pattern, text_norm) else 0


def has_negated_expression(text_norm: str, expr: str) -> bool:
    """Detect 'nao <expr>' / 'não <expr>' immediately preceding expr."""
    pattern = r"\bnao\s+(?:\w+\s+){0,2}" + re.escape(norm_txt(expr))
    return bool(re.search(pattern, text_norm))


_CANON_MAP = {
    "tipo_problema": {
        "escolha": "Escolha",
        "ordenacao": "Ordenacao",
        "ordenação": "Ordenacao",
        "classificacao": "Classificacao",
        "classificação": "Classificacao",
    },
    "compensatoriedade": {
        "compensatorio": "Compensatorio",
        "parcialmente compensatorio": "ParcialmenteCompensatorio",
        "nao compensatorio": "NaoCompensatorio",
    },
    "tipo_variavel": {
        "cardinal": "Cardinal",
        "ordinal": "Ordinal",
        "mista": "Mista",
        "pseudocardinal": "PseudoCardinal",
        "cardinal intervalar": "CardinalIntervalar",
        "cardinal fuzzy": "CardinalFuzzy",
        "cardinal grey": "CardinalGrey",
    },
    "monotonicidade": {
        "monotonico": "Monotonico",
        "nao monotonico": "NaoMonotonico",
        "monotonicidade fraca": "MonotonicidadeFraca",
    },
    "estrutura_decisoria": {
        "individual": "Individual",
        "grupo": "Grupo",
        "coletiva": "Coletiva",
        "monodecisor": "Monodecisor",
        "multidecisor": "Multidecisor",
    },
    "completude_pref": {
        "completo": "Completo",
        "incompleto": "Incompleto",
    },
    "ambiente_decisao": {
        "certeza": "Certeza",
        "incerteza": "Incerteza",
        "risco": "Risco",
    },
    "ponderabilidade": {
        "ponderavel": "Ponderavel",
        "nao ponderavel": "NaoPonderavel",
    },
}


def canon_value(attr: str, val: str | None) -> str | None:
    """Map a free-form string (possibly accented) to the ontology canonical value."""
    if val is None:
        return None
    key = norm_txt(val)
    mapping = _CANON_MAP.get(attr, {})
    if key in mapping:
        return mapping[key]
    return str(val).strip().replace(" ", "")
