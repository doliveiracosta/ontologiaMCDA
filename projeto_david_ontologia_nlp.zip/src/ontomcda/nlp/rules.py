"""Rule-based overrides for tipo_problema inference.

When the lexicon alone is ambiguous between Escolha/Ordenacao/Classificacao,
these higher-priority patterns disambiguate based on phrase-level context.
"""
from ontomcda.nlp.normalize import contains_term


def infer_tipo_problema_por_regras(
    t: str, evidencias_atuais: list[str]
) -> tuple[str | None, list[str]]:
    # t must already be normalized via norm_txt before calling

    escolhas = [
        "melhor alternativa", "melhor opcao", "melhor opção",
        "alternativa mais adequada", "alternativa mais apropriada",
        "qual alternativa escolher", "qual alternativa selecionar",
        "escolha final", "decisão final", "decisao final", "alternativa vencedora",
        "selecionar a melhor alternativa", "escolher a melhor alternativa",
    ]
    ordenacoes = [
        "ranking", "ranquear", "ranqueamento", "hierarquia",
        "lista de prioridade", "lista de prioridades",
        "ordem de preferência", "ordem de preferencia",
        "da mais preferida para a menos preferida",
        "da melhor para a pior", "ordenar as alternativas",
        "ordenar alternativas", "priorizar",
    ]
    classificacoes = [
        "categorias", "classes", "niveis", "níveis", "faixas",
        "categorias previamente definidas", "classes previamente definidas",
        "alocar em categorias", "atribuir a classes",
        "classificar em categorias", "enquadrar em classes",
    ]

    score_escolha = sum(contains_term(t, x) for x in escolhas)
    score_ordenacao = sum(contains_term(t, x) for x in ordenacoes)
    score_classificacao = sum(contains_term(t, x) for x in classificacoes)

    if "nao se pretende escolher uma unica alternativa" in t:
        if score_classificacao > 0:
            return "Classificacao", evidencias_atuais + ["regra_semantica_nao_escolha+categorias"]
        if score_ordenacao > 0:
            return "Ordenacao", evidencias_atuais + ["regra_semantica_nao_escolha+ranking"]

    if (
        "o objetivo final e escolher" in t
        or "selecionar a melhor alternativa" in t
        or "escolher a melhor alternativa" in t
    ):
        return "Escolha", evidencias_atuais + ["regra_objetivo_final_escolha"]

    if (
        "o objetivo final e ordenar" in t
        or "gerar ranking" in t
        or "ordenar as alternativas" in t
    ):
        return "Ordenacao", evidencias_atuais + ["regra_objetivo_final_ordenacao"]

    if (
        "o objetivo final e classificar" in t
        or "categorias previamente definidas" in t
        or "classificar as alternativas em categorias" in t
    ):
        return "Classificacao", evidencias_atuais + ["regra_objetivo_final_classificacao"]

    scores = {
        "Escolha": score_escolha,
        "Ordenacao": score_ordenacao,
        "Classificacao": score_classificacao,
    }
    melhor = max(scores, key=scores.get)
    if scores[melhor] > 0 and list(scores.values()).count(scores[melhor]) == 1:
        return melhor, evidencias_atuais + [f"regra_contextual_{melhor.lower()}"]
    return None, evidencias_atuais
