"""OWL ontology loader.

Preserves the dual-namespace behavior of the original notebook: properties
under NEW_NS and OLD_NS are merged transparently. The .owl file is
never modified; this module is read-only.
"""
from rdflib import RDF, Graph, Literal, URIRef

from ontomcda.config import ATTRS, DATA_ATTRS, NEW_NS, OLD_NS
from ontomcda.nlp.lexicon import ATTR_TO_PROP
from ontomcda.nlp.normalize import canon_value, local_name, norm_txt


def get_method_instances(g: Graph):
    classes = ["MetodoMCDA", "Metodo", "MetodosMCDA"]
    methods = set()
    for cls_name in classes:
        cls_new = URIRef(NEW_NS + cls_name)
        cls_old = URIRef(OLD_NS + cls_name)
        methods.update(g.subjects(RDF.type, cls_new))
        methods.update(g.subjects(RDF.type, cls_old))
    return sorted(methods, key=lambda x: local_name(x).lower())


def parse_bool_literal(v) -> str:
    try:
        pyv = v.toPython()
        if isinstance(pyv, bool):
            return "Sim" if pyv else "Nao"
    except Exception:
        pass
    s = norm_txt(str(v))
    if s in {"true", "1", "sim", "yes"}:
        return "Sim"
    if s in {"false", "0", "nao", "não", "no"}:
        return "Nao"
    return str(v)


def load_profiles(owl_path: str) -> dict[str, dict[str, str | None]]:
    g = Graph()
    g.parse(owl_path)
    methods = get_method_instances(g)
    profiles = {}
    for m in methods:
        name = local_name(m)
        prof = {}
        for attr in ATTRS:
            props = ATTR_TO_PROP[attr]
            if isinstance(props, str):
                props = [props]
            vals = []
            seen_vals: set = set()
            for prop in props:
                p_new = URIRef(NEW_NS + prop)
                p_old = URIRef(OLD_NS + prop)
                for v in list(g.objects(m, p_new)) + list(g.objects(m, p_old)):
                    key = str(v)
                    if key not in seen_vals:
                        seen_vals.add(key)
                        vals.append(v)
            if not vals:
                prof[attr] = None
                continue
            v0 = vals[0]
            if attr in DATA_ATTRS:
                prof[attr] = parse_bool_literal(v0)
            else:
                prof[attr] = canon_value(
                    attr,
                    str(v0) if isinstance(v0, Literal) else local_name(v0),
                )
        profiles[name] = prof
    return profiles
