"""Public API: recomendar() glues NLP inference and ontology scoring."""
import pandas as pd

from ontomcda.config import MANDATORY_QUERY_ATTRS
from ontomcda.nlp.inference import infer_premissas
from ontomcda.scoring import build_query_profile, consult_ontology


def recomendar(
    texto: str,
    profiles: dict[str, dict[str, str | None]],
    top_k: int = 15,
) -> dict:
    prem, evid_map, score_map = infer_premissas(texto)
    query_profile = build_query_profile(prem, score_map)

    faltantes = [a for a in MANDATORY_QUERY_ATTRS if prem.get(a) is None]
    if faltantes:
        return {
            "premissas": prem,
            "query_profile": query_profile,
            "aceitos": pd.DataFrame(),
            "rejeitados": pd.DataFrame(),
            "faltantes": faltantes,
        }

    acc_df, rej_df = consult_ontology(query_profile, profiles, top_k=top_k)
    return {
        "premissas": prem,
        "query_profile": query_profile,
        "aceitos": acc_df,
        "rejeitados": rej_df,
        "faltantes": [],
    }


def batch_recomendar(
    casos: pd.DataFrame,
    profiles: dict[str, dict[str, str | None]],
    top_k: int = 15,
) -> list[dict]:
    required = {"id", "texto"}
    missing = required - set(casos.columns)
    if missing:
        raise ValueError(f"batch_recomendar: DataFrame is missing columns: {missing}")
    out = []
    for _, row in casos.iterrows():
        r = recomendar(row["texto"], profiles, top_k=top_k)
        out.append({
            "id": row["id"],
            "premissas": r["premissas"],
            "ranking": list(r["aceitos"]["metodo"]) if not r["aceitos"].empty else [],
            "faltantes": r["faltantes"],
        })
    return out
