"""Scoring: match inferred premises against method ontology profiles.

ontology_match is attribute-aware — the rules for tipo_variavel,
estrutura_decisoria, and compensatoriedade are not pure equality.
consult_ontology produces the accepted/rejected DataFrames.
"""
import pandas as pd

from ontomcda.config import ATTR_WEIGHTS, ATTRS, MANDATORY_QUERY_ATTRS
from ontomcda.nlp.normalize import canon_value


def tipo_variavel_match(inferido: str, metodo_val: str | None) -> bool:
    if metodo_val is None:
        return False
    mv = canon_value("tipo_variavel", metodo_val)
    if inferido == "Mista":
        return mv in {
            "Mista", "Cardinal", "Ordinal", "PseudoCardinal",
            "CardinalIntervalar", "CardinalFuzzy", "CardinalGrey",
        }
    if inferido == "Cardinal":
        return mv in {
            "Cardinal", "Mista", "PseudoCardinal",
            "CardinalIntervalar", "CardinalFuzzy", "CardinalGrey",
        }
    if inferido == "Ordinal":
        return mv in {"Ordinal", "Mista"}
    if inferido == "PseudoCardinal":
        return mv in {"PseudoCardinal", "Cardinal", "Mista"}
    if inferido == "CardinalIntervalar":
        return mv in {"CardinalIntervalar", "Cardinal", "Mista"}
    if inferido == "CardinalFuzzy":
        return mv in {"CardinalFuzzy", "Cardinal", "Mista"}
    if inferido == "CardinalGrey":
        return mv in {"CardinalGrey", "Cardinal", "Mista"}
    return inferido == mv


def ontology_match(
    attr: str, problem_value: str | None, method_value: str | None
) -> tuple[bool | None, str]:
    if problem_value is None:
        return None, "atributo não inferido"
    if method_value is None:
        return None, "atributo ausente na ontologia"

    pv = canon_value(attr, problem_value)
    mv = canon_value(attr, method_value)

    if attr == "tipo_variavel":
        ok = tipo_variavel_match(pv, mv)
        return ok, f"{pv} vs {mv}"

    if attr == "estrutura_decisoria":
        if mv in {"MonoMulti", "Mono_Multi", "MonoMultiDecisor", "Mono/Multi"}:
            ok = pv in {"Individual", "Grupo"}
            return ok, f"{pv} vs {mv}"
        if mv in {"Monodecisor", "Mono"}:
            ok = pv == "Individual"
            return ok, f"{pv} vs {mv}"
        if mv in {"Multidecisor", "Multi", "Coletiva"}:
            ok = pv == "Grupo"
            return ok, f"{pv} vs {mv}"
        ok = pv == mv
        return ok, f"{pv} vs {mv}"

    if attr == "compensatoriedade":
        if pv == "ParcialmenteCompensatorio":
            ok = mv in {"ParcialmenteCompensatorio", "Compensatorio", "NaoCompensatorio"}
            return ok, f"{pv} vs {mv}"
        ok = pv == mv
        return ok, f"{pv} vs {mv}"

    ok = pv == mv
    return ok, f"{pv} vs {mv}"


def build_query_profile(
    prem: dict[str, str | None], score_map: dict[str, int]
) -> dict[str, dict[str, object]]:
    query = {}
    for attr in ATTRS:
        val = prem.get(attr)
        score = score_map.get(attr, 0)

        if val is None:
            role = "ignore"
        elif attr in MANDATORY_QUERY_ATTRS:
            role = "hard"
        elif score >= 2 and attr in {
            "compensatoriedade", "tipo_variavel", "estrutura_decisoria", "ambiente_decisao"
        }:
            role = "hard"
        elif score >= 1:
            role = "soft"
        else:
            role = "ignore"

        query[attr] = {"value": val, "score": score, "role": role}
    return query


def consult_ontology(
    query_profile: dict[str, dict[str, object]],
    profiles: dict[str, dict[str, str | None]],
    top_k: int = 15,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    accepted = []
    rejected = []

    compared_attrs = [a for a in ATTRS if query_profile[a]["value"] is not None]

    for method_name, method_profile in profiles.items():
        hard_fail = []
        atendidos = 0
        peso_total = 0.0
        peso_atendido = 0.0
        row_marks = {}

        for attr in ATTRS:
            q = query_profile[attr]
            qval = q["value"]
            role = q["role"]

            if qval is None:
                row_marks[attr] = "—"
                continue

            match, _ = ontology_match(attr, qval, method_profile.get(attr))

            if role == "hard" and match is False:
                hard_fail.append(attr)

            peso = ATTR_WEIGHTS.get(attr, 1.0)
            peso_total += peso

            if match is True:
                atendidos += 1
                peso_atendido += peso
                row_marks[attr] = "✓"
            elif match is False:
                row_marks[attr] = "✗"
            else:
                row_marks[attr] = "—"

        if hard_fail:
            rejected.append({
                "metodo": method_name,
                "restricoes_hard_violadas": ", ".join(hard_fail),
            })
            continue

        aderencia = 0.0 if peso_total == 0 else (100.0 * peso_atendido / peso_total)
        accepted.append({
            "metodo": method_name,
            "aderencia_pct": round(aderencia, 2),
            "criterios_atendidos": atendidos,
            "criterios_comparados": len(compared_attrs),
            **row_marks,
        })

    acc_df = pd.DataFrame(accepted)
    rej_df = pd.DataFrame(rejected)

    if not acc_df.empty:
        base_cols = ["metodo", "aderencia_pct", "criterios_atendidos", "criterios_comparados"]
        cols = base_cols + compared_attrs
        present_cols = [c for c in cols if c in acc_df.columns]
        acc_df = (
            acc_df[present_cols]
            .sort_values(
                ["aderencia_pct", "criterios_atendidos", "metodo"],
                ascending=[False, False, True],
            )
            .head(top_k)
            .reset_index(drop=True)
        )

    return acc_df, rej_df
