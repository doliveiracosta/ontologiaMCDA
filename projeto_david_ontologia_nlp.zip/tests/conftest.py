from pathlib import Path

import pytest
from ontomcda.ontology import load_profiles

OWL_PATH = Path(__file__).parent.parent / "OntoMCDA_final.owl"


@pytest.fixture(scope="session")
def profiles():
    return load_profiles(str(OWL_PATH))
