import json

import pytest
from ontomcda.dataset.generator import escrever_csvs, gerar_casos
from ontomcda.dataset.templates import TEMPLATES
from ontomcda.nlp.inference import infer_premissas


def test_gerar_casos_produces_case_per_redacao():
    out = gerar_casos()
    assert len(out["casos"]) >= 27  # 9 templates × 3 redacoes minimum
    assert set(out["casos"].columns) == {"id", "template_id", "redacao_idx", "texto"}


def test_gabarito_has_all_required_attrs():
    out = gerar_casos()
    required = {"id", "tipo_problema", "tipo_variavel", "estrutura_decisoria"}
    assert required.issubset(set(out["gabarito"].columns))


def test_ranking_esperado_starts_empty():
    out = gerar_casos()
    re_df = out["ranking_esperado"]
    assert set(re_df.columns) == {"id", "relevantes"}
    assert re_df["relevantes"].isna().all() or (re_df["relevantes"] == "").all()


@pytest.mark.parametrize("tmpl", TEMPLATES, ids=[t.id for t in TEMPLATES])
def test_tipo_problema_round_trip(tmpl):
    """Every redacao must produce the correct tipo_problema via infer_premissas."""
    for i, redacao in enumerate(tmpl.redacoes, start=1):
        prem, _, _ = infer_premissas(redacao)
        assert prem["tipo_problema"] == tmpl.premissas["tipo_problema"], (
            f"{tmpl.id} r{i}: expected {tmpl.premissas['tipo_problema']}, "
            f"got {prem['tipo_problema']!r}"
        )


def test_escrever_csvs_creates_four_files(tmp_path):
    escrever_csvs(gerar_casos(), tmp_path)
    for name in ["casos.csv", "gabarito_premissas.csv", "ranking_esperado.csv"]:
        assert (tmp_path / name).exists()
    assert (tmp_path / "templates.json").exists()
    manifest = json.loads((tmp_path / "templates.json").read_text(encoding="utf-8"))
    assert len(manifest["templates"]) == 9
