import numpy as np
import pandas as pd
from ontomcda.evaluation.bootstrap import intervalos_ic, resample_with_seed


def test_resample_is_reproducible_with_seed():
    df = pd.DataFrame({"x": list(range(100))})
    a = resample_with_seed(df, seed=42)
    b = resample_with_seed(df, seed=42)
    pd.testing.assert_frame_equal(a.reset_index(drop=True), b.reset_index(drop=True))


def test_resample_differs_with_different_seed():
    df = pd.DataFrame({"x": list(range(100))})
    a = resample_with_seed(df, seed=1)
    b = resample_with_seed(df, seed=2)
    assert not a.equals(b)


def test_intervalos_ic_produces_lower_and_upper():
    rng = np.random.default_rng(0)
    values = pd.Series(rng.normal(0, 1, size=200))
    def stat(s):
        return float(s.mean())
    ic = intervalos_ic(values, stat, n_iter=500, seed=42)
    assert ic["lower"] < ic["mean"] < ic["upper"]


def test_intervalos_ic_stable_with_seed():
    values = pd.Series([1.0] * 50 + [0.0] * 50)
    def stat(s):
        return float(s.mean())
    ic1 = intervalos_ic(values, stat, n_iter=200, seed=42)
    ic2 = intervalos_ic(values, stat, n_iter=200, seed=42)
    assert ic1 == ic2
