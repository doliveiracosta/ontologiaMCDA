import pandas as pd
from ontomcda.evaluation.pln import (
    matriz_confusao,
    metricas_por_atributo,
    per_class_report,
    taxa_nao_inferido,
)


def _gold():
    return pd.DataFrame([
        {"id": 1, "tipo_problema": "Escolha", "tipo_variavel": "Cardinal"},
        {"id": 2, "tipo_problema": "Ordenacao", "tipo_variavel": "Mista"},
        {"id": 3, "tipo_problema": "Escolha", "tipo_variavel": "Cardinal"},
    ])


def _pred_perfect():
    return _gold()


def _pred_one_wrong():
    df = _gold().copy()
    df.loc[0, "tipo_problema"] = "Ordenacao"
    return df


def test_metricas_perfect_accuracy_is_one():
    m = metricas_por_atributo(_gold(), _pred_perfect(), ["tipo_problema", "tipo_variavel"])
    assert (m["accuracy"] == 1.0).all()


def test_metricas_per_class_report_returns_frame():
    r = per_class_report("tipo_problema", _gold(), _pred_perfect())
    assert isinstance(r, pd.DataFrame)
    assert {"classe", "precision", "recall", "f1", "support"}.issubset(r.columns)


def test_matriz_confusao_returns_square():
    cm = matriz_confusao("tipo_problema", _gold(), _pred_one_wrong())
    assert cm.shape[0] == cm.shape[1]


def test_taxa_nao_inferido_counts_none_and_nan():
    pred = _gold().copy()
    pred.loc[0, "tipo_problema"] = None
    pred.loc[1, "tipo_problema"] = pd.NA
    t = taxa_nao_inferido(pred, ["tipo_problema", "tipo_variavel"])
    assert t["tipo_problema"] == 2 / 3
    assert t["tipo_variavel"] == 0.0


def test_kappa_is_between_minus_one_and_one():
    m = metricas_por_atributo(_gold(), _pred_one_wrong(), ["tipo_problema"])
    assert -1.0 <= m.iloc[0]["kappa"] <= 1.0
