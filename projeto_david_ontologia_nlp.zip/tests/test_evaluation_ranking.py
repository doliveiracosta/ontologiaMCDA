import pandas as pd
import pytest
from ontomcda.evaluation.ranking import (
    hit_at_k,
    kendall_tau_parcial,
    metricas_completas,
    mrr,
    ndcg_at_k,
    precision_at_k,
    spearman_parcial,
)


def test_precision_at_k_full_match():
    assert precision_at_k(["A", "B", "C"], ["A", "B", "C", "D"], k=3) == 1.0


def test_precision_at_k_partial():
    assert abs(precision_at_k(["A", "B"], ["A", "X", "B"], k=3) - 2/3) < 1e-9


def test_hit_at_k_true_when_any_relevant_present():
    assert hit_at_k(["A"], ["X", "A", "Y"], k=3) == 1.0
    assert hit_at_k(["A"], ["X", "Y", "Z"], k=3) == 0.0


def test_ndcg_higher_when_relevant_is_first():
    better = ndcg_at_k(["A"], ["A", "X", "Y"], k=3)
    worse = ndcg_at_k(["A"], ["X", "Y", "A"], k=3)
    assert better > worse


def test_mrr_mean_across_cases():
    rankings = [["A", "B"], ["X", "A"], ["Y", "X"]]
    relevantes = [["A"], ["A"], ["A"]]
    # positions: 1, 2, inf → RR = 1, 0.5, 0 → mean = 0.5
    assert abs(mrr(relevantes, rankings) - 0.5) < 1e-9


def test_kendall_tau_parcial_same_order_is_one():
    t, _ = kendall_tau_parcial(["A", "B", "C"], ["A", "B", "C", "D"])
    assert t == 1.0


def test_spearman_parcial_works_with_partial_overlap():
    rho, _ = spearman_parcial(["A", "B", "C"], ["A", "C", "B"])
    assert -1.0 <= rho <= 1.0


def test_precision_at_k_short_ranking_uses_k_denominator():
    # ranking shorter than k — denominator must be k, not len(ranking)
    assert precision_at_k(["A"], ["A"], k=3) == pytest.approx(1 / 3)


def test_metricas_completas_produces_correct_metrics():
    ranking_esperado = pd.DataFrame([
        {"id": "case1", "relevantes": "A;B"},
        {"id": "case2", "relevantes": ""},
    ])
    resultados = [
        {"id": "case1", "ranking": ["A", "X", "B"], "premissas": {}},
        {"id": "case2", "ranking": ["X", "Y"], "premissas": {}},
    ]
    df = metricas_completas(ranking_esperado, resultados, ks=(3,))
    assert len(df) == 1  # case2 skipped (empty relevantes)
    assert df.iloc[0]["id"] == "case1"
    assert df.iloc[0]["p@3"] == pytest.approx(2 / 3)
