import pandas as pd
from ontomcda.evaluation.report import (
    desempenho_por_template,
    estabilidade_linguistica,
    exportar_excel,
)


def _mock_inputs():
    casos = pd.DataFrame([
        {"id": "T01-r1", "template_id": "T01", "redacao_idx": 1, "texto": "x"},
        {"id": "T01-r2", "template_id": "T01", "redacao_idx": 2, "texto": "y"},
        {"id": "T02-r1", "template_id": "T02", "redacao_idx": 1, "texto": "z"},
    ])
    gabarito = pd.DataFrame([
        {"id": "T01-r1", "tipo_problema": "Escolha"},
        {"id": "T01-r2", "tipo_problema": "Escolha"},
        {"id": "T02-r1", "tipo_problema": "Ordenacao"},
    ])
    resultados = [
        {"id": "T01-r1", "premissas": {"tipo_problema": "Escolha"}, "ranking": []},
        {"id": "T01-r2", "premissas": {"tipo_problema": "Ordenacao"}, "ranking": []},
        {"id": "T02-r1", "premissas": {"tipo_problema": "Ordenacao"}, "ranking": []},
    ]
    return casos, gabarito, resultados


def test_desempenho_por_template_returns_one_row_per_template():
    casos, gabarito, resultados = _mock_inputs()
    df = desempenho_por_template(resultados, gabarito, casos)
    assert set(df["template_id"]) == {"T01", "T02"}


def test_estabilidade_flags_template_with_divergent_redacoes():
    casos, gabarito, resultados = _mock_inputs()
    est = estabilidade_linguistica(resultados, gabarito, casos)
    t01 = est[est["template_id"] == "T01"].iloc[0]
    assert t01["concordancia_redacoes"] < 1.0


def test_exportar_excel_creates_file(tmp_path):
    casos, gabarito, resultados = _mock_inputs()
    path = tmp_path / "relatorio.xlsx"
    exportar_excel(
        resultados, gabarito,
        pd.DataFrame({"id": [], "relevantes": []}),
        casos, path,
    )
    assert path.exists()


def test_exportar_excel_includes_ranking_sheet_when_relevantes_present(tmp_path):
    casos, gabarito, resultados = _mock_inputs()
    ranking_esperado = pd.DataFrame([
        {"id": "T01-r1", "relevantes": "MetodoA;MetodoB"},
        {"id": "T01-r2", "relevantes": ""},
        {"id": "T02-r1", "relevantes": ""},
    ])
    path = tmp_path / "relatorio_ranking.xlsx"
    exportar_excel(resultados, gabarito, ranking_esperado, casos, path)
    import openpyxl
    wb = openpyxl.load_workbook(path)
    assert "ranking_por_caso" in wb.sheetnames
    assert "bootstrap_ic" in wb.sheetnames
