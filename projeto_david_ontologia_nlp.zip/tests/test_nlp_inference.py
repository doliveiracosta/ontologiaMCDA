from ontomcda.nlp.inference import infer_premissas


def test_t01_escolha_cardinal_individual():
    t = ("Um analista precisa escolher a melhor alternativa de investimento. "
         "Os critérios são numéricos e admitem trade-off.")
    prem, evid, score = infer_premissas(t)
    assert prem["tipo_problema"] == "Escolha"
    assert prem["tipo_variavel"] == "Cardinal"
    assert prem["estrutura_decisoria"] == "Individual"
    assert prem["compensatoriedade"] == "Compensatorio"


def test_t05_ordenacao_mista_grupo():
    t = ("Um comitê precisa ordenar projetos para definir prioridade. "
         "Os critérios envolvem variáveis quantitativas e qualitativas. "
         "Nem todas as preferências são conhecidas.")
    prem, evid, score = infer_premissas(t)
    assert prem["tipo_problema"] == "Ordenacao"
    assert prem["tipo_variavel"] == "Mista"
    assert prem["estrutura_decisoria"] == "Grupo"
    assert prem["completude_pref"] == "Incompleto"


def test_t09_classificacao_ordinal_individual():
    t = ("Um auditor precisa classificar processos em categorias previamente definidas "
         "usando avaliações qualitativas ordenadas.")
    prem, evid, score = infer_premissas(t)
    assert prem["tipo_problema"] == "Classificacao"
    assert prem["tipo_variavel"] == "Ordinal"


def test_infer_premissas_returns_three_dicts_with_same_keys():
    prem, evid, score = infer_premissas("teste simples")
    assert set(prem.keys()) == set(evid.keys()) == set(score.keys())
