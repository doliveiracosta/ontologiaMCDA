from ontomcda.nlp.normalize import (
    canon_value,
    contains_term,
    has_negated_expression,
    local_name,
    norm_txt,
)


def test_norm_txt_lowercases_and_strips_accents():
    assert norm_txt("Ordenação") == "ordenacao"
    assert norm_txt("CLASSIFICAÇÃO") == "classificacao"


def test_norm_txt_collapses_whitespace():
    assert norm_txt("  foo\t\nbar   baz  ") == "foo bar baz"


def test_contains_term_requires_word_boundary():
    assert contains_term("quero escolher a melhor", "escolher") == 1
    assert contains_term("desescolher o antigo", "escolher") == 0


def test_has_negated_expression_detects_nao():
    assert has_negated_expression("nao se pretende escolher", "escolher") is True
    assert has_negated_expression("se pretende escolher", "escolher") is False


def test_canon_value_maps_accents_and_variants():
    assert canon_value("tipo_problema", "Ordenação") == "Ordenacao"
    assert canon_value("tipo_problema", "Classificação") == "Classificacao"
    assert (
        canon_value("compensatoriedade", "parcialmente compensatório")
        == "ParcialmenteCompensatorio"
    )


def test_canon_value_none_passes_through():
    assert canon_value("tipo_problema", None) is None


def test_local_name_extracts_fragment():
    from rdflib import URIRef
    uri = URIRef("http://www.ontomcda.org/onto#TOPSIS")
    assert local_name(uri) == "TOPSIS"
