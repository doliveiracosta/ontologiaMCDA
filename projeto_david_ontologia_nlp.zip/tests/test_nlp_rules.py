from ontomcda.nlp.rules import infer_tipo_problema_por_regras


def test_rule_detects_ordenacao_from_ranking():
    txt = "precisamos gerar um ranking das alternativas"
    valor, evid = infer_tipo_problema_por_regras(txt, [])
    assert valor == "Ordenacao"


def test_rule_detects_escolha_from_melhor_alternativa():
    txt = "o objetivo final e selecionar a melhor alternativa"
    valor, evid = infer_tipo_problema_por_regras(txt, [])
    assert valor == "Escolha"


def test_rule_detects_classificacao_from_categorias():
    txt = "classificar as alternativas em categorias previamente definidas"
    valor, evid = infer_tipo_problema_por_regras(txt, [])
    assert valor == "Classificacao"


def test_rule_returns_none_when_tied():
    txt = "avaliar as opcoes"
    valor, evid = infer_tipo_problema_por_regras(txt, [])
    assert valor is None
