

def test_load_profiles_finds_many_methods(profiles):
    assert len(profiles) >= 50


def test_load_profiles_includes_canonical_methods(profiles):
    for m in ["TOPSIS_Classico", "AHP", "PROMETHEE_III", "BWM_TOPSIS", "PSI"]:
        assert m in profiles, f"method {m} not loaded"


def test_load_profiles_dual_namespace_reads_attributes(profiles):
    """PROMETHEE_III has attributes in both NEW_NS and OLD_NS. Reader must merge."""
    prof = profiles["PROMETHEE_III"]
    assert prof["tipo_problema"] == "Ordenacao"
    assert prof["compensatoriedade"] == "ParcialmenteCompensatorio"
    assert prof["estrutura_decisoria"] == "Coletiva"


def test_load_profiles_parses_boolean_data_attrs(profiles):
    topsis = profiles["TOPSIS_Classico"]
    assert topsis["usa_pesos"] in {"Sim", "Nao", None}
