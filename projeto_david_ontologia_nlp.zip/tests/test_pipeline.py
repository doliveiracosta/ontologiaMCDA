import pandas as pd
from ontomcda.pipeline import batch_recomendar, recomendar


def test_recomendar_returns_structured_result(profiles):
    texto = "Precisamos ranquear projetos; decisão em grupo, variáveis mistas."
    r = recomendar(texto, profiles, top_k=5)
    assert set(r.keys()) == {"premissas", "query_profile", "aceitos", "rejeitados", "faltantes"}
    assert isinstance(r["aceitos"], pd.DataFrame)
    assert len(r["aceitos"]) <= 5


def test_recomendar_flags_missing_mandatory_premise(profiles):
    r = recomendar("texto vazio irrelevante xyz", profiles)
    assert "tipo_problema" in r["faltantes"]
    assert r["aceitos"].empty


def test_batch_recomendar_processes_all_rows(profiles):
    casos = pd.DataFrame([
        {"id": "a", "texto": "escolher melhor fornecedor com dados numericos"},
        {"id": "b", "texto": "ordenar projetos por prioridade em grupo"},
    ])
    out = batch_recomendar(casos, profiles, top_k=3)
    assert len(out) == 2
    assert set(out[0].keys()) >= {"id", "premissas", "ranking"}


def test_batch_recomendar_raises_on_missing_columns(profiles):
    casos = pd.DataFrame([{"case_id": "a", "descricao": "texto"}])
    try:
        batch_recomendar(casos, profiles)
        assert False, "should have raised ValueError"
    except ValueError as e:
        assert "id" in str(e) or "texto" in str(e)
