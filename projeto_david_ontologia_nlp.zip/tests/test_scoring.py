from ontomcda.scoring import build_query_profile, ontology_match, tipo_variavel_match


def test_tipo_variavel_mista_accepts_cardinal_and_ordinal():
    assert tipo_variavel_match("Mista", "Cardinal") is True
    assert tipo_variavel_match("Mista", "Ordinal") is True
    assert tipo_variavel_match("Mista", "PseudoCardinal") is True


def test_tipo_variavel_ordinal_rejects_cardinal():
    assert tipo_variavel_match("Ordinal", "Cardinal") is False


def test_ontology_match_parcialmente_compensatorio_is_flexible():
    ok, _ = ontology_match("compensatoriedade", "ParcialmenteCompensatorio", "Compensatorio")
    assert ok is True
    ok, _ = ontology_match("compensatoriedade", "ParcialmenteCompensatorio", "NaoCompensatorio")
    assert ok is True


def test_ontology_match_estrutura_decisoria_monomulti_accepts_both():
    ok_ind, _ = ontology_match("estrutura_decisoria", "Individual", "MonoMulti")
    ok_grp, _ = ontology_match("estrutura_decisoria", "Grupo", "MonoMulti")
    assert ok_ind is True and ok_grp is True


def test_ontology_match_returns_none_when_premise_missing():
    ok, _ = ontology_match("ambiente_decisao", None, "Certeza")
    assert ok is None


def test_build_query_profile_includes_all_attrs():
    prem = {"tipo_problema": "Escolha"}
    score_map = {"tipo_problema": 2}
    qp = build_query_profile(prem, score_map)
    assert "tipo_problema" in qp
    assert qp["tipo_problema"]["value"] == "Escolha"
